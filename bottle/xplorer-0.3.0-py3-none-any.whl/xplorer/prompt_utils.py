from typing import List, Dict, Any, Optional, Tuple
from rich.console import Console
from rich.table import Table
from rich.prompt import Prompt
import shutil
import subprocess
import sys
import json
import tempfile
import os

# Sentinel value for unhealthy selection
UNHEALTHY_SENTINEL = "__UNHEALTHY__"

def _get_condition_status(instance: Dict[str, Any], condition_type: str) -> str:
    """Get the status of a specific condition from the instance."""
    conditions = instance.get('status', {}).get('conditions', [])
    for condition in conditions:
        if condition.get('type') == condition_type:
            status = condition.get('status', 'Unknown')
            return f"{condition_type}: {status}"
    return f"{condition_type}: Unknown"

def _get_age(instance: Dict[str, Any]) -> str:
    """Calculate and format the age of the resource."""
    creation_time = instance.get('metadata', {}).get('creationTimestamp', '')
    if not creation_time:
        return "Age: Unknown"
    # For now, just return the timestamp - could enhance with relative time calculation
    return f"Created: {creation_time}"

def _create_preview_content(instance: Dict[str, Any]) -> str:
    """Create formatted preview content for an instance."""
    metadata = instance.get('metadata', {})
    spec = instance.get('spec', {})
    status = instance.get('status', {})
    
    lines = []
    lines.append("=" * 60)
    lines.append(f"CLAIM: {metadata.get('name', 'Unknown')}")
    lines.append("=" * 60)
    lines.append("")
    
    # Basic info
    lines.append("📋 BASIC INFO")
    lines.append(f"  Kind: {instance.get('kind', 'Unknown')}")
    lines.append(f"  Namespace: {metadata.get('namespace', 'cluster-scoped')}")
    lines.append(f"  API Version: {instance.get('apiVersion', 'Unknown')}")
    lines.append(f"  {_get_age(instance)}")
    lines.append("")
    
    # Status conditions
    lines.append("🔍 STATUS")
    conditions = status.get('conditions', [])
    if conditions:
        for condition in conditions:
            ctype = condition.get('type', 'Unknown')
            cstatus = condition.get('status', 'Unknown')
            reason = condition.get('reason', '')
            message = condition.get('message', '')
            icon = "✅" if cstatus == "True" else "❌" if cstatus == "False" else "❓"
            lines.append(f"  {icon} {ctype}: {cstatus}")
            if reason:
                lines.append(f"     Reason: {reason}")
            if message:
                lines.append(f"     Message: {message}")
    else:
        lines.append("  No status conditions available")
    lines.append("")
    
    # Resource reference
    resource_ref = spec.get('resourceRef')
    if resource_ref:
        lines.append("🔗 RESOURCE REFERENCE")
        lines.append(f"  Kind: {resource_ref.get('kind', 'Unknown')}")
        lines.append(f"  Name: {resource_ref.get('name', 'Unknown')}")
        lines.append(f"  API Version: {resource_ref.get('apiVersion', 'Unknown')}")
        lines.append("")
    
    # Labels
    labels = metadata.get('labels', {})
    if labels:
        lines.append("🏷️  LABELS")
        for key, value in labels.items():
            lines.append(f"  {key}: {value}")
        lines.append("")
    
    # Annotations (filtered and formatted)
    annotations = metadata.get('annotations', {})
    # Skip kubectl last-applied-configuration as it's too verbose
    filtered_annotations = {k: v for k, v in annotations.items() 
                          if k != 'kubectl.kubernetes.io/last-applied-configuration'}
    
    if filtered_annotations:
        lines.append("📝 ANNOTATIONS")
        # Show up to 8 annotations with better formatting
        for key, value in list(filtered_annotations.items())[:8]:
            # Truncate very long values
            if len(str(value)) > 100:
                formatted_value = str(value)[:97] + "..."
            else:
                formatted_value = str(value)
            
            # Format multi-line values
            if '\n' in formatted_value:
                lines.append(f"  {key}:")
                for line in formatted_value.split('\n')[:3]:  # Show first 3 lines
                    lines.append(f"    {line}")
                if len(formatted_value.split('\n')) > 3:
                    lines.append("    ...")
            else:
                lines.append(f"  {key}: {formatted_value}")
        
        if len(filtered_annotations) > 8:
            lines.append(f"  ... and {len(filtered_annotations) - 8} more annotations")
        lines.append("")
    
    return "\n".join(lines)

def _get_unique_values(instances: List[Dict[str, Any]], field_path: str) -> List[str]:
    """Extract unique values from instances for a given field path."""
    values = set()
    for instance in instances:
        if field_path == "kind":
            kind = instance.get('kind', '')
            if kind:
                values.add(kind)
        elif field_path == "namespace":
            namespace = instance.get('metadata', {}).get('namespace', '')
            if namespace:
                values.add(namespace)
        elif field_path == "env":
            # Look for environment in labels
            labels = instance.get('metadata', {}).get('labels', {})
            env_value = (labels.get('environment') or 
                        labels.get('env') or 
                        labels.get('app.kubernetes.io/environment') or 
                        labels.get('stage') or
                        labels.get('tier', ''))
            if env_value:
                values.add(env_value)
    return sorted(list(values))

def prompt_select_claim(instances: List[Dict[str, Any]], filter_kind: Optional[str] = None, filter_namespace: Optional[str] = None, _original_instances: Optional[List[Dict[str, Any]]] = None) -> Tuple[Optional[str], Optional[str]]:
    """
    Prompt the user to select a claim, show all, or show unhealthy.
    Uses fzf with preview and filtering if available, otherwise fallback to rich prompt.
    Returns:
        - (name, namespace) for a specific claim.
        - (None, None) for 'Show All Claims'.
        - (None, UNHEALTHY_SENTINEL) for 'Show Unhealthy Claims'.
    """
    console = Console()
    fzf_available = shutil.which("fzf") is not None
    
    # Keep track of original instances for filtering purposes
    if _original_instances is None:
        _original_instances = instances
    
    if not instances:
        console.print("[red]No claims found.[/red]")
        return None, None
    
    # Apply filters
    filtered_instances = instances
    if filter_kind:
        filtered_instances = [inst for inst in filtered_instances if inst.get('kind') == filter_kind]
    if filter_namespace:
        filtered_instances = [inst for inst in filtered_instances if inst.get('metadata', {}).get('namespace') == filter_namespace]
    
    if not filtered_instances:
        console.print(f"[red]No claims found matching filters (kind={filter_kind}, namespace={filter_namespace}).[/red]")
        return None, None
    
    # Filter status will be handled by the calling code, not here
    
    instances = filtered_instances
    
    # Create instance lookup
    instance_lookup = {}
    options = []
    label_to_tuple = {}
    
    # Compute max widths for pretty alignment
    name_w = max((len(inst.get('metadata', {}).get('name', '')) for inst in instances), default=4)
    kind_w = max((len(inst.get('kind', '')) for inst in instances), default=4) 
    ns_w = max((len(inst.get('metadata', {}).get('namespace', '')) for inst in instances), default=9)
    status_w = 6  # For emoji checkboxes (✅❌) - increased width
    
    fmt = f"{{:<{name_w}}}  {{:<{kind_w}}}  {{:<{ns_w}}}  {{:<{status_w}}}"
    
    for inst in instances:
        name = inst.get('metadata', {}).get('name', '')
        kind = inst.get('kind', '')
        namespace = inst.get('metadata', {}).get('namespace', '')
        
        # Get health status for display with colored checkboxes
        ready_status = _get_condition_status(inst, 'Ready').split(': ')[1]
        synced_status = _get_condition_status(inst, 'Synced').split(': ')[1]
        
        # Convert to colored checkboxes
        ready_icon = "✅" if ready_status == "True" else "❌" if ready_status == "False" else "❓"
        synced_icon = "✅" if synced_status == "True" else "❌" if synced_status == "False" else "❓"
        health = f"{ready_icon}{synced_icon}"
        
        label = fmt.format(name, kind, namespace, health)
        options.append(label)
        label_to_tuple[label] = (name, namespace)
        instance_lookup[label] = inst

    # Add special options
    unhealthy_option_label = ">>> Show Unhealthy Claims <<< (Ctrl-U)"
    
    # Show "all currently visible" option - always available
    if any([filter_kind, filter_namespace]):
        # When filtered, show what's currently visible with filter info
        filter_desc = []
        if filter_kind:
            filter_desc.append(f"Kind={filter_kind}")
        if filter_namespace:
            filter_desc.append(f"Namespace={filter_namespace}")
        all_visible_label = f">>> Show All Visible ({', '.join(filter_desc)}) <<< (Ctrl-A)"
        clear_filters_label = "🔄 Clear All Filters <<< (Ctrl-R)"
        filter_options = [all_visible_label, clear_filters_label]
    else:
        # When not filtered, show all claims
        all_visible_label = ">>> Show All Claims <<< (Ctrl-A)"
        filter_options = [all_visible_label]
    
    # Only claims data in scrollable content, menu options will be in prompt area
    special_options = [unhealthy_option_label] + filter_options
    header_line = fmt.format('NAME', 'KIND', 'NAMESPACE', 'STATUS')
    fzf_options = options  # Only claims data, no menu items in scrollable content

    if fzf_available:
        try:
            # Create a temporary file for the preview script
            with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
                json.dump({label: _create_preview_content(inst) for label, inst in instance_lookup.items()}, f)
                preview_data_file = f.name
            
            # Create preview script
            preview_script = f'''
import json
import sys
label = sys.argv[1] if len(sys.argv) > 1 else ""
try:
    with open("{preview_data_file}", "r") as f:
        data = json.load(f)
    print(data.get(label, "No preview available"))
except:
    print("Preview not available")
'''
            
            with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
                f.write(preview_script)
                preview_script_file = f.name
            
            # Create a script to handle filtering by current selection  
            filter_script = f'''
import sys

label = sys.argv[1] if len(sys.argv) > 1 else ""
if not label or label.startswith(">>>") or label.startswith("🔄") or label == "---":
    sys.exit(0)

# Parse the selected line to get kind and namespace
# Format: name  kind  namespace  status (no spaces in claim names)
try:
    parts = label.split()
    if len(parts) >= 4:  # name, kind, namespace, status
        name = parts[0]
        kind = parts[1] 
        namespace = parts[2]
        status = parts[3]
        
        if sys.argv[2] == "kind":
            print(f"FILTER_KIND:{{kind}}")
        elif sys.argv[2] == "namespace":
            print(f"FILTER_NAMESPACE:{{namespace}}")
except Exception as e:
    # Debug output
    with open("/tmp/fzf_filter_debug.log", "w") as f:
        f.write(f"Error: {{e}}\\nLabel: '{{label}}'\\nParts: {{parts if 'parts' in locals() else 'N/A'}}\\nArgv: {{sys.argv}}\\n")
'''
            
            with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
                f.write(filter_script)
                filter_script_file = f.name
            
            # Build multi-line header with all shortcuts and column names
            shortcuts_line1 = 'Shortcuts: Ctrl-K=filter kind, Ctrl-N=filter namespace, Ctrl-A=show all'
            shortcuts_line2 = '           Ctrl-R=clear filters, Ctrl-U=unhealthy, Ctrl-/=toggle preview'
            
            # Combine shortcuts and column header into multi-line header with divider
            divider_line = '─' * 200  # Very long horizontal line divider that will be clipped
            multi_line_header = f'{shortcuts_line1}\n{shortcuts_line2}\n{divider_line}\n{header_line}'
            prompt_text = '🔍 Select claim: '
            
            # Calculate dynamic height based on number of items (only claims now, menu items are in header)
            # Items: claims + prompt area
            total_items = len(options) + 5  # +5 for prompt/status/padding lines
            # Cap at reasonable limits: min 10 lines, max for larger screens
            dynamic_height = min(max(total_items, 10), 60)  # Max 60 lines
            height_param = f'{dynamic_height}'
            
            fzf_cmd = [
                'fzf',
                '--with-nth=1,2,3,4',
                '--prompt', prompt_text,
                '--header', multi_line_header,
                '--header-first',
                '--reverse',
                '--cycle',
                '--preview', f'python3 {preview_script_file} {{}}',
                '--preview-window', 'right:60%:wrap',
                '--height', height_param,
                '--border',
                '--color', 'hl:33,hl+:37,info:37,marker:37,pointer:125,spinner:37,prompt:37,header:33',
                f'--bind=ctrl-u:become(echo "{unhealthy_option_label}")+accept',
                f'--bind=ctrl-k:become(python3 {filter_script_file} {{}} kind)+accept',
                f'--bind=ctrl-n:become(python3 {filter_script_file} {{}} namespace)+accept',
                '--bind=ctrl-/:toggle-preview',
                '--bind=alt-up:preview-page-up',
                '--bind=alt-down:preview-page-down'
            ]
            
            # Always add Ctrl-A for "Show All Currently Visible"
            fzf_cmd.append(f'--bind=ctrl-a:become(echo "{all_visible_label}")+accept')
            
            # Add clear filters binding if filters are active
            if any([filter_kind, filter_namespace]):
                clear_filters_label = filter_options[1]  # "Clear All Filters"
                fzf_cmd.append(f'--bind=ctrl-r:become(echo "{clear_filters_label}")+accept')
            
            fzf = subprocess.Popen(fzf_cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True)
            fzf_input = "\n".join(fzf_options)
            selected, _ = fzf.communicate(fzf_input)
            selected = selected.strip()
            
            # Cleanup temporary files
            try:
                os.unlink(preview_data_file)
                os.unlink(preview_script_file)
                os.unlink(filter_script_file)
            except:
                pass

            # Check for special options first
            if selected.startswith(">>> Show All Claims"):
                return None, None
            if selected == unhealthy_option_label:
                return None, UNHEALTHY_SENTINEL
            
            # Check for show all currently visible claims option
            if selected.startswith(">>> Show All Visible"):
                # Return the filter context so calling code can map to existing -k/-n functionality
                if filter_kind:
                    return "ALL_KIND", filter_kind
                elif filter_namespace:
                    return "ALL_NAMESPACE", filter_namespace
                else:
                    # No filters (shouldn't happen but fallback)
                    return None, None
            
            # Check for filter commands from keyboard shortcuts
            if selected.startswith("FILTER_KIND:"):
                filter_value = selected.split("FILTER_KIND:")[1]
                return prompt_select_claim(_original_instances, filter_kind=filter_value, _original_instances=_original_instances)
            elif selected.startswith("FILTER_NAMESPACE:"):
                filter_value = selected.split("FILTER_NAMESPACE:")[1]
                return prompt_select_claim(_original_instances, filter_namespace=filter_value, _original_instances=_original_instances)
            
            # Check for clear filters option
            if selected.startswith("🔄 Clear All Filters"):
                return prompt_select_claim(_original_instances, _original_instances=_original_instances)

            # Extract the name and namespace from the selected row
            if selected in label_to_tuple:
                return label_to_tuple[selected]

            # Fallback parsing
            parts = selected.split()
            if len(parts) >= 2 and not selected.startswith(">>>") and selected != "---":
                return parts[0], parts[-2]  # name, namespace (status is last)

            console.print("[red]No valid selection made. Exiting.[/red]")
            sys.exit(0)

        except Exception as e:
            console.print(f"[red]FZF failed: {e}. Falling back to rich prompt.[/red]")
    # Fallback to rich prompt
    table = Table(show_header=True, header_style="bold magenta")
    table.add_column("#", style="dim", width=4)
    table.add_column("Name")
    table.add_column("Kind")
    table.add_column("Namespace")
    num_instances = len(instances)
    for idx, inst in enumerate(instances):
        name = inst.get('metadata', {}).get('name', '')
        kind = inst.get('kind', '')
        namespace = inst.get('metadata', {}).get('namespace', '')
        table.add_row(str(idx + 1), name, kind, namespace)

    # Add special options to the table display
    table.add_row("---", "---", "---", "---")
    table.add_row("[bold]a[/bold]", "Show All Claims", "", "")
    table.add_row("[bold]u[/bold]", "Show Unhealthy Claims", "", "")

    console.print("\n[bold]Select a claim to inspect, or choose an option:[/bold]")
    console.print(table)

    while True:
        choice = Prompt.ask(f"Enter claim number (1-{num_instances}), 'a' (all), or 'u' (unhealthy)", default="1").lower()
        if choice == 'a':
            return None, None
        if choice == 'u':
            return None, UNHEALTHY_SENTINEL
        if choice.isdigit() and 1 <= int(choice) <= num_instances:
            inst = instances[int(choice) - 1]
            return inst.get('metadata', {}).get('name', ''), inst.get('metadata', {}).get('namespace', '')
        console.print(f"[red]Invalid selection. Please enter a number between 1 and {num_instances}, 'a', or 'u'.[/red]")
