"""Watch module for Kubernetes resource exploration."""

import time
import sys
from rich.console import Console
from rich.live import Live
from xplorer.discovery import (
    discover_xr,
    discover_child_resources,
    get_matches,
    attach_events
)
from xplorer.display import display_resources, panel_with_timestamp

def parse_watch_arg(watch_arg):
    """
    Parse the watch argument to extract period and timeout.

    Args:
        watch_arg: The watch argument value from command line

    Returns:
        tuple: (period in seconds, timeout in seconds)
    """
    default_period = 15
    default_timeout_min = 30
    if watch_arg is True:
        return default_period, default_timeout_min * 60
    try:
        parts = str(watch_arg).split(',')
        period = int(parts[0]) if parts[0] else default_period
        timeout_min = int(parts[1]) if len(parts) > 1 and parts[1] else default_timeout_min
        return period, timeout_min * 60
    except Exception:
        return default_period, default_timeout_min * 60

def watch_claim(claim_name, namespace, matches, dynamic_client, cache, watch_arg, verbose=0):
    """
    Watch a claim for changes and update the display periodically.

    Args:
        claim_name: Name of the claim to watch
        namespace: Namespace of the claim
        matches: List of CRD matches from discover_by_category
        dynamic_client: Kubernetes dynamic client
        cache: Resource cache
        watch_arg: Watch argument value (period and timeout)
        verbose: Verbosity level

    Returns:
        None
    """
    console = Console()
    period, max_duration = parse_watch_arg(watch_arg)
    console.print(f"[bold green]Entering watch mode. Press Ctrl+C to exit. (Period: {period}s, Timeout: {max_duration//60}min)[/bold green]")

    try:
        start_time = time.time()

        # Initial fetch
        matching_crds = get_matches(claim_name, matches, dynamic_client, cache)

        # Filter by namespace
        user_set_namespace = any(arg in ('-n', '--namespace') for arg in sys.argv)
        if user_set_namespace:
            namespace_filtered = [
                m for m in matching_crds
                if m.get('metadata', {}).get('namespace', 'default').lower() == namespace.lower()
            ]
        else:
            namespace_filtered = matching_crds

        if len(namespace_filtered) == 1:
            manifest = namespace_filtered[0]
        else:
            console.print(f"[red]Claim '{claim_name}' not found{' in namespace ' + namespace if user_set_namespace else ''}. Exiting watch mode.[/red]")
            return

        xr_manifest = discover_xr(manifest, dynamic_client, namespace, cache)
        discovered_manifests = None
        if xr_manifest:
            # Set only_unhealthy based on verbose flag
            only_unhealthy = not verbose
            discovered_manifests = discover_child_resources(xr_manifest, dynamic_client, cache, only_unhealthy=only_unhealthy)

        tree = display_resources(manifest, xr_manifest, discovered_manifests, verbose, dynamic_client, cache, as_renderable=True)
        panel = panel_with_timestamp(tree)

        with Live(panel, refresh_per_second=4, console=console, transient=True) as live:
            while True:
                if time.time() - start_time > max_duration:
                    console.print("\n[bold yellow]Watch mode timeout reached. Exiting.[/bold yellow]")
                    break

                time.sleep(period)

                # Refetch the latest manifest and related resources
                matching_crds = get_matches(claim_name, matches, dynamic_client, cache)

                # Only filter by namespace if -n was explicitly provided by the user
                user_set_namespace = any(arg in ('-n', '--namespace') for arg in sys.argv)
                if user_set_namespace:
                    namespace_filtered = [
                        m for m in matching_crds
                        if m.get('metadata', {}).get('namespace', 'default').lower() == namespace.lower()
                    ]
                else:
                    namespace_filtered = matching_crds

                if len(namespace_filtered) == 1:
                    manifest = namespace_filtered[0]
                else:
                    console.print(f"[red]Claim '{claim_name}' not found{' in namespace ' + namespace if user_set_namespace else ''}. Exiting watch mode.[/red]")
                    break

                xr_manifest = discover_xr(manifest, dynamic_client, namespace, cache)
                discovered_manifests = None
                if xr_manifest:
                    # Set only_unhealthy based on verbose flag
                    only_unhealthy = not verbose
                    discovered_manifests = discover_child_resources(xr_manifest, dynamic_client, cache, only_unhealthy=only_unhealthy)

                # Refetch events/conditions
                attach_events(manifest, dynamic_client, cache)
                if xr_manifest:
                    attach_events(xr_manifest, dynamic_client, cache)

                if discovered_manifests:
                    def attach_events_recursively(resource_tree):
                        attach_events(resource_tree['resource'], dynamic_client, cache)
                        for child in resource_tree.get('children', []):
                            attach_events_recursively(child)
                    attach_events_recursively(discovered_manifests)

                # Update the live panel
                tree = display_resources(manifest, xr_manifest, discovered_manifests, verbose, dynamic_client, cache, as_renderable=True)
                live.update(panel_with_timestamp(tree))

    except KeyboardInterrupt:
        console.print("\n[bold red]Watch mode exited by user.[/bold red]")
        sys.exit(0)
