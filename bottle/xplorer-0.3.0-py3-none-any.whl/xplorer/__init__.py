"""Kubernetes resource explorer package."""

import importlib.metadata

from .cache import ResourceCache
from .cli import main
from .discovery import (
    discover_by_category,
    discover_xr,
    discover_child_resources,
    list_crd_instances,
    get_matches,
    attach_events,
    process_child_resources
)
from .display import display_resources, show_cache_info

__all__ = [
    'ResourceCache',
    'main',
    'discover_by_category',
    'discover_xr',
    'discover_child_resources',
    'list_crd_instances',
    'get_matches',
    'attach_events',
    'process_child_resources',
    'display_resources',
    'show_cache_info'
]

try:
    __version__ = importlib.metadata.version("xplorer")
except importlib.metadata.PackageNotFoundError:
    # Fallback for development environment
    __version__ = "0.1.0-dev"