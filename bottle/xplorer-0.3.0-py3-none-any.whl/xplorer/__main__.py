#!/usr/bin/env python3
"""Entry point for running xplorer as a module."""

from xplorer.cli import main

if __name__ == "__main__":
    main()