from typing import Dict, Optional
from kubernetes.client import ApiClient
import json
import sys


def is_plural(s: str) -> bool:
    """Check if a string is already in plural form"""
    if not s:
        return False

    # Common plural endings
    plural_endings = ['s', 'es', 'ies', 'ves']

    # Check if the word ends with any of the plural endings
    for ending in plural_endings:
        if s.lower().endswith(ending):
            return True

    # Special cases for irregular plurals
    irregular_plurals = {
        'children': 'child',
        'people': 'person',
        'men': 'man',
        'women': 'woman',
        'mice': 'mouse',
        'geese': 'goose',
        'teeth': 'tooth',
        'feet': 'foot'
    }

    return s.lower() in irregular_plurals


def build_singular_to_plural_map(api_client_obj: ApiClient) -> Dict[str, str]:
    """Build a mapping between singular and plural resource names"""
    mapping = {}
    try:
        # Get API groups and resources
        api_groups = api_client_obj.call_api(
            '/apis', 'GET', _preload_content=False)
        api_groups = json.loads(api_groups.data)

        # Process each API group
        for group in api_groups['groups']:
            group_path = f"/apis/{group['name']}/{group['preferredVersion']['version']}"
            group_resources = api_client_obj.call_api(
                group_path, 'GET', _preload_content=False)
            group_resources = json.loads(group_resources.data)

            # Map resources in this group
            for resource in group_resources['resources']:
                if '/' not in resource['name']:  # Skip subresources
                    mapping[resource['singularName']] = resource['name']

        # Add core resources
        core_resources = api_client_obj.call_api(
            '/api/v1', 'GET', _preload_content=False)
        core_resources = json.loads(core_resources.data)
        for resource in core_resources['resources']:
            if '/' not in resource['name']:  # Skip subresources
                mapping[resource['singularName']] = resource['name']

    except Exception as e:
        print(f"Error building resource map: {e}", file=sys.stderr)

    return mapping


def get_api_data(api_client_obj: ApiClient, path: str) -> Optional[Dict]:
    """Get API data from a specific path.

    Args:
        api_client_obj: The Kubernetes API client
        path: The API path to query

    Returns:
        The API response data or None if an error occurs
    """
    try:
        # Use _preload_content=False to get a file-like response stream
        resp, status, headers = api_client_obj.call_api(
            path, 'GET',
            _preload_content=False,
            auth_settings=['BearerToken']
        )

        if status >= 200 and status < 300:
            try:
                # Handle both string and bytes response
                if isinstance(resp.data, bytes):
                    data = json.loads(resp.data.decode('utf-8'))
                else:
                    data = json.loads(resp.data)

                if isinstance(data, dict) and 'kind' in data:
                    return data
                print(f"Invalid response format from {path}: missing 'kind' field", file=sys.stderr)
                return None
            except json.JSONDecodeError as e:
                print(f"Error decoding JSON from {path}: {e}", file=sys.stderr)
                return None
            except AttributeError:
                print(f"Invalid response object from {path}", file=sys.stderr)
                return None
        else:
            print(f"HTTP error {status} from {path}", file=sys.stderr)
            return None

    except Exception as e:
        print(f"Error fetching data from {path}: {e}", file=sys.stderr)
        return None


def should_include_child(child, verbose):
    if verbose >= 1:  # -v or higher: show all children
        return True
    else:  # default: only show children with errors or non-normal status
        from xplorer.display import get_resource_status
        status = get_resource_status(child)
        return status != '[green]✓[/green]'


def check_resource_health(resource_manifest, cache):
    """Check if a resource or any of its nested references are unhealthy.

    Args:
        resource_manifest: The resource manifest to check
        cache: The resource cache instance

    Returns:
        True if the resource or any of its nested references are unhealthy, False otherwise
    """
    from xplorer.display import get_resource_conditions

    # Check if this resource is unhealthy
    child_ready, child_synced = get_resource_conditions(resource_manifest)
    if child_ready != 'True' or child_synced != 'True':
        return True

    # Check if this resource has nested references
    if 'spec' in resource_manifest and 'resourceRefs' in resource_manifest['spec']:
        nested_refs = resource_manifest['spec'].get('resourceRefs', [])
        for nested_ref in nested_refs:
            api_version = nested_ref.get('apiVersion', '')
            kind = nested_ref.get('kind', '')
            name = nested_ref.get('name', '')

            if not api_version or not kind or not name:
                continue

            # Split api_version for the group cache
            group = ''
            version = api_version
            if '/' in api_version:
                group, version = api_version.split('/')

            # Get the instance using the cache
            if group and version and kind and name:
                nested_result = cache.get_instance(group, version, kind, name)
                if nested_result and check_resource_health(nested_result, cache):
                    return True

    return False
