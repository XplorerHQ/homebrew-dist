import json
import os
import sys
import time
from typing import Dict, Set
import urllib3.exceptions
from .display import format_size_kb

class ResourceCache:
    """Cache for Kubernetes resources to reduce API calls with file persistence"""
    def __init__(self, dynamic_client, debug=False):
        self._client = dynamic_client
        self._debug = debug
        self._resources_meta: Dict = {}
        self._resources: Dict = {}
        self._crds = None
        self._group_instances = {}
        self._namespace_events = {}
        self._errors: Set = set()
        self._group_relationships: Dict[str, Set] = {}
        self._group_discovery_in_progress: Set = set()
        self._cache_file = os.path.expanduser('~/.kube/discovery_cache.json')
        self._cache_ttl = 3600*3  # 3 hours in seconds
        self._cache_info = None

        # Try to load cache from file
        self._load_cache()

    def get_cache_info(self):
        """Get cache information.

        Returns:
            dict: Cache information including size (KB) and age (minutes), or None if cache not loaded
        """
        return self._cache_info

    def debug(self, message):
        """Print debug message if debug mode is enabled"""
        if self._debug:
            print(f"[DEBUG] {message}", file=sys.stderr)

    def _validate_cache_data(self, cache_data):
        """Validate that cache data is well-formed and compatible"""
        try:
            required_fields = ['timestamp', 'crds', 'resources_meta', 'group_relationships']
            if not all(k in cache_data for k in required_fields):
                return False

            # Validate CRDs structure
            if not isinstance(cache_data['crds'], dict) or 'items' not in cache_data['crds']:
                return False

            # Validate resources_meta structure
            if not isinstance(cache_data['resources_meta'], dict):
                return False

            # Validate group relationships structure
            if not isinstance(cache_data['group_relationships'], dict):
                return False

            # Convert group_relationships values from lists back to sets
            cache_data['group_relationships'] = {
                k: set(v) for k, v in cache_data['group_relationships'].items()
            }

            return True
        except Exception:
            return False

    def _load_cache(self):
        """Load cached data from file if it exists and is not expired"""
        try:
            if os.path.exists(self._cache_file):
                cache_size = os.path.getsize(self._cache_file)
                cache_mtime = os.path.getmtime(self._cache_file)
                cache_age = time.time() - cache_mtime

                self.debug(f"Found cache file: {self._cache_file} (size: {format_size_kb(cache_size)}KB, age: {cache_age/60:.1f}min)")

                with open(self._cache_file, 'r') as f:
                    cache_data = json.load(f)

                # Check if cache is still valid (within TTL)
                if cache_data.get('timestamp', 0) + self._cache_ttl > time.time():
                    # Validate cache data
                    if self._validate_cache_data(cache_data):
                        self._crds = cache_data['crds']
                        self._resources_meta = cache_data['resources_meta']
                        self._group_relationships = cache_data['group_relationships']

                        self._cache_info = {
                            'size': cache_size/1024,
                            'age': cache_age/60
                        }
                        self.debug("Successfully loaded cache data")
                        return True
                    else:
                        self.debug("Cache data validation failed")
                else:
                    self.debug("Cache has expired")

        except (json.JSONDecodeError, KeyError):
            # Try to recover from backup
            backup_file = f"{self._cache_file}.bak"
            try:
                if os.path.exists(backup_file):
                    self.debug("Attempting to recover from backup file")
                    with open(backup_file, 'r') as f:
                        cache_data = json.load(f)
                    if self._validate_cache_data(cache_data):
                        self._crds = cache_data['crds']
                        self._resources_meta = cache_data['resources_meta']
                        self._group_relationships = cache_data['group_relationships']

                        # Set cache info for backup file
                        cache_size = os.path.getsize(backup_file)
                        cache_mtime = os.path.getmtime(backup_file)
                        cache_age = time.time() - cache_mtime
                        self._cache_info = {
                            'size': cache_size/1024,
                            'age': cache_age/60
                        }

                        self.debug(f"Successfully recovered cache from backup (size: {format_size_kb(cache_size)}KB, age: {cache_age/60:.1f}min)")
                        # Restore the backup as main cache
                        os.replace(backup_file, self._cache_file)
                        return True
                    else:
                        self.debug("Backup file validation failed")
            except Exception as e:
                self.debug(f"Failed to recover from backup: {e}")
                print("Cache file is corrupt, refreshing", file=sys.stderr)
                self._cache_info = None  # Reset cache info for fresh data
        except Exception as e:
            self.debug(f"Error reading cache: {e}")
            print(f"Error reading cache: {e}", file=sys.stderr)
            self._cache_info = None  # Reset cache info for fresh data

        return False

    def _save_cache(self):
        """Save cache data to file with backup"""
        try:
            self.debug("Saving cache data to file")
            # Ensure cache directory exists
            os.makedirs(os.path.dirname(self._cache_file), exist_ok=True)

            # Convert sets to lists for JSON serialization
            group_relationships = {
                k: list(v) for k, v in self._group_relationships.items()
            }

            # Prepare cache data (excluding statuses)
            cache_data = {
                'timestamp': time.time(),
                'crds': self._crds,
                'resources_meta': self._resources_meta,
                'group_relationships': group_relationships
            }

            temp_file = f"{self._cache_file}.tmp"
            backup_file = f"{self._cache_file}.bak"

            # Write to temp file first
            self.debug("Writing cache to temporary file")
            with open(temp_file, 'w') as f:
                json.dump(cache_data, f)

            # Create backup of existing cache if it exists
            if os.path.exists(self._cache_file):
                try:
                    os.replace(self._cache_file, backup_file)
                    self.debug("Created backup of existing cache")
                except Exception as e:
                    self.debug(f"Failed to create backup: {e}")
                    # If backup fails, continue anyway
                    pass

            # Move temp file to main cache file
            os.replace(temp_file, self._cache_file)

            # Update cache info for the new cache file
            cache_size = os.path.getsize(self._cache_file)
            self._cache_info = {
                'size': cache_size/1024,
                'age': 0  # Fresh data
            }
            self.debug(f"Cache saved successfully (size: {format_size_kb(cache_size)}KB)")

        except Exception as e:
            self.debug(f"Failed to save cache: {e}")
            print(f"Error saving cache: {e}", file=sys.stderr)

            # Try to clean up temp file if it exists
            try:
                if os.path.exists(temp_file):
                    os.unlink(temp_file)
                    self.debug("Cleaned up temporary cache file")
            except Exception as cleanup_error:
                self.debug(f"Failed to clean up temporary file: {cleanup_error}")

            # Keep existing cache_info if available, otherwise mark as fresh
            if not self._cache_info:
                self._cache_info = {
                    'size': 0,
                    'age': 0  # Fresh data
                }

    def _should_refresh_cache(self):
        """Check if we should refresh the cache"""
        try:
            if os.path.exists(self._cache_file):
                mtime = os.path.getmtime(self._cache_file)
                age = time.time() - mtime
                should_refresh = age > self._cache_ttl

                if should_refresh:
                    self.debug(f"Cache has expired (age: {age/60:.1f}min, TTL: {self._cache_ttl/60:.1f}min)")
                else:
                    self.debug(f"Cache is still valid (age: {age/60:.1f}min, TTL: {self._cache_ttl/60:.1f}min)")

                return should_refresh
            else:
                self.debug("No cache file exists, refresh needed")
        except Exception as e:
            self.debug(f"Error checking cache freshness: {e}")
        return True

    def _convert_for_cache(self, obj):
        """Convert dynamic client objects to JSON-serializable format for caching"""
        if hasattr(obj, 'to_dict'):
            return self._convert_for_cache(obj.to_dict())
        elif isinstance(obj, (list, tuple)):
            return [self._convert_for_cache(item) for item in obj]
        elif isinstance(obj, dict):
            return {k: self._convert_for_cache(v) for k, v in obj.items()}
        elif isinstance(obj, set):
            return list(obj)
        return obj

    def get_crds(self):
        """Get CRDs with caching"""
        if self._crds is None or self._should_refresh_cache():
            try:
                # Try to load from cache first
                if self._load_cache():
                    self.debug(f"Using cached CRDs (age: {self._cache_info['age']:.1f}min)")
                else:
                    self.debug("Cache not available or expired, fetching fresh data")
                    self.debug("Calling API: GET /apis/apiextensions.k8s.io/v1/customresourcedefinitions")
                    crd_api = self._client.resources.get(
                        api_version='apiextensions.k8s.io/v1',
                        kind='CustomResourceDefinition'
                    )
                    crds = crd_api.get()
                    self.debug("API call completed: GET /apis/apiextensions.k8s.io/v1/customresourcedefinitions")

                    # Ensure we convert the items to dictionaries properly
                    if hasattr(crds, 'items'):
                        items = [self._convert_for_cache(item) for item in crds.items]
                        self._crds = {'items': items}
                    else:
                        self._crds = self._convert_for_cache(crds)

                    # Save cache and update cache info
                    self._save_cache()
                    self.debug("Fresh data cached successfully")
            except urllib3.exceptions.MaxRetryError as e:
                # Re-raise MaxRetryError to be caught by the main function
                self.debug(f"MaxRetryError during CRD operation: {e}")
                raise
            except Exception as e:
                error_msg = f"Failed to get CRDs: {str(e)}"
                if error_msg not in self._errors:
                    self._errors.add(error_msg)
                    print(error_msg, file=sys.stderr)
                self.debug(f"Error during CRD operation: {e}")
                # Keep existing cache_info if available
                if not self._cache_info:
                    self.debug("No cache info available, marking as fresh data")
                    self._cache_info = {
                        'size': 0,
                        'age': 0  # Fresh data
                    }
                self._crds = {'items': []}
        return self._crds

    def get_resource(self, api_version, kind):
        """Get API resource with caching"""
        key = f"{api_version}/{kind}"
        self.debug(f"Preparing API call for resource: {key}")

        # First check if we have the actual resource object
        if key in self._resources:
            self.debug(f"Using cached resource for: {key}")
            return self._resources[key]

        try:
            # If we have cached metadata and it's still valid, recreate the resource
            if key in self._resources_meta and not self._should_refresh_cache():
                meta = self._resources_meta[key]

                # Create a new DynamicClient resource from cached metadata
                try:
                    resource = self._client.resources.get(
                        api_version=meta['api_version'],
                        kind=meta['kind']
                    )
                    self._resources[key] = resource
                    return resource
                except Exception:
                    # If that fails, try alternate format
                    try:
                        resource = self._client.resources.get(
                            group=meta['group'],
                            version=meta['version'],
                            kind=meta['kind']
                        )
                        self._resources[key] = resource
                        return resource
                    except Exception:
                        # Failed to recreate from cache, fall through to fresh fetch
                        pass

            # If we get here, we need to fetch fresh resource metadata
            if '/' in api_version:
                group, version = api_version.split('/')
            else:
                group, version = '', api_version

            # Try both ways to get the resource
            try:
                if group:
                    self.debug(f"Calling API: GET /apis/{group}/{version}")
                else:
                    self.debug(f"Calling API: GET /api/{version}")
                resource = self._client.resources.get(
                    api_version=api_version,
                    kind=kind
                )
            except Exception:
                resource = self._client.resources.get(
                    group=group,
                    version=version,
                    kind=kind
                )
            self.debug(f"API call completed for resource: {key}")

            # Cache both the resource object and its metadata
            self._resources[key] = resource
            self._resources_meta[key] = {
                'api_version': api_version,
                'kind': kind,
                'group': group,
                'version': version,
                'namespaced': getattr(resource, 'namespaced', False),
                'verbs': getattr(resource, 'verbs', []),
                'singular_name': getattr(resource, 'singular_name', ''),
                'plural': getattr(resource, 'plural', ''),
            }
            self._save_cache()
            return resource

        except Exception as e:
            error_msg = f"Failed to get resource {key}: {str(e)}"
            if error_msg not in self._errors:
                self._errors.add(error_msg)
                print(error_msg, file=sys.stderr)
            return None

    def _guess_related_groups(self, group):
        """Guess related groups based on common patterns"""
        return set()  # No more guessing of related groups

    def _add_group_relationship(self, source_group, target_group):
        """Track relationships between groups for prefetching"""
        if source_group not in self._group_relationships:
            self._group_relationships[source_group] = set()
        self._group_relationships[source_group].add(target_group)

    def _prefetch_related_groups(self, group, version):
        """Prefetch all related groups to minimize API calls"""
        # Disabled prefetching to avoid unnecessary API calls
        pass

    def get_group_instances(self, group, version, kinds=None, namespace=None, name=None):
        """Get instances for a group/version with caching and filtering

        Args:
            group: API group
            version: API version
            kinds: Optional list of kinds to fetch (if None, fetch all kinds)
            namespace: Optional namespace to filter by
            name: Optional name to filter by

        Returns:
            Dictionary of instances by kind
        """
        key = f"{group}/{version}"
        cache_key = key

        # If we're requesting specific kinds/namespace/name, we need to check if we have the full data first
        filtered_request = kinds is not None or namespace is not None or name is not None

        if filtered_request:
            # Check if we already have the full data for this group/version
            if key in self._group_instances:
                self.debug(f"Using cached data for {key} with filtering")
                return self._filter_instances(self._group_instances[key], kinds, namespace, name)

        # If we don't have the data or we're requesting the full set
        if key not in self._group_instances and key not in self._group_discovery_in_progress:
            try:
                self._group_discovery_in_progress.add(key)
                self.debug(f"Starting discovery for group/version: {key}")

                # Get all CRDs for this group/version
                crds = self.get_crds()
                instances = {}

                # Filter CRDs by group and version
                group_crds = [
                    crd for crd in crds['items']
                    if (crd.get('spec', {}).get('group') == group and
                        any(v.get('name') == version for v in crd.get('spec', {}).get('versions', [])))
                ]

                # Further filter by kinds if specified
                if kinds:
                    group_crds = [
                        crd for crd in group_crds
                        if crd.get('spec', {}).get('names', {}).get('kind') in kinds
                    ]

                # Now fetch instances for the filtered CRDs
                for crd in group_crds:
                    try:
                        kind = crd.get('spec', {}).get('names', {}).get('kind')
                        if not kind:
                            continue

                        api_version = f"{group}/{version}"
                        self.debug(f"Fetching instances for: {api_version}/{kind}")
                        resource = self.get_resource(api_version, kind)
                        if not resource:
                            continue

                        is_namespaced = crd.get('spec', {}).get('scope') == 'Namespaced'
                        try:
                            # Apply namespace filter if provided and resource is namespaced
                            fetch_namespace = namespace if namespace and is_namespaced else ''

                            # Apply name filter if provided
                            field_selector = None
                            if name:
                                field_selector = f"metadata.name={name}"
                                self.debug(f"Applying field selector: {field_selector}")

                            self.debug(f"Calling API: GET {fetch_namespace+'/' if fetch_namespace else ''}{'namespaces/' if is_namespaced else ''}{api_version}/{kind.lower()}s")

                            # Use field_selector if provided
                            if field_selector:
                                result = resource.get(namespace=fetch_namespace, field_selector=field_selector)
                            else:
                                result = resource.get(namespace=fetch_namespace)

                            self.debug(f"API call completed for: {api_version}/{kind}")
                            if not hasattr(result, 'items'):
                                continue

                            items = [self._convert_for_cache(item) for item in result.items]
                            instances[kind] = {
                                item['metadata']['name']: item
                                for item in items if 'metadata' in item and 'name' in item['metadata']
                            }
                        except Exception as e:
                            if not str(e).startswith('404'):
                                print(f"Error listing instances for {kind}: {e}", file=sys.stderr)
                            continue

                    except Exception as e:
                        print(f"Error processing CRD {kind}: {e}", file=sys.stderr)
                        continue

                self._group_instances[key] = instances

            except Exception as e:
                print(f"Error getting group instances for {key}: {e}", file=sys.stderr)
                return {}
            finally:
                self._group_discovery_in_progress.remove(key)

        # Apply filtering if needed
        if filtered_request:
            return self._filter_instances(self._group_instances.get(key, {}), kinds, namespace, name)

        return self._group_instances.get(key, {})

    def _filter_instances(self, instances, kinds=None, namespace=None, name=None):
        """Filter instances by kind, namespace, and name

        Args:
            instances: Dictionary of instances by kind
            kinds: Optional list of kinds to filter by
            namespace: Optional namespace to filter by
            name: Optional name to filter by

        Returns:
            Filtered dictionary of instances
        """
        if not instances:
            return {}

        result = {}

        # Filter by kinds if specified
        if kinds:
            for kind in kinds:
                if kind in instances:
                    result[kind] = instances[kind]
        else:
            result = instances.copy()

        # Filter by name if specified
        if name:
            for kind, items in list(result.items()):
                result[kind] = {k: v for k, v in items.items() if k == name}
                # Remove empty kinds
                if not result[kind]:
                    del result[kind]

        # Filter by namespace if specified
        if namespace:
            for kind, items in list(result.items()):
                result[kind] = {
                    k: v for k, v in items.items() 
                    if v.get('metadata', {}).get('namespace') == namespace
                }
                # Remove empty kinds
                if not result[kind]:
                    del result[kind]

        return result

    def _discover_group_relationships(self, crds, group):
        """Discover and cache group relationships from CRD schemas"""
        for crd in crds:
            try:
                schema = crd.get('spec', {}).get('versions', [{}])[0].get('schema', {}).get('openAPIV3Schema', {})
                props = schema.get('properties', {}).get('spec', {}).get('properties', {})

                # Check resourceRef
                if 'resourceRef' in props:
                    ref_props = props['resourceRef'].get('properties', {})
                    if 'apiVersion' in ref_props:
                        api_version = ref_props['apiVersion'].get('default', '')
                        if '/' in api_version:
                            target_group, _ = api_version.split('/')
                            self._add_group_relationship(group, target_group)

                # Check resourceRefs
                if 'resourceRefs' in props:
                    items = props['resourceRefs'].get('items', {}).get('properties', {})
                    if 'apiVersion' in items:
                        api_version = items['apiVersion'].get('default', '')
                        if '/' in api_version:
                            target_group, _ = api_version.split('/')
                            self._add_group_relationship(group, target_group)

            except Exception:
                continue

        self._save_cache()

    def clear_errors(self):
        """Clear the error tracking set"""
        self._errors.clear()

    def get_instance(self, group, version, kind, name):
        """Get a specific instance using group cache with filtering

        Args:
            group: API group
            version: API version
            kind: Resource kind
            name: Resource name

        Returns:
            The resource instance or None if not found
        """
        # First try to get the instance directly from the cached group instances
        key = f"{group}/{version}"
        if key in self._group_instances and kind in self._group_instances[key] and name in self._group_instances[key][kind]:
            self.debug(f"Found {kind}/{name} in cached group instances")
            return self._group_instances[key][kind][name]

        # If not found in cache, try to fetch it with filtering
        self.debug(f"Instance {kind}/{name} not found in cache, fetching with filtering")
        instances = self.get_group_instances(group, version, kinds=[kind], name=name)
        return instances.get(kind, {}).get(name)

    def get_namespace_events(self, namespace='', resource_uid=None, resource_kind=None, resource_name=None):
        """Get events for a namespace with optional filtering by resource

        Args:
            namespace: Namespace to get events for (empty for all namespaces)
            resource_uid: Optional UID of the resource to filter events for
            resource_kind: Optional kind of the resource to filter events for
            resource_name: Optional name of the resource to filter events for

        Returns:
            Dictionary of events indexed by involved object UID
        """
        # Create a cache key that includes the filters
        cache_key = f"{namespace}:{resource_uid or ''}:{resource_kind or ''}:{resource_name or ''}"

        if cache_key not in self._namespace_events:
            try:
                field_selectors = []

                # Add field selectors for resource filtering
                if resource_uid:
                    field_selectors.append(f"involvedObject.uid={resource_uid}")
                if resource_kind:
                    field_selectors.append(f"involvedObject.kind={resource_kind}")
                if resource_name:
                    field_selectors.append(f"involvedObject.name={resource_name}")

                # Combine field selectors
                field_selector = None
                if field_selectors:
                    field_selector = ",".join(field_selectors)
                    self.debug(f"Using field selector for events: {field_selector}")

                self.debug(f"Calling API: GET /api/v1/events{f'/namespaces/{namespace}' if namespace else ''}")
                core_api = self._client.resources.get(api_version='v1', kind='Event')

                # Use field selector if provided
                if field_selector:
                    events = core_api.get(namespace=namespace, field_selector=field_selector)
                else:
                    events = core_api.get(namespace=namespace)

                self.debug(f"API call completed for events in namespace: {namespace or 'all'}")

                # Index events by involved object uid for quick lookup
                self._namespace_events[cache_key] = {}
                for event in events.items:
                    obj = event.involvedObject
                    if hasattr(obj, 'uid'):
                        if obj.uid not in self._namespace_events[cache_key]:
                            self._namespace_events[cache_key][obj.uid] = []
                        self._namespace_events[cache_key][obj.uid].append(event.to_dict())

                self.debug(f"Indexed {sum(len(events) for events in self._namespace_events[cache_key].values())} events")
            except Exception as e:
                print(f"Error fetching events for namespace {namespace}: {e}", file=sys.stderr)
                self._namespace_events[cache_key] = {}

        return self._namespace_events[cache_key]

    def get_resource_events(self, resource):
        """Get events for a specific resource using server-side filtering

        Args:
            resource: The resource to get events for

        Returns:
            List of events for the resource
        """
        if not isinstance(resource, dict):
            resource = resource.to_dict()

        namespace = resource.get('metadata', {}).get('namespace', '')
        uid = resource.get('metadata', {}).get('uid')
        kind = resource.get('kind')
        name = resource.get('metadata', {}).get('name')

        if not uid:
            self.debug(f"Resource has no UID, cannot fetch events")
            return []

        self.debug(f"Fetching events for {kind}/{name} (uid: {uid}) in namespace {namespace or 'all'}")

        # Use the new filtering capabilities to fetch only events for this resource
        events = self.get_namespace_events(
            namespace=namespace,
            resource_uid=uid,
            resource_kind=kind,
            resource_name=name
        )

        # The events are already indexed by UID, so we can just return the events for this resource
        return events.get(uid, [])

    def clear_cache(self):
        """Clear both memory and file cache"""
        self._resources = {}
        self._crds = None
        self._group_instances = {}
        self._namespace_events = {}
        self._group_relationships = {}
        self._cache_info = None  # Reset cache info

        # Remove all cache files
        for suffix in ['', '.tmp', '.bak']:
            cache_file = f"{self._cache_file}{suffix}"
            if os.path.exists(cache_file):
                try:
                    os.remove(cache_file)
                    self.debug(f"Cache file removed: {cache_file}")
                except Exception as e:
                    print(f"Error removing cache file {cache_file}: {e}", file=sys.stderr)
