"""Module for discovering Kubernetes resources and their relationships."""

import sys
from typing import Dict, List, Optional, Any, Tuple
from kubernetes.dynamic import DynamicClient
from urllib3.exceptions import MaxRetryError

from .cache import ResourceCache

def handle_resource_error(error_type: str, kind: str, name: str, api_version: str, error_msg: str, 
                         error: Exception, cache: ResourceCache) -> Dict[str, Any]:
    """Handle resource errors (403 Forbidden or 404 Not Found) in a consistent way.

    Args:
        error_type: The type of error ('forbidden' or 'notfound')
        kind: The resource kind
        name: The resource name
        api_version: The API version
        error_msg: The error message to display
        error: The original exception
        cache: The resource cache instance

    Returns:
        A placeholder resource with appropriate status conditions
    """
    # Log the error
    if error_type == 'forbidden':
        cache.debug(f"Permission denied (403) for resource reference {kind}/{name}: {error}")
        print(f"Permission denied or resource not yet created: {kind}/{name}. This might be due to an error in the composition.", file=sys.stderr)
        reason_ready = 'PermissionDenied'
        reason_synced = 'AccessError'
        message_ready = f'Permission denied for {kind}/{name}. The resource might not be created yet due to composition errors.'
        message_synced = f'Cannot access {kind}/{name}. Check the composition for errors or wait for it to be created.'
    else:  # notfound
        cache.debug(f"Resource not found (404) for resource reference {kind}/{name}: {error}")
        print(f"Resource not found: {kind}/{name}. It might not be created yet due to composition errors.", file=sys.stderr)
        reason_ready = 'NotFound'
        reason_synced = 'Missing'
        message_ready = f'Resource {kind}/{name} was not found. It might not be created yet due to composition errors.'
        message_synced = f'Resource {kind}/{name} is missing. Check the composition for errors or wait for it to be created.'

    # Create a placeholder resource with appropriate status conditions
    return {
        'kind': kind,
        'apiVersion': api_version,
        'metadata': {
            'name': name,
        },
        'status': {
            'conditions': [
                {
                    'type': 'Ready',
                    'status': 'False',
                    'reason': reason_ready,
                    'message': message_ready,
                    'lastTransitionTime': None
                },
                {
                    'type': 'Synced',
                    'status': 'False',
                    'reason': reason_synced,
                    'message': message_synced,
                    'lastTransitionTime': None
                }
            ]
        }
    }

def discover_by_category(category: str, dynamic_client: DynamicClient, cache: ResourceCache) -> List[Dict[str, Any]]:
    """Discover resources by category using DynamicClient and cache.

    Args:
        category: The category to search for (e.g., 'claim')
        dynamic_client: The Kubernetes dynamic client
        cache: The resource cache instance

    Returns:
        List of matching resources
    """
    matches = []

    try:
        # Check if we can use cached CRDs first
        crds = cache.get_crds()
        cache.debug(f"Looking for CRDs with category: {category}")

        # Process all CRDs to find those with matching categories
        for crd in crds['items']:
            spec = crd.get('spec', {})
            names = spec.get('names', {})

            # Skip CRDs without names or categories
            if not names:
                continue

            categories = names.get('categories', [])
            if not categories:
                continue

            # Check if this category matches
            if category in categories:
                group = spec.get('group', '')
                versions = spec.get('versions', [])
                if versions:
                    version = versions[0].get('name', '')
                    cache.debug(f"Found matching CRD: {names.get('kind')} in {group}/{version}")
                    matches.append({
                            'group': group,
                            'version': version,
                            'namespace': 'default',
                            'name': names.get('plural'),
                            'details': {
                                'name': names.get('plural'),
                                'singularName': names.get('singular'),
                                'namespaced': spec.get('scope') == 'Namespaced',
                                'kind': names.get('kind'),
                                'verbs': ['get', 'list'],
                                'categories': categories
                            }
                        })
        cache.debug(f"Found {len(matches)} matching CRDs")
        return matches

    except MaxRetryError:
        # Re-raise MaxRetryError to be handled by the main function
        raise
    except Exception as e:
        print(f"Error discovering resources by category: {e}", file=sys.stderr)
        return []

def discover_xr(manifest: Dict[str, Any], dynamic_client: DynamicClient, namespace: str, cache: ResourceCache) -> Optional[Dict[str, Any]]:
    """Discover XR using group-level caching.

    Args:
        manifest: The resource manifest
        dynamic_client: The Kubernetes dynamic client
        namespace: The namespace to search in
        cache: The resource cache instance

    Returns:
        The discovered XR manifest or None
    """
    if not isinstance(manifest, dict):
        manifest = manifest.to_dict()

    if 'spec' not in manifest or 'resourceRef' not in manifest['spec']:
        cache.debug("No resourceRef found in manifest spec")
        return None

    resource_ref = manifest['spec']['resourceRef']
    api_version = resource_ref.get('apiVersion', '')
    kind = resource_ref.get('kind', '')
    name = resource_ref.get('name', '')

    if not api_version or not kind or not name:
        cache.debug("Missing required fields in resourceRef")
        return None

    try:
        # Split api_version into group/version
        if '/' in api_version:
            group, version = api_version.split('/')
        else:
            group, version = '', api_version

        cache.debug(f"Looking up XR {kind}/{name} in group {group}/{version}")
        # Get the instance from cache
        result = cache.get_instance(group, version, kind, name)
        if result:
            cache.debug(f"Found XR {kind}/{name}")
        else:
            cache.debug(f"XR {kind}/{name} not found")
        return result

    except Exception as e:
        print(f"Error fetching XR manifest {kind}/{name} in namespace {namespace}: {e}", file=sys.stderr)
        return None

def list_crd_instances(crd: Dict[str, Any], dynamic_client: DynamicClient, cache: ResourceCache) -> List[Dict[str, Any]]:
    """List CRD instances using group-level caching.

    Args:
        crd: The CRD definition
        dynamic_client: The Kubernetes dynamic client
        cache: The resource cache instance

    Returns:
        List of CRD instances
    """
    try:
        group = crd['group']
        version = crd['version']
        kind = crd['details']['kind']

        cache.debug(f"Looking up instances of {kind} in {group}/{version}")
        # Get all instances for this group/version
        instances = cache.get_group_instances(group, version)
        if kind in instances:
            instance_list = list(instances[kind].values())
            cache.debug(f"Found {len(instance_list)} instances of {kind}")
            return instance_list
        cache.debug(f"No instances found for {kind}")
        return []

    except Exception as e:
        print(f"Error getting instances: {e}", file=sys.stderr)
        return []

def get_matches(claim_name: str, matches: List[Dict[str, Any]], dynamic_client: DynamicClient, cache: ResourceCache) -> List[Dict[str, Any]]:
    """Get matching claims by name.

    Args:
        claim_name: The name of the claim to match
        matches: List of CRDs to search in
        dynamic_client: The Kubernetes dynamic client
        cache: The resource cache instance

    Returns:
        List of matching claims
    """
    all_matches = []
    cache.debug(f"Looking for claim with name: {claim_name}")
    for crd in matches:
        cache.debug(f"Checking CRD group: {crd['group']}/{crd['version']}")
        instances = list_crd_instances(crd, dynamic_client, cache)
        if instances:
            for instance in instances:
                instance_name = instance.get('metadata', {}).get('name')
                cache.debug(f"Comparing {instance_name} with {claim_name}")
                if claim_name.lower() == instance_name.lower():
                    cache.debug(f"Found matching claim: {instance_name}")
                    all_matches.append(instance)
    cache.debug(f"Found {len(all_matches)} matching claims in total")
    return all_matches

def attach_events(resource: Dict[str, Any], dynamic_client: DynamicClient, cache: ResourceCache) -> None:
    """Attach events to a resource using namespace-level caching.

    Args:
        resource: The resource to attach events to
        dynamic_client: The Kubernetes dynamic client
        cache: The resource cache instance
    """
    if not isinstance(resource, dict):
        resource = resource.to_dict()

    try:
        name = resource.get('metadata', {}).get('name')
        kind = resource.get('kind')
        cache.debug(f"Checking events for {kind}/{name}")

        # Only fetch events if resource is unhealthy
        ready_status = resource.get('status', {}).get('conditions', [])
        synced_status = resource.get('status', {}).get('conditions', [])
        ready = next((condition['status'] for condition in ready_status if condition['type'] == 'Ready'), 'N/A')
        synced = next((condition['status'] for condition in synced_status if condition['type'] == 'Synced'), 'N/A')

        if ready != "True" or synced != "True":
            cache.debug(f"Resource {kind}/{name} is unhealthy (Ready={ready}, Synced={synced}), fetching events")
            events = cache.get_resource_events(resource)
            if events:
                cache.debug(f"Found {len(events)} events for {kind}/{name}")
                resource['events'] = events
            else:
                cache.debug(f"No events found for {kind}/{name}")
        else:
            cache.debug(f"Resource {kind}/{name} is healthy, skipping events")

    except Exception as e:
        print(f"Error fetching events for resource {resource.get('metadata', {}).get('name')}: {e}", file=sys.stderr)

def process_child_resources(resource_tree: Dict[str, Any], dynamic_client: DynamicClient, cache: ResourceCache) -> None:
    """Process child resources recursively with event caching.

    Args:
        resource_tree: The resource tree to process
        dynamic_client: The Kubernetes dynamic client
        cache: The resource cache instance
    """
    if resource_tree and 'resource' in resource_tree:
        name = resource_tree['resource'].get('metadata', {}).get('name')
        kind = resource_tree['resource'].get('kind')
        cache.debug(f"Processing child resource tree for {kind}/{name}")
        attach_events(resource_tree['resource'], dynamic_client, cache)
        for child in resource_tree.get('children', []):
            process_child_resources(child, dynamic_client, cache)

def discover_child_resources(
    manifest: Dict[str, Any], 
    dynamic_client: DynamicClient, 
    cache: ResourceCache,
    max_depth: int = 10,
    only_unhealthy: bool = False,
    current_depth: int = 0
) -> Dict[str, Any]:
    """Discover child resources using group-level caching with depth control.

    Args:
        manifest: The resource manifest
        dynamic_client: The Kubernetes dynamic client
        cache: The resource cache instance
        max_depth: Maximum recursion depth (default: 10)
        only_unhealthy: Only process unhealthy resources (default: False)
        current_depth: Current recursion depth (internal use)

    Returns:
        Dictionary containing the resource tree
    """
    if not isinstance(manifest, dict):
        manifest = manifest.to_dict()

    resource_name = manifest.get('metadata', {}).get('name', 'unknown')
    resource_kind = manifest.get('kind', 'unknown')

    cache.debug(f"Discovering child resources for {resource_kind}/{resource_name} (depth: {current_depth}/{max_depth})")

    # Check if we've reached the maximum recursion depth
    if current_depth >= max_depth:
        cache.debug(f"Reached maximum recursion depth ({max_depth}), stopping recursion")
        return {
            'resource': manifest,
            'children': [],
            'truncated': True  # Indicate that recursion was truncated
        }

    resource_tree = {
        'resource': manifest,
        'children': []
    }

    # Skip recursion if the resource doesn't have resourceRefs
    if 'spec' not in manifest or 'resourceRefs' not in manifest['spec']:
        cache.debug("No resourceRefs found in manifest spec")
        return resource_tree

    # Check if we should process this resource based on its health
    if only_unhealthy and current_depth > 0:  # Don't skip the root resource
        from xplorer.utils import check_resource_health

        # If the resource is healthy (not unhealthy), skip it
        if not check_resource_health(manifest, cache):
            cache.debug(f"Skipping healthy resource {resource_kind}/{resource_name}")
            return resource_tree

    resource_refs = manifest['spec'].get('resourceRefs', [])
    cache.debug(f"Found {len(resource_refs)} resource references")

    for ref in resource_refs:
        try:
            api_version = ref.get('apiVersion', '')
            kind = ref.get('kind', '')
            name = ref.get('name', '')

            if not api_version or not kind or not name:
                cache.debug(f"Skipping invalid resource reference: missing required fields")
                continue

            cache.debug(f"Looking up {kind}/{name}")

            # Skip fetching CRDs themselves (we only care about instances, not definitions)
            if kind == "CustomResourceDefinition" or api_version.startswith("apiextensions.k8s.io/"):
                cache.debug(f"Skipping CRD {kind}/{name} ({api_version})")
                continue

            # Split api_version for the group cache
            group = ''
            version = api_version
            if '/' in api_version:
                group, version = api_version.split('/')

            # Try to get the instance using the cache first
            result = None
            if group and version and kind and name:
                result = cache.get_instance(group, version, kind, name)

            # If not found in cache, try the traditional approach
            if not result:
                try:
                    # Get the resource type
                    resource = cache.get_resource(api_version, kind)
                    if resource:
                        cache.debug(f"Trying traditional approach for {kind}/{name}")
                        # Try to get the instance using the resource directly
                        try:
                            result = resource.get(name=name)
                            if result:
                                cache.debug(f"Found {kind}/{name} using traditional approach")
                                # Convert to dict if needed
                                if hasattr(result, 'to_dict'):
                                    result = result.to_dict()
                        except Exception as e:
                            # Check if this is a 403 error (Forbidden) or 404 error (Not Found)
                            error_msg = str(e)
                            if "403" in error_msg or "forbidden" in error_msg.lower():
                                # Just log the error, placeholder will be created later if needed
                                cache.debug(f"Permission denied (403) for {kind}/{name}: {e}")
                            elif "404" in error_msg or "not found" in error_msg.lower():
                                # Just log the error, placeholder will be created later if needed
                                cache.debug(f"Resource not found (404) for {kind}/{name}: {e}")
                            else:
                                cache.debug(f"Error getting {kind}/{name} using traditional approach: {e}")
                except Exception as e:
                    cache.debug(f"Error getting resource type {kind}: {e}")

            if result:
                cache.debug(f"Found {kind}/{name}")
                # Recursively discover child resources with incremented depth
                child_tree = discover_child_resources(
                    result, 
                    dynamic_client, 
                    cache,
                    max_depth=max_depth,
                    only_unhealthy=only_unhealthy,
                    current_depth=current_depth + 1
                )
                resource_tree['children'].append(child_tree)
            else:
                # Resource not found, create a placeholder
                resource = cache.get_resource(api_version, kind)
                if not resource:
                    cache.debug(f"Resource type {kind} not found")
                    # Create a custom placeholder for missing resource type
                    missing_resource = {
                        'kind': kind,
                        'apiVersion': api_version,
                        'metadata': {
                            'name': name,
                        },
                        'status': {
                            'conditions': [
                                {
                                    'type': 'Ready',
                                    'status': 'False',
                                    'reason': 'NotFound',
                                    'message': f'Resource type {kind} was not found',
                                    'lastTransitionTime': None
                                },
                                {
                                    'type': 'Synced',
                                    'status': 'False',
                                    'reason': 'Missing',
                                    'message': f'Resource type {kind} does not exist',
                                    'lastTransitionTime': None
                                }
                            ]
                        }
                    }
                else:
                    # Resource type exists but instance not found
                    cache.debug(f"Resource {kind}/{name} not found")
                    # Use the helper function for consistent error handling
                    missing_resource = handle_resource_error('notfound', kind, name, api_version, 
                                                           f"Resource {kind}/{name} not found", None, cache)

                child_tree = {'resource': missing_resource, 'children': []}
                resource_tree['children'].append(child_tree)

        except Exception as e:
            error_msg = str(e)
            # Check if this is a 403 error (Forbidden) or 404 error (Not Found)
            if "403" in error_msg or "forbidden" in error_msg.lower():
                # Handle forbidden error
                missing_resource = handle_resource_error('forbidden', kind, name, api_version, error_msg, e, cache)
                child_tree = {'resource': missing_resource, 'children': []}
                resource_tree['children'].append(child_tree)
            elif "404" in error_msg or "not found" in error_msg.lower():
                # Handle not found error
                missing_resource = handle_resource_error('notfound', kind, name, api_version, error_msg, e, cache)
                child_tree = {'resource': missing_resource, 'children': []}
                resource_tree['children'].append(child_tree)
            else:
                # For other errors, log them but don't show the full stack trace
                print(f"Error processing resource reference: {error_msg}", file=sys.stderr)
                cache.debug(f"Error processing resource reference: {e}")

    cache.debug(f"Found {len(resource_tree['children'])} child resources")
    return resource_tree
