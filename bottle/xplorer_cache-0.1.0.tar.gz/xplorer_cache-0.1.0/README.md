# Xplorer-Cache

[![Test Coverage](https://codecov.io/gh/xplorer/xplorer-cache/branch/main/graph/badge.svg)](https://codecov.io/gh/xplorer/xplorer-cache)

Xplorer-Cache is a specialized Python server application designed to enhance the Xplorer project by efficiently storing, managing, and proxying Kubernetes cluster data. This tool aims to reduce network traffic to Kubernetes clusters during development, testing, and debugging sessions by providing a configurable proxy that can serve either live or cached API data used by the main application.

Built with FastAPI and SQLAlchemy for high performance and flexibility.

## Features

- **Kubernetes API Replication**: Acts as a drop-in replacement for a Kubernetes API server
- **Configurable Endpoint Proxying**: Configure endpoints to use live data, cached data, or a mix of both
- **Local Database Storage**: Efficiently store and retrieve Kubernetes resources
- **Cache Management**: Tools for viewing and managing cached data
- **Hybrid Mode Operation**: Seamlessly mix cached and live data based on endpoint configuration
- **Identifiable Process**: Server runs with the name "xplorer-cache" in the process list instead of "python"

## Installation

### From PyPI

```bash
# Create a virtual environment
uv venv

# Activate the virtual environment
source .venv/bin/activate

# Install the package
uv pip install xplorer-cache
```

### From Source

```bash
# Clone the repository
git clone https://github.com/xplorer/xplorer-cache.git
cd xplorer-cache

# Create a virtual environment
uv venv

# Activate the virtual environment
source .venv/bin/activate

# Install the package in development mode
uv pip install -e .
```

## Usage

### Initialization

Before using Xplorer-Cache, you need to initialize it:

```bash
xplorer-cache init
```

This will create the necessary configuration files and database.

### Starting the Server

To start the Xplorer-Cache server:

```bash
xplorer-cache start [--port PORT] [--host HOST]
```

By default, the server will listen on `127.0.0.1:8080`.

### Stopping the Server

To stop the Xplorer-Cache server:

```bash
xplorer-cache stop
```

### Checking Server Status

To check the status of the Xplorer-Cache server:

```bash
xplorer-cache status
```

### Managing Endpoint Configurations

To list current endpoint configurations:

```bash
xplorer-cache config list
```

To set the mode for a specific endpoint:

```bash
xplorer-cache config set <endpoint> <mode>
```

Where `<mode>` is one of:
- `live`: Proxy requests directly to the Kubernetes cluster
- `cache`: Serve requests from the local cache
- `hybrid`: Try to serve from cache first, then fall back to live cluster if not found

Example:

```bash
xplorer-cache config set /api/v1/pods cache
xplorer-cache config set /api/v1/namespaces live
xplorer-cache config set /apis/apps/v1/deployments hybrid
```

### Managing Cache

To list cached resources:

```bash
xplorer-cache cache list [resource]
```

To show details of a cached resource:

```bash
xplorer-cache cache show <resource> [--name NAME] [--namespace NAMESPACE]
```

To clear specific resources from cache:

```bash
xplorer-cache cache clear [resource]
```

### Exporting and Importing Cache

To export the cache to a file:

```bash
xplorer-cache export <file>
```

To import the cache from a file:

```bash
xplorer-cache import <file>
```

## Configuration

Xplorer-Cache uses a YAML configuration file located at `~/.xplorer-cache/config.yaml`. You can customize various settings including:

- Database connection
- Server port
- Endpoint routing rules
- Cache expiration policies
- Authentication settings

Example configuration:

```yaml
server:
  host: 127.0.0.1
  port: 8080
  debug: false
database:
  type: sqlite
  path: ~/.xplorer-cache/cache.db
cache:
  expiration: 3600  # 1 hour in seconds
  max_size: 1024    # 1 GB in MB
endpoints:
  default_mode: live
  rules:
    - endpoint: /api/v1/pods
      mode: cache
    - endpoint: /api/v1/namespaces
      mode: live
    - endpoint: /apis/apps/v1/deployments
      mode: hybrid
kubernetes:
  use_kubeconfig: true
  kubeconfig_path: ~/.kube/config
  context: null
```

## Development

### Setup Development Environment

```bash
# Clone the repository
git clone https://github.com/xplorer/xplorer-cache.git
cd xplorer-cache

# Create a virtual environment
uv venv

# Activate the virtual environment
source .venv/bin/activate

# Install development dependencies
uv pip install -r requirements.txt

# Install the package in development mode
uv pip install -e .
```

### Running Tests

```bash
# Run all tests
pytest

# Run a specific test file
pytest tests/test_cli.py
```

See the [tests README](tests/README.md) for more information on testing.

### Project Structure

- `xplorer_cache/`: Main package directory
  - `__init__.py`: Package initialization
  - `__main__.py`: Entry point for running as a module
  - `cli.py`: Command-line interface implementation
  - `config.py`: Configuration management
  - `cache.py`: Cache management
  - `server.py`: API server implementation
  - `api.py`: Kubernetes API proxy implementation
- `tests/`: Test directory
  - `test_cli.py`: Tests for CLI functionality
- `setup.py`: Package setup script
- `requirements.txt`: Package dependencies
