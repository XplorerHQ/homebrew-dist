"""
Property-based tests for the different caching modes (live, cache, hybrid).

These tests use Hypothesis to generate various inputs and verify the invariants
that should hold true for the caching mode functionality regardless of the input values.
"""

import pytest
# No need for unittest.mock imports as we're using pytest-mock
from hypothesis import given, strategies as st, settings, HealthCheck
from xplorer_cache.config import Config


# Define strategies for caching modes and endpoints
caching_modes = st.sampled_from(['live', 'cache', 'hybrid'])
endpoint_paths = st.text(alphabet="abcdefghijklmnopqrstuvwxyz/-_", min_size=1, max_size=50).map(lambda s: f"/{s}")


@settings(suppress_health_check=[HealthCheck.function_scoped_fixture])
@given(
    endpoint=endpoint_paths,
    mode=caching_modes
)
def test_set_get_endpoint_mode_property(endpoint, mode):
    """
    Property: Setting any endpoint to any valid mode should be retrievable with get_endpoint_mode.
    
    This tests that the configuration system correctly stores and retrieves endpoint mode settings.
    """
    config = Config()
    
    # Mock the get and set methods to isolate the test
    original_get = config.get
    original_set = config.set
    
    try:
        # Create a test environment with a mock storage
        rules_storage = []
        
        def mock_get(key, default=None):
            if key == 'endpoints.rules':
                return rules_storage
            elif key == 'endpoints.default_mode':
                return 'hybrid'  # This is the new default
            return default
            
        def mock_set(key, value):
            nonlocal rules_storage
            if key == 'endpoints.rules':
                rules_storage = value
        
        config.get = mock_get
        config.set = mock_set
        
        # Set the endpoint mode
        config.set_endpoint_mode(endpoint, mode)
        
        # Get the endpoint mode
        retrieved_mode = config.get_endpoint_mode(endpoint)
        
        # Verify that the mode was correctly set and retrieved
        assert retrieved_mode == mode, f"Expected mode {mode} for endpoint {endpoint}, got {retrieved_mode}"
        
        # Verify that the rule was added to the rules storage
        rule_found = False
        for rule in rules_storage:
            if rule.get('endpoint') == endpoint:
                assert rule.get('mode') == mode, f"Rule in storage has incorrect mode: {rule.get('mode')}"
                rule_found = True
                break
        
        assert rule_found, f"Rule for endpoint {endpoint} not found in storage"
        
    finally:
        # Restore the original methods
        config.get = original_get
        config.set = original_set


@settings(suppress_health_check=[HealthCheck.function_scoped_fixture])
@given(
    endpoint=endpoint_paths,
    existing_mode=caching_modes,
    new_mode=caching_modes
)
def test_update_endpoint_mode_property(endpoint, existing_mode, new_mode):
    """
    Property: Updating an existing endpoint mode should correctly change the mode.
    
    This tests that the configuration system correctly updates existing endpoint mode settings.
    """
    config = Config()
    
    # Mock the get and set methods to isolate the test
    original_get = config.get
    original_set = config.set
    
    try:
        # Create a test environment with a mock storage
        rules_storage = [{'endpoint': endpoint, 'mode': existing_mode}]
        
        def mock_get(key, default=None):
            if key == 'endpoints.rules':
                return rules_storage
            elif key == 'endpoints.default_mode':
                return 'hybrid'  # This is the new default
            return default
            
        def mock_set(key, value):
            nonlocal rules_storage
            if key == 'endpoints.rules':
                rules_storage = value
        
        config.get = mock_get
        config.set = mock_set
        
        # Update the endpoint mode
        config.set_endpoint_mode(endpoint, new_mode)
        
        # Get the endpoint mode
        retrieved_mode = config.get_endpoint_mode(endpoint)
        
        # Verify that the mode was correctly updated and retrieved
        assert retrieved_mode == new_mode, f"Expected mode {new_mode} for endpoint {endpoint}, got {retrieved_mode}"
        
        # Verify that the rule was updated in the rules storage
        rule_found = False
        for rule in rules_storage:
            if rule.get('endpoint') == endpoint:
                assert rule.get('mode') == new_mode, f"Rule in storage has incorrect mode: {rule.get('mode')}"
                rule_found = True
                break
        
        assert rule_found, f"Rule for endpoint {endpoint} not found in storage"
        
    finally:
        # Restore the original methods
        config.get = original_get
        config.set = original_set


@settings(suppress_health_check=[HealthCheck.function_scoped_fixture])
@given(
    endpoint=endpoint_paths,
    default_mode=caching_modes
)
def test_default_endpoint_mode_property(endpoint, default_mode):
    """
    Property: When no specific rule exists for an endpoint, the default mode should be used.
    
    This tests that the configuration system correctly falls back to the default mode when no specific rule exists.
    """
    config = Config()
    
    # Mock the get method to isolate the test
    original_get = config.get
    
    try:
        # Create a test environment with a mock storage that doesn't contain our test endpoint
        def mock_get(key, default=None):
            if key == 'endpoints.rules':
                return [{'endpoint': '/some-other-endpoint', 'mode': 'live'}]
            elif key == 'endpoints.default_mode':
                return default_mode
            return default
        
        config.get = mock_get
        
        # Get the endpoint mode
        retrieved_mode = config.get_endpoint_mode(endpoint)
        
        # Verify that the default mode was used
        assert retrieved_mode == default_mode, f"Expected default mode {default_mode} for endpoint {endpoint}, got {retrieved_mode}"
        
    finally:
        # Restore the original method
        config.get = original_get


@settings(suppress_health_check=[HealthCheck.function_scoped_fixture])
@given(
    endpoint=endpoint_paths,
    wildcard_endpoint=st.text(alphabet="abcdefghijklmnopqrstuvwxyz/-_", min_size=1, max_size=20).map(lambda s: f"/{s}*"),
    mode=caching_modes
)
def test_wildcard_endpoint_mode_property(endpoint, wildcard_endpoint, mode):
    """
    Property: Endpoints matching a wildcard rule should use the mode from that rule.
    
    This tests that the configuration system correctly handles wildcard endpoint rules.
    """
    config = Config()
    
    # Only test cases where the endpoint matches the wildcard
    if not endpoint.startswith(wildcard_endpoint[:-1]):
        return
    
    # Mock the get method to isolate the test
    original_get = config.get
    
    try:
        # Create a test environment with a mock storage that contains a wildcard rule
        def mock_get(key, default=None):
            if key == 'endpoints.rules':
                return [{'endpoint': wildcard_endpoint, 'mode': mode}]
            elif key == 'endpoints.default_mode':
                return 'hybrid'  # This is the new default
            return default
        
        config.get = mock_get
        
        # Get the endpoint mode
        retrieved_mode = config.get_endpoint_mode(endpoint)
        
        # Verify that the wildcard rule's mode was used
        assert retrieved_mode == mode, f"Expected wildcard rule mode {mode} for endpoint {endpoint}, got {retrieved_mode}"
        
    finally:
        # Restore the original method
        config.get = original_get