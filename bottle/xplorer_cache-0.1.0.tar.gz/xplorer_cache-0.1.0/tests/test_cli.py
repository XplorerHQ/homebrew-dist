"""
Tests for the CLI functionality.
"""

import os
import tempfile
import shutil

import pytest
from click.testing import CliRunner

from xplorer_cache.cli import cli, main


@pytest.fixture
def runner():
    """Fixture for CLI runner."""
    return CliRunner()


@pytest.fixture
def temp_dir():
    """Fixture for temporary directory."""
    temp_dir = tempfile.mkdtemp()
    yield temp_dir
    # Clean up temp directory
    shutil.rmtree(temp_dir)


def test_cli_version(runner):
    """Test the CLI version command."""
    result = runner.invoke(cli, ["--version"])
    assert result.exit_code == 0
    assert "version" in result.output.lower()


def test_cli_help(runner):
    """Test the CLI help command."""
    result = runner.invoke(cli, ["--help"])
    assert result.exit_code == 0
    assert "usage" in result.output.lower()


def test_init_command(mocker, runner):
    """Test the init command."""
    # Mock the Config class
    mock_config = mocker.patch("xplorer_cache.cli_logic.Config")
    mock_config_instance = mocker.MagicMock()
    mock_config.return_value = mock_config_instance

    result = runner.invoke(cli, ["init"])
    assert result.exit_code == 0
    assert "initializing" in result.output.lower()
    assert "complete" in result.output.lower()


def test_start_command(mocker, runner):
    """Test the start command."""
    # First, let's test a simplified version that just confirms the command works
    mock_is_server_running = mocker.patch("xplorer_cache.cli.is_server_running", return_value=False)
    mock_reset_cache = mocker.patch("xplorer_cache.cli.reset_cache_if_requested", return_value=(True, None))
    mock_update_mode = mocker.patch("xplorer_cache.cli.update_cache_mode", return_value=(True, None))
    mock_start_server = mocker.patch("xplorer_cache.cli.start_server", return_value=(True, "Server started successfully", 12345))
    
    # Invoke the command
    result = runner.invoke(cli, ["start", "--daemon"])
    
    # Check the output contains expected text
    assert result.exit_code == 0
    assert "starting" in result.output.lower()
    assert "server started successfully" in result.output.lower()


def test_stop_command(mocker, runner):
    """Test the stop command."""
    # Use mocker to patch modules used by click command
    mock_is_server_running = mocker.patch("xplorer_cache.cli.is_server_running")
    mock_read_server_info = mocker.patch("xplorer_cache.cli.read_server_info")
    mock_stop_server = mocker.patch("xplorer_cache.cli.stop_server")
    
    # Set up mocks
    mock_is_server_running.return_value = True
    mock_read_server_info.return_value = {"pid": 12345, "host": "127.0.0.1", "port": 4433}
    mock_stop_server.return_value = (True, "Server stopped gracefully via API")
    
    # Invoke the command with mocks in place
    result = runner.invoke(cli, ["stop"])
    
    # Check the output and exit code
    assert result.exit_code == 0
    assert "stopping" in result.output.lower()
    assert "server stopped" in result.output.lower()
    
    # Verify that stop_server was called
    mock_stop_server.assert_called_once()


def test_status_command_running(mocker, runner):
    """Test the status command when server is running."""
    # Use mocker to patch modules used by click command
    mock_get_server_status = mocker.patch("xplorer_cache.cli.get_server_status")
    
    # Set up mock to return a status with server running but missing PID file
    mock_get_server_status.return_value = {
        "running": True,
        "server": {
            "host": "127.0.0.1",
            "port": 4433,
            "pid": None,
            "pid_file": "Missing"
        },
        "database": {"status": "Connected", "type": "sqlite", "path": "~/.xplorer-cache/cache.db"},
        "cache": {"status": "Active"},
        "cache_stats": {"total_resources": 0, "cache_size": "0 MB", "hit_rate": "0%"}
    }
    
    # Invoke the command with mocks in place
    result = runner.invoke(cli, ["status"])
    
    # Check the output and exit code
    assert result.exit_code == 0
    assert "status" in result.output.lower()
    assert "running" in result.output.lower()
    assert "pid file missing" in result.output.lower()
    
    # Verify that get_server_status was called
    mock_get_server_status.assert_called_once()


def test_status_command_stopped(mocker, runner):
    """Test the status command when server is stopped."""
    # Use mocker to patch modules used by click command
    mock_get_server_status = mocker.patch("xplorer_cache.cli.get_server_status")
    
    # Set up mock to return a status with server stopped
    mock_get_server_status.return_value = {
        "running": False,
        "server": None,
        "database": {"status": "Disconnected"},
        "cache": {"status": "Inactive"},
        "cache_stats": None
    }
    
    # Invoke the command with mocks in place
    result = runner.invoke(cli, ["status"])
    
    # Check the output and exit code
    assert result.exit_code == 0
    assert "status" in result.output.lower()
    assert "stopped" in result.output.lower()
    
    # Verify that get_server_status was called
    mock_get_server_status.assert_called_once()


def test_cache_list_command(mocker, runner):
    """Test the cache list command."""
    # Directly mock the list_cache function in the CLI module
    sample_data = [{"resource": "namespaces", "count": "5", "last_updated": "2023-01-01 12:00:00"}]
    
    # Mock the list_cache function
    mock_list_cache = mocker.patch("xplorer_cache.cli.list_cache", return_value=sample_data)
    
    # Invoke the command with mocks in place
    result = runner.invoke(cli, ["cache", "list"])
    
    # Verify output
    assert result.exit_code == 0
    assert "cached resources" in result.output.lower()
    
    # Verify the function was called with the right args
    mock_list_cache.assert_called_once_with(None)


def test_config_list_command(mocker, runner):
    """Test the config list command."""
    # Mock the Config class
    mock_config = mocker.patch("xplorer_cache.cli_logic.Config")
    mock_config_instance = mocker.MagicMock()
    mock_config_instance.get_all_endpoint_rules.return_value = []
    mock_config.return_value = mock_config_instance

    result = runner.invoke(cli, ["config", "list"])
    assert result.exit_code == 0
    assert "endpoint configurations" in result.output.lower()


def test_config_set_command(mocker, runner):
    """Test the config set command."""
    # Mock the Config class
    mock_config = mocker.patch("xplorer_cache.cli_logic.Config")
    mock_config_instance = mocker.MagicMock()
    mock_config.return_value = mock_config_instance

    result = runner.invoke(cli, ["config", "set", "/api/v1/pods", "cache"])
    assert result.exit_code == 0
    assert "setting" in result.output.lower()
    assert "mode" in result.output.lower()

    # Note: The current implementation doesn't call set_endpoint_mode yet
    # This is marked with a TODO in the cli.py file


def test_main_function(mocker):
    """Test the main function."""
    # Patch sys.exit to prevent the test from exiting
    mock_exit = mocker.patch("sys.exit")
    # Patch the cli function to prevent it from running
    mock_cli = mocker.patch("xplorer_cache.cli.cli")
    main()
    mock_cli.assert_called_once()
