"""
Property-based tests for the proxy router functionality.

These tests focus specifically on the proxy router's routing functionality,
testing it in isolation from the cache system.

Note: Path parsing tests have been moved to tests/kubernetes/test_path_parser_property.py
"""

import json
import pytest
from hypothesis import given, strategies as st, settings, HealthCheck, example

# Path parsing functionality has been moved to the kubernetes module
# Tests for this functionality are now in tests/kubernetes/test_path_parser_property.py