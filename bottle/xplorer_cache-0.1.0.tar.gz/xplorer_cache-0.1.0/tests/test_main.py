"""
Tests for the main FastAPI application.
"""

from fastapi.testclient import TestClient

from xplorer_cache.main import app


def test_root_endpoint():
    """Test the root endpoint returns the expected response."""
    client = TestClient(app)
    response = client.get("/")
    assert response.status_code == 200
    assert response.json() == {"message": "Xplorer-Cache is running"}