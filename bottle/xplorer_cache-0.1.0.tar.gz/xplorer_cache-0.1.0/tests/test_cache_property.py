"""
Property-based tests for the cache functionality.

These tests focus specifically on the cache module's functionality, testing it in isolation
to ensure proper storage and retrieval of Kubernetes resources.
"""

import json
import os
import tempfile
import time
import pytest
from hypothesis import given, strategies as st, settings, HealthCheck, example, assume

from xplorer_cache.cache import Cache
from xplorer_cache.config import Config

# Define strategies for generating Kubernetes resources
resource_names = st.text(min_size=1, max_size=30, alphabet="abcdefghijklmnopqrstuvwxyz0123456789-")
namespaces = st.sampled_from(["default", "kube-system", "app", "test"])
api_versions = st.sampled_from(["v1", "apps/v1", "networking.k8s.io/v1", "batch/v1"])
kinds = st.sampled_from(["Pod", "Service", "Deployment", "ConfigMap", "Secret", "Ingress"])

# Cache key strategy
cache_keys = st.one_of(
    # Core API paths - /api/v1/...
    st.builds(
        lambda resource, namespace, name: f"api/v1/namespaces/{namespace}/{resource}/{name}" if name else f"api/v1/namespaces/{namespace}/{resource}",
        resource=st.sampled_from(["pods", "services", "configmaps", "secrets"]),
        namespace=namespaces,
        name=st.one_of(st.none(), resource_names)
    ),
    # API group paths - /apis/apps/v1/...
    st.builds(
        lambda resource, namespace, name: f"apis/apps/v1/namespaces/{namespace}/{resource}/{name}" if name else f"apis/apps/v1/namespaces/{namespace}/{resource}",
        resource=st.sampled_from(["deployments", "statefulsets", "daemonsets"]),
        namespace=namespaces,
        name=st.one_of(st.none(), resource_names)
    )
)

# Generate sample Kubernetes resources for testing
def generate_k8s_resource(kind, name, namespace=None, api_version="v1"):
    """Generate a sample Kubernetes resource with the given parameters."""
    resource = {
        "apiVersion": api_version,
        "kind": kind,
        "metadata": {
            "name": name,
            "uid": f"test-uid-{name}",
            "resourceVersion": "1"
        }
    }
    if namespace:
        resource["metadata"]["namespace"] = namespace
    return resource


@settings(suppress_health_check=[HealthCheck.function_scoped_fixture])
@given(
    cache_key=cache_keys,
    resource_name=resource_names,
    namespace=namespaces,
    api_version=api_versions,
    kind=kinds
)
def test_cache_store_retrieve_property(test_cache, cache_key, resource_name, namespace, api_version, kind):
    """
    Property: The cache should correctly store and retrieve resources.
    
    This test verifies that:
    1. Any resource stored in the cache can be retrieved correctly
    2. The cache preserves all resource details
    """
    # Generate a unique cache key to avoid collisions with other tests
    unique_cache_key = f"test_{cache_key}_{resource_name}"
    
    # Generate a test resource
    test_resource = generate_k8s_resource(kind, resource_name, namespace, api_version)
    
    # Store the resource in the isolated test cache
    test_cache.store_response(unique_cache_key, test_resource)
    
    # Retrieve the resource from the cache
    cached_resource = test_cache.get_response(unique_cache_key)
    
    # Verify that the cached resource matches the original
    assert cached_resource is not None, f"Failed to retrieve resource with key {unique_cache_key}"
    assert cached_resource == test_resource, "Cached resource does not match original"
    
    # Verify specific attributes
    assert cached_resource["apiVersion"] == test_resource["apiVersion"]
    assert cached_resource["kind"] == test_resource["kind"]
    assert cached_resource["metadata"]["name"] == test_resource["metadata"]["name"]
    
    if namespace:
        assert cached_resource["metadata"]["namespace"] == test_resource["metadata"]["namespace"]
        
    # Clean up only this specific key, not the entire cache
    test_cache.clear_response(unique_cache_key)


@settings(suppress_health_check=[HealthCheck.function_scoped_fixture])
@given(
    cache_key=cache_keys,
    kind=kinds,
    api_version=api_versions
)
def test_cache_list_resources_property(test_cache, cache_key, kind, api_version):
    """
    Property: The cache should correctly store and retrieve lists of resources.
    
    This test verifies that list resources (with 'items' array) are properly 
    stored and retrieved from the cache.
    """
    # Generate a unique cache key to avoid collisions with other tests
    unique_cache_key = f"test_list_{cache_key}_{kind}_{api_version.replace('/', '_')}"
    
    # Generate a list of test resources
    resources = [
        generate_k8s_resource(kind, f"test-{i}", "default", api_version)
        for i in range(3)
    ]
    
    # Create a list response
    list_response = {
        "apiVersion": api_version,
        "kind": f"{kind}List",
        "items": resources
    }
    
    # Store the list in the isolated test cache
    test_cache.store_response(unique_cache_key, list_response)
    
    # Retrieve the list from the cache
    cached_list = test_cache.get_response(unique_cache_key)
    
    # Verify that the cached list matches the original
    assert cached_list is not None, f"Failed to retrieve list with key {unique_cache_key}"
    assert cached_list["apiVersion"] == list_response["apiVersion"]
    assert cached_list["kind"] == list_response["kind"]
    assert "items" in cached_list
    assert len(cached_list["items"]) == len(list_response["items"])
    
    # Verify each item in the list
    for i, item in enumerate(cached_list["items"]):
        original_item = list_response["items"][i]
        assert item["kind"] == original_item["kind"]
        assert item["apiVersion"] == original_item["apiVersion"]
        assert item["metadata"]["name"] == original_item["metadata"]["name"]
        
    # Clean up only this specific key, not the entire cache
    test_cache.clear_response(unique_cache_key)


def test_cache_operations_integration(test_cache):
    """
    Test the integration of various cache operations.
    
    This test verifies the cache's CRUD operations work correctly together:
    - store_response
    - get_response
    - clear_response (individual key)
    - get_cache_stats
    """
    # Create unique test keys to avoid collisions
    test_keys = [
        "test_integration_api/v1/namespaces/default/pods/test-pod",
        "test_integration_api/v1/namespaces/default/pods"
    ]
    
    # Single resource
    single_resource = generate_k8s_resource("Pod", "test-pod", "default")
    
    # List resource
    list_resource = {
        "apiVersion": "v1",
        "kind": "PodList",
        "items": [
            generate_k8s_resource("Pod", "pod-1", "default"),
            generate_k8s_resource("Pod", "pod-2", "default")
        ]
    }
    
    # Get initial stats to compare against
    initial_stats = test_cache.get_cache_stats()
    initial_count = initial_stats["total_responses"]
    
    # Store resources in the isolated test cache
    test_cache.store_response(test_keys[0], single_resource)
    test_cache.store_response(test_keys[1], list_resource)
    
    # Verify storage
    assert test_cache.get_response(test_keys[0]) == single_resource
    assert test_cache.get_response(test_keys[1]) == list_resource
    
    # Get cache stats
    stats = test_cache.get_cache_stats()
    assert stats["total_responses"] >= initial_count + 2  # At least our 2 responses added
    
    # Clear one key
    test_cache.clear_response(test_keys[0])
    assert test_cache.get_response(test_keys[0]) is None
    assert test_cache.get_response(test_keys[1]) is not None
    
    # Check stats after partial clear
    stats_after_partial = test_cache.get_cache_stats()
    assert stats_after_partial["total_responses"] >= initial_count + 1  # At least 1 of our responses remaining
    
    # Clean up only our test keys, not the entire cache
    test_cache.clear_response(test_keys[1])
    
    # Final stats check - our entries should be gone
    final_stats = test_cache.get_cache_stats()
    assert test_cache.get_response(test_keys[1]) is None


def test_cache_update_response(test_cache):
    """
    Test updating an existing cached response.
    
    This test verifies that when a response is stored with an existing cache key,
    it updates the existing entry rather than creating a duplicate.
    """
    # Use a unique test key to avoid collisions
    test_key = "test_update_api/v1/namespaces/default/pods/test-pod"
    
    # Get initial stats to establish baseline
    initial_stats = test_cache.get_cache_stats()
    initial_count = initial_stats["total_responses"]
    print(f"\nInitial stats: {initial_stats['total_responses']} total responses")
    
    # Create initial resource
    initial_resource = generate_k8s_resource("Pod", "test-pod", "default")
    initial_resource["spec"] = {"containers": [{"name": "container-1"}]}
    
    # Store initial resource in the isolated test cache
    test_cache.store_response(test_key, initial_resource)
    
    # Check stats after first store
    stats_after_first = test_cache.get_cache_stats()
    print(f"After first store: {stats_after_first['total_responses']} total responses")
    expected_after_first = initial_count + 1
    assert stats_after_first["total_responses"] >= expected_after_first
    
    # Create updated resource
    updated_resource = initial_resource.copy()
    updated_resource["spec"]["containers"].append({"name": "container-2"})
    updated_resource["metadata"]["resourceVersion"] = "2"
    
    # Store updated resource with same key
    test_cache.store_response(test_key, updated_resource)
    
    # Retrieve and verify it was updated
    cached_resource = test_cache.get_response(test_key)
    assert cached_resource is not None
    assert cached_resource["metadata"]["resourceVersion"] == "2", "Resource version was not updated"
    assert len(cached_resource["spec"]["containers"]) == 2, "Container list was not updated"
    
    # Check stats after update - should still have same count as after first store
    stats_after_update = test_cache.get_cache_stats()
    print(f"After update: {stats_after_update['total_responses']} total responses")
    
    # Verify the key aspects of the update
    # The unique constraint on cache_key should prevent duplicates
    # Expected count should remain the same as after the first store
    assert stats_after_update["total_responses"] == stats_after_first["total_responses"], "Count changed after update - indicates a potential issue with unique constraints"
    
    # Clean up only this specific key
    test_cache.clear_response(test_key)


def test_runtime_check_prevents_production_cache_access():
    """
    Test that the runtime checks in Cache methods correctly prevent tests from
    accessing the production cache without using the test_cache fixture.
    
    This test is crucial to ensure the safety features that prevent tests from
    accidentally modifying production data remain in place and are not removed.
    """
    # Create a standard Cache instance (not marked as test_cache)
    temp_dir = tempfile.mkdtemp(prefix="cache_safety_test_")
    config = Config(config_dir=temp_dir)
    cache = Cache(config)
    
    # We're running in a test, so PYTEST_CURRENT_TEST should be set
    assert "PYTEST_CURRENT_TEST" in os.environ, "This test must be run with pytest"
    
    # Verify that the cache instance doesn't have the _is_test_cache attribute
    assert not hasattr(cache, "_is_test_cache"), "Cache instance should not have _is_test_cache attribute"
    
    try:
        # Attempt to store a response - should raise RuntimeError
        with pytest.raises(RuntimeError) as excinfo:
            cache.store_response("test/safety/path", {"data": "test"})
        assert "CRITICAL ERROR: Attempting to modify production cache from a test" in str(excinfo.value)
        
        # Attempt to retrieve a response - should raise RuntimeError
        with pytest.raises(RuntimeError) as excinfo:
            cache.get_response("test/safety/path")
        assert "CRITICAL ERROR: Attempting to read from production cache in a test" in str(excinfo.value)
        
        # Attempt to clear a specific response - should raise RuntimeError
        with pytest.raises(RuntimeError) as excinfo:
            cache.clear_response("test/safety/path")
        assert "CRITICAL ERROR: Attempting to clear response from production cache in a test" in str(excinfo.value)
        
        # Attempt to clear the entire cache - should raise RuntimeError
        with pytest.raises(RuntimeError) as excinfo:
            cache.clear_cache()
        assert "CRITICAL ERROR: Attempting to clear production cache from a test" in str(excinfo.value)
        
    finally:
        # Clean up temporary directory
        import shutil
        shutil.rmtree(temp_dir)


@settings(suppress_health_check=[HealthCheck.function_scoped_fixture])
@given(
    resource_name=resource_names,
    namespace=st.one_of(st.none(), namespaces),
    api_version=api_versions,
    kind=kinds
)
def test_store_resource_property(test_cache, resource_name, namespace, api_version, kind):
    """
    Property: store_resource should correctly store valid Kubernetes resources.
    
    This test verifies that:
    1. Valid resources with all required fields are stored successfully
    2. Resources can be retrieved using get_resource after storage
    3. Resource data is preserved accurately
    """
    # Generate a test resource with all required fields
    test_resource = generate_k8s_resource(kind, resource_name, namespace, api_version)
    
    # Store the resource in the isolated test cache
    test_cache.store_resource(test_resource)
    
    # Retrieve the resource using get_resource
    retrieved_resource = test_cache.get_resource(
        api_version=api_version,
        kind=kind,
        name=resource_name,
        namespace=namespace
    )
    
    # Verify that the resource was stored and retrieved correctly
    assert retrieved_resource is not None, f"Failed to retrieve stored resource {kind}/{resource_name}"
    assert retrieved_resource == test_resource, "Retrieved resource does not match original"
    
    # Verify specific required fields are preserved
    assert retrieved_resource["apiVersion"] == api_version
    assert retrieved_resource["kind"] == kind
    assert retrieved_resource["metadata"]["name"] == resource_name
    assert retrieved_resource["metadata"]["uid"] == test_resource["metadata"]["uid"]
    assert retrieved_resource["metadata"]["resourceVersion"] == test_resource["metadata"]["resourceVersion"]
    
    if namespace:
        assert retrieved_resource["metadata"]["namespace"] == namespace


@settings(suppress_health_check=[HealthCheck.function_scoped_fixture])
@given(
    resource_name=resource_names,
    namespace=st.one_of(st.none(), namespaces),
    api_version=api_versions,
    kind=kinds
)
def test_store_resource_update_property(test_cache, resource_name, namespace, api_version, kind):
    """
    Property: store_resource should update existing resources based on UID.
    
    This test verifies that:
    1. Storing a resource with the same UID updates the existing record
    2. The updated resource data is correctly stored
    3. No duplicate records are created
    """
    # Generate initial resource
    initial_resource = generate_k8s_resource(kind, resource_name, namespace, api_version)
    uid = initial_resource["metadata"]["uid"]
    
    # Store initial resource
    test_cache.store_resource(initial_resource)
    
    # Generate updated resource with same UID but different resourceVersion
    updated_resource = initial_resource.copy()
    updated_resource["metadata"]["resourceVersion"] = "2"
    updated_resource["spec"] = {"updated": True}  # Add some distinguishing data
    
    # Store updated resource
    test_cache.store_resource(updated_resource)
    
    # Retrieve the resource
    retrieved_resource = test_cache.get_resource(
        api_version=api_version,
        kind=kind,
        name=resource_name,
        namespace=namespace
    )
    
    # Verify the resource was updated, not duplicated
    assert retrieved_resource is not None
    assert retrieved_resource["metadata"]["resourceVersion"] == "2", "Resource version was not updated"
    assert retrieved_resource.get("spec", {}).get("updated") == True, "Resource data was not updated"
    
    # Verify using list_resources that only one record exists
    resources = test_cache.list_resources(api_version=api_version, kind=kind, namespace=namespace)
    matching_resources = [r for r in resources if r["metadata"]["name"] == resource_name]
    assert len(matching_resources) == 1, f"Expected 1 resource, found {len(matching_resources)}"


@settings(suppress_health_check=[HealthCheck.function_scoped_fixture])
@given(
    resource_name=resource_names,
    missing_field=st.sampled_from(["apiVersion", "kind", "name", "uid", "resourceVersion"])
)
def test_store_resource_validation_property(test_cache, resource_name, missing_field):
    """
    Property: store_resource should validate required fields and raise ValueError for invalid resources.
    
    This test verifies that:
    1. Resources missing required fields are rejected
    2. Appropriate ValueError is raised with descriptive message
    3. Invalid resources are not stored in the cache
    """
    # Generate a valid resource
    valid_resource = generate_k8s_resource("Pod", resource_name, "default", "v1")
    
    # Create invalid resource by removing a required field
    invalid_resource = valid_resource.copy()
    if missing_field in ["apiVersion", "kind"]:
        del invalid_resource[missing_field]
    elif missing_field in ["name", "uid", "resourceVersion"]:
        del invalid_resource["metadata"][missing_field]
    
    # Verify that storing the invalid resource raises ValueError
    with pytest.raises(ValueError) as excinfo:
        test_cache.store_resource(invalid_resource)
    
    assert "missing required fields" in str(excinfo.value)
    
    # Verify the invalid resource was not stored by checking get_resource returns None
    retrieved_resource = test_cache.get_resource(
        api_version=valid_resource.get("apiVersion", ""),
        kind=valid_resource.get("kind", ""),
        name=resource_name,
        namespace="default"
    )
    assert retrieved_resource is None, "Invalid resource should not have been stored"


@settings(suppress_health_check=[HealthCheck.function_scoped_fixture])
@given(
    resource_names_list=st.lists(resource_names, min_size=2, max_size=5, unique=True),
    namespace=namespaces,
    api_version=api_versions,
    kind=kinds
)
def test_store_multiple_resources_property(test_cache, resource_names_list, namespace, api_version, kind):
    """
    Property: store_resource should handle storing multiple resources correctly.
    
    This test verifies that:
    1. Multiple resources can be stored independently
    2. Each resource can be retrieved correctly
    3. list_resources returns all stored resources
    """
    stored_resources = []
    
    # Store multiple resources
    for resource_name in resource_names_list:
        resource = generate_k8s_resource(kind, resource_name, namespace, api_version)
        test_cache.store_resource(resource)
        stored_resources.append(resource)
    
    # Verify each resource can be retrieved individually
    for i, resource_name in enumerate(resource_names_list):
        retrieved_resource = test_cache.get_resource(
            api_version=api_version,
            kind=kind,
            name=resource_name,
            namespace=namespace
        )
        assert retrieved_resource is not None, f"Failed to retrieve resource {resource_name}"
        assert retrieved_resource == stored_resources[i], f"Resource {resource_name} data mismatch"
    
    # Verify list_resources returns all stored resources
    listed_resources = test_cache.list_resources(api_version=api_version, kind=kind, namespace=namespace)
    
    # Filter to only our test resources
    our_resources = [r for r in listed_resources if r["metadata"]["name"] in resource_names_list]
    assert len(our_resources) == len(resource_names_list), f"Expected {len(resource_names_list)} resources, found {len(our_resources)}"
    
    # Verify all our resources are present
    retrieved_names = {r["metadata"]["name"] for r in our_resources}
    expected_names = set(resource_names_list)
    assert retrieved_names == expected_names, f"Resource names mismatch: expected {expected_names}, got {retrieved_names}"


def test_store_resource_runtime_safety_check():
    """
    Test that store_resource has the same runtime safety check as other cache methods.
    
    This test verifies that store_resource prevents tests from accidentally
    accessing the production cache without using the test_cache fixture.
    """
    # Create a standard Cache instance (not marked as test_cache)
    temp_dir = tempfile.mkdtemp(prefix="cache_safety_test_store_resource_")
    config = Config(config_dir=temp_dir)
    cache = Cache(config)
    
    # We're running in a test, so PYTEST_CURRENT_TEST should be set
    assert "PYTEST_CURRENT_TEST" in os.environ, "This test must be run with pytest"
    
    # Verify that the cache instance doesn't have the _is_test_cache attribute
    assert not hasattr(cache, "_is_test_cache"), "Cache instance should not have _is_test_cache attribute"
    
    try:
        # Attempt to store a resource - should raise RuntimeError now that runtime check is added
        test_resource = generate_k8s_resource("Pod", "test-pod", "default", "v1")
        
        # Now the runtime check is in place, so this should raise RuntimeError
        with pytest.raises(RuntimeError) as excinfo:
            cache.store_resource(test_resource)
        assert "CRITICAL ERROR: Attempting to modify production cache from a test" in str(excinfo.value)
        
    finally:
        # Clean up temporary directory
        import shutil
        shutil.rmtree(temp_dir)


# =============================================================================
# TESTS FOR get_resource METHOD - COMPREHENSIVE COVERAGE
# =============================================================================

@settings(suppress_health_check=[HealthCheck.function_scoped_fixture])
@given(
    resource_name=resource_names,
    namespace=st.one_of(st.none(), namespaces),
    api_version=api_versions,
    kind=kinds
)
def test_get_resource_existing_property(test_cache, resource_name, namespace, api_version, kind):
    """
    Property: get_resource should retrieve existing stored resources correctly.
    
    This test verifies that:
    1. Resources stored via store_resource can be retrieved via get_resource
    2. Namespace filtering works correctly
    3. Resource data is preserved accurately
    """
    # Generate unique test prefix to avoid contamination
    test_prefix = f"test_get_resource_{resource_name}"
    
    try:
        # Generate and store a test resource
        test_resource = generate_k8s_resource(kind, test_prefix, namespace, api_version)
        test_cache.store_resource(test_resource)
        
        # Retrieve the resource using get_resource
        retrieved_resource = test_cache.get_resource(
            api_version=api_version,
            kind=kind,
            name=test_prefix,
            namespace=namespace
        )
        
        # Verify retrieval was successful and data matches
        assert retrieved_resource is not None, f"Failed to retrieve stored resource {kind}/{test_prefix}"
        assert retrieved_resource == test_resource, "Retrieved resource does not match stored resource"
        
        # Verify all key fields are preserved
        assert retrieved_resource["apiVersion"] == api_version
        assert retrieved_resource["kind"] == kind
        assert retrieved_resource["metadata"]["name"] == test_prefix
        assert retrieved_resource["metadata"]["uid"] == test_resource["metadata"]["uid"]
        
        if namespace:
            assert retrieved_resource["metadata"]["namespace"] == namespace
    
    finally:
        # Clean up test data - delete the specific resource we created
        try:
            test_cache.delete_resource(api_version, kind, test_prefix, namespace)
        except:
            pass  # Ignore cleanup errors


@settings(suppress_health_check=[HealthCheck.function_scoped_fixture])
@given(
    resource_name=resource_names,
    namespace=st.one_of(st.none(), namespaces),
    api_version=api_versions,
    kind=kinds
)
def test_get_resource_nonexistent_property(test_cache, resource_name, namespace, api_version, kind):
    """
    Property: get_resource should return None for non-existent resources.
    
    This test verifies that:
    1. Requesting non-existent resources returns None
    2. No exceptions are raised for missing resources
    3. Namespace filtering affects results correctly
    """
    # Use a unique prefix that definitely doesn't exist
    nonexistent_name = f"test_nonexistent_{resource_name}_{int(time.time() * 1000)}"
    
    # Try to retrieve a resource that doesn't exist
    retrieved_resource = test_cache.get_resource(
        api_version=api_version,
        kind=kind,
        name=nonexistent_name,
        namespace=namespace
    )
    
    # Should return None for non-existent resource
    assert retrieved_resource is None, f"Expected None for non-existent resource {kind}/{nonexistent_name}"


@settings(suppress_health_check=[HealthCheck.function_scoped_fixture])
@given(
    resource_name=resource_names,
    correct_namespace=namespaces,
    wrong_namespace=namespaces,
    api_version=api_versions,
    kind=kinds
)
def test_get_resource_namespace_filtering_property(test_cache, resource_name, correct_namespace, wrong_namespace, api_version, kind):
    """
    Property: get_resource should correctly filter by namespace.
    
    This test verifies that:
    1. Resources are only retrieved when the correct namespace is specified
    2. Wrong namespace returns None even if resource exists
    3. Namespace filtering is exact match
    """
    # Skip if namespaces are the same (no filtering to test)
    assume(correct_namespace != wrong_namespace)
    
    # Generate unique test prefix to avoid contamination
    test_prefix = f"test_namespace_{resource_name}"
    
    try:
        # Generate and store a resource in a specific namespace
        test_resource = generate_k8s_resource(kind, test_prefix, correct_namespace, api_version)
        test_cache.store_resource(test_resource)
        
        # Try to retrieve with correct namespace - should succeed
        retrieved_correct = test_cache.get_resource(
            api_version=api_version,
            kind=kind,
            name=test_prefix,
            namespace=correct_namespace
        )
        assert retrieved_correct is not None, "Should find resource with correct namespace"
        assert retrieved_correct["metadata"]["namespace"] == correct_namespace
        
        # Try to retrieve with wrong namespace - should fail
        retrieved_wrong = test_cache.get_resource(
            api_version=api_version,
            kind=kind,
            name=test_prefix,
            namespace=wrong_namespace
        )
        assert retrieved_wrong is None, "Should not find resource with wrong namespace"
    
    finally:
        # Clean up test data
        try:
            test_cache.delete_resource(api_version, kind, test_prefix, correct_namespace)
        except:
            pass  # Ignore cleanup errors


# =============================================================================
# TESTS FOR list_resources METHOD - COMPREHENSIVE COVERAGE
# =============================================================================

@settings(suppress_health_check=[HealthCheck.function_scoped_fixture])
@given(
    resource_names_list=st.lists(resource_names, min_size=2, max_size=4, unique=True),
    namespace=namespaces,
    api_version=api_versions,
    kind=kinds
)
def test_list_resources_all_property(test_cache, resource_names_list, namespace, api_version, kind):
    """
    Property: list_resources should return all stored resources when no filters applied.
    
    This test verifies that:
    1. All stored resources are returned when no filters are applied
    2. Resource data is preserved accurately in the list
    3. List operations don't modify stored resources
    """
    test_prefix = "test_list_all"
    test_resources = []
    
    try:
        # Store multiple resources
        for i, resource_name in enumerate(resource_names_list):
            test_name = f"{test_prefix}_{resource_name}"
            test_resource = generate_k8s_resource(kind, test_name, namespace, api_version)
            test_cache.store_resource(test_resource)
            test_resources.append((test_name, test_resource))
        
        # Get initial count to establish baseline
        all_resources_before = test_cache.list_resources()
        initial_count = len(all_resources_before)
        
        # List all resources (no filters)
        all_resources = test_cache.list_resources()
        
        # Should contain at least our test resources
        assert len(all_resources) >= len(test_resources), f"Expected at least {len(test_resources)} resources"
        
        # Find our test resources in the list
        our_resources = [r for r in all_resources if r["metadata"]["name"].startswith(test_prefix)]
        assert len(our_resources) == len(test_resources), f"Expected {len(test_resources)} test resources, found {len(our_resources)}"
        
        # Verify each resource is correct
        for test_name, original_resource in test_resources:
            found = False
            for listed_resource in our_resources:
                if listed_resource["metadata"]["name"] == test_name:
                    assert listed_resource == original_resource, f"Resource {test_name} data mismatch"
                    found = True
                    break
            assert found, f"Resource {test_name} not found in list"
    
    finally:
        # Clean up test data
        for test_name, _ in test_resources:
            try:
                test_cache.delete_resource(api_version, kind, test_name, namespace)
            except:
                pass


@settings(suppress_health_check=[HealthCheck.function_scoped_fixture])
@given(
    resource_names_list=st.lists(resource_names, min_size=2, max_size=3, unique=True),
    target_namespace=namespaces,
    other_namespace=namespaces,
    api_version=api_versions,
    kind=kinds
)
def test_list_resources_filtered_property(test_cache, resource_names_list, target_namespace, other_namespace, api_version, kind):
    """
    Property: list_resources should correctly filter by api_version, kind, and namespace.
    
    This test verifies that:
    1. Filtering by specific criteria returns only matching resources
    2. Multiple filters work together correctly
    3. Non-matching resources are excluded
    """
    assume(target_namespace != other_namespace)
    
    test_prefix = "test_filtered"
    target_resources = []
    other_resources = []
    
    try:
        # Store resources in target namespace
        for i, resource_name in enumerate(resource_names_list):
            test_name = f"{test_prefix}_target_{resource_name}"
            test_resource = generate_k8s_resource(kind, test_name, target_namespace, api_version)
            test_cache.store_resource(test_resource)
            target_resources.append((test_name, test_resource))
        
        # Store resources in other namespace
        for i, resource_name in enumerate(resource_names_list):
            test_name = f"{test_prefix}_other_{resource_name}"
            test_resource = generate_k8s_resource(kind, test_name, other_namespace, api_version)
            test_cache.store_resource(test_resource)
            other_resources.append((test_name, test_resource))
        
        # Filter by target namespace only
        namespace_filtered = test_cache.list_resources(namespace=target_namespace)
        our_namespace_resources = [r for r in namespace_filtered if r["metadata"]["name"].startswith(test_prefix)]
        
        # Should only contain target namespace resources
        for resource in our_namespace_resources:
            assert resource["metadata"]["namespace"] == target_namespace, "Wrong namespace in filtered results"
        
        # Filter by api_version and kind
        kind_filtered = test_cache.list_resources(api_version=api_version, kind=kind)
        our_kind_resources = [r for r in kind_filtered if r["metadata"]["name"].startswith(test_prefix)]
        
        # Should contain both namespaces but correct kind/api_version
        assert len(our_kind_resources) >= len(target_resources) + len(other_resources), "Missing resources in kind filter"
        for resource in our_kind_resources:
            assert resource["apiVersion"] == api_version, "Wrong apiVersion in filtered results"
            assert resource["kind"] == kind, "Wrong kind in filtered results"
        
        # Filter by all three criteria
        fully_filtered = test_cache.list_resources(
            api_version=api_version, 
            kind=kind, 
            namespace=target_namespace
        )
        our_fully_filtered = [r for r in fully_filtered if r["metadata"]["name"].startswith(test_prefix)]
        
        # Should only contain target namespace resources
        expected_count = len(target_resources)
        assert len(our_fully_filtered) == expected_count, f"Expected {expected_count} fully filtered resources, got {len(our_fully_filtered)}"
        
        for resource in our_fully_filtered:
            assert resource["apiVersion"] == api_version, "Wrong apiVersion in fully filtered results"
            assert resource["kind"] == kind, "Wrong kind in fully filtered results"
            assert resource["metadata"]["namespace"] == target_namespace, "Wrong namespace in fully filtered results"
    
    finally:
        # Clean up test data
        for test_name, _ in target_resources + other_resources:
            try:
                namespace = target_namespace if "target" in test_name else other_namespace
                test_cache.delete_resource(api_version, kind, test_name, namespace)
            except:
                pass


def test_list_resources_empty_property(test_cache):
    """
    Property: list_resources should handle empty cache gracefully.
    
    This test verifies that:
    1. Empty cache returns empty list, not None
    2. No exceptions are raised for empty cache
    3. Filtering empty cache still returns empty list
    """
    # List resources from potentially empty cache
    all_resources = test_cache.list_resources()
    
    # Should return a list (may be empty, but should be a list)
    assert isinstance(all_resources, list), "list_resources should return a list, not None"
    
    # Try filtered queries on empty cache
    filtered_resources = test_cache.list_resources(
        api_version="v1", 
        kind="Pod", 
        namespace="nonexistent"
    )
    assert isinstance(filtered_resources, list), "Filtered list_resources should return a list"
    
    # For this specific filter, should be empty since namespace is nonexistent
    our_resources = [r for r in filtered_resources if r["metadata"]["namespace"] == "nonexistent"]
    assert len(our_resources) == 0, "Should find no resources in nonexistent namespace"


# =============================================================================
# TESTS FOR delete_resource METHOD - COMPREHENSIVE COVERAGE
# =============================================================================

@settings(suppress_health_check=[HealthCheck.function_scoped_fixture])
@given(
    resource_name=resource_names,
    namespace=st.one_of(st.none(), namespaces),
    api_version=api_versions,
    kind=kinds
)
def test_delete_resource_existing_property(test_cache, resource_name, namespace, api_version, kind):
    """
    Property: delete_resource should successfully delete existing resources.
    
    This test verifies that:
    1. Existing resources can be deleted from the cache
    2. delete_resource returns True for successful deletions
    3. The resource is no longer retrievable after deletion
    """
    test_prefix = f"test_delete_{resource_name}"
    
    try:
        # Store a resource first
        test_resource = generate_k8s_resource(kind, test_prefix, namespace, api_version)
        test_cache.store_resource(test_resource)
        
        # Verify the resource exists
        retrieved_before = test_cache.get_resource(api_version, kind, test_prefix, namespace)
        assert retrieved_before is not None, "Resource should exist before deletion"
        
        # Delete the resource
        deletion_result = test_cache.delete_resource(api_version, kind, test_prefix, namespace)
        
        # Verify deletion was successful
        assert deletion_result == True, "delete_resource should return True for successful deletion"
        
        # Verify the resource no longer exists
        retrieved_after = test_cache.get_resource(api_version, kind, test_prefix, namespace)
        assert retrieved_after is None, "Resource should not exist after deletion"
        
        # Verify the resource is not in the list anymore
        listed_resources = test_cache.list_resources(api_version=api_version, kind=kind, namespace=namespace)
        our_resources = [r for r in listed_resources if r["metadata"]["name"] == test_prefix]
        assert len(our_resources) == 0, "Deleted resource should not appear in list_resources"
        
    finally:
        # Clean up - try to delete in case test failed before deletion
        try:
            test_cache.delete_resource(api_version, kind, test_prefix, namespace)
        except:
            pass


@settings(suppress_health_check=[HealthCheck.function_scoped_fixture])
@given(
    resource_name=resource_names,
    namespace=st.one_of(st.none(), namespaces),
    api_version=api_versions,
    kind=kinds
)
def test_delete_resource_nonexistent_property(test_cache, resource_name, namespace, api_version, kind):
    """
    Property: delete_resource should return False for non-existent resources.
    
    This test verifies that:
    1. Attempting to delete non-existent resources returns False
    2. No exceptions are raised for missing resources
    3. The operation is safe and idempotent
    """
    # Use a unique name that definitely doesn't exist
    nonexistent_name = f"test_delete_nonexistent_{resource_name}_{int(time.time() * 1000)}"
    
    # Try to delete a resource that doesn't exist
    deletion_result = test_cache.delete_resource(api_version, kind, nonexistent_name, namespace)
    
    # Should return False for non-existent resource
    assert deletion_result == False, f"delete_resource should return False for non-existent resource {kind}/{nonexistent_name}"
    
    # Verify no side effects - should still return False on subsequent attempts
    deletion_result_2 = test_cache.delete_resource(api_version, kind, nonexistent_name, namespace)
    assert deletion_result_2 == False, "Subsequent deletion attempts should also return False"


@settings(suppress_health_check=[HealthCheck.function_scoped_fixture])
@given(
    resource_name=resource_names,
    correct_namespace=namespaces,
    wrong_namespace=namespaces,
    api_version=api_versions,
    kind=kinds
)
def test_delete_resource_namespace_filtering_property(test_cache, resource_name, correct_namespace, wrong_namespace, api_version, kind):
    """
    Property: delete_resource should correctly filter by namespace.
    
    This test verifies that:
    1. Resources are only deleted when the correct namespace is specified
    2. Wrong namespace returns False even if resource exists
    3. Namespace filtering is exact match
    """
    # Skip if namespaces are the same (no filtering to test)
    assume(correct_namespace != wrong_namespace)
    
    test_prefix = f"test_delete_namespace_{resource_name}"
    
    try:
        # Store a resource in a specific namespace
        test_resource = generate_k8s_resource(kind, test_prefix, correct_namespace, api_version)
        test_cache.store_resource(test_resource)
        
        # Verify the resource exists
        retrieved_correct = test_cache.get_resource(api_version, kind, test_prefix, correct_namespace)
        assert retrieved_correct is not None, "Resource should exist before deletion attempt"
        
        # Try to delete with wrong namespace - should fail
        deletion_wrong = test_cache.delete_resource(api_version, kind, test_prefix, wrong_namespace)
        assert deletion_wrong == False, "Should not delete resource with wrong namespace"
        
        # Verify the resource still exists with correct namespace
        retrieved_still_exists = test_cache.get_resource(api_version, kind, test_prefix, correct_namespace)
        assert retrieved_still_exists is not None, "Resource should still exist after failed deletion"
        
        # Now delete with correct namespace - should succeed
        deletion_correct = test_cache.delete_resource(api_version, kind, test_prefix, correct_namespace)
        assert deletion_correct == True, "Should successfully delete resource with correct namespace"
        
        # Verify the resource is gone
        retrieved_after_correct = test_cache.get_resource(api_version, kind, test_prefix, correct_namespace)
        assert retrieved_after_correct is None, "Resource should not exist after successful deletion"
        
    finally:
        # Clean up - try to delete in case test failed
        try:
            test_cache.delete_resource(api_version, kind, test_prefix, correct_namespace)
        except:
            pass


@settings(suppress_health_check=[HealthCheck.function_scoped_fixture])
@given(
    resource_names_list=st.lists(resource_names, min_size=2, max_size=4, unique=True),
    namespace=namespaces,
    api_version=api_versions,
    kind=kinds
)
def test_delete_resource_multiple_resources_property(test_cache, resource_names_list, namespace, api_version, kind):
    """
    Property: delete_resource should handle multiple resources correctly.
    
    This test verifies that:
    1. Deleting one resource doesn't affect other resources
    2. Multiple resources can be deleted independently
    3. Partial deletions work correctly
    """
    test_prefix = "test_delete_multiple"
    test_resources = []
    
    try:
        # Store multiple resources
        for i, resource_name in enumerate(resource_names_list):
            test_name = f"{test_prefix}_{resource_name}"
            test_resource = generate_k8s_resource(kind, test_name, namespace, api_version)
            test_cache.store_resource(test_resource)
            test_resources.append((test_name, test_resource))
        
        # Verify all resources exist
        for test_name, _ in test_resources:
            retrieved = test_cache.get_resource(api_version, kind, test_name, namespace)
            assert retrieved is not None, f"Resource {test_name} should exist after storage"
        
        # Delete the first resource
        first_name, _ = test_resources[0]
        deletion_result = test_cache.delete_resource(api_version, kind, first_name, namespace)
        assert deletion_result == True, "First resource deletion should succeed"
        
        # Verify first resource is gone
        first_retrieved = test_cache.get_resource(api_version, kind, first_name, namespace)
        assert first_retrieved is None, "First resource should not exist after deletion"
        
        # Verify other resources still exist
        for test_name, original_resource in test_resources[1:]:
            retrieved = test_cache.get_resource(api_version, kind, test_name, namespace)
            assert retrieved is not None, f"Resource {test_name} should still exist"
            assert retrieved == original_resource, f"Resource {test_name} should be unchanged"
        
        # Delete the remaining resources one by one
        for test_name, _ in test_resources[1:]:
            deletion_result = test_cache.delete_resource(api_version, kind, test_name, namespace)
            assert deletion_result == True, f"Deletion of {test_name} should succeed"
            
            # Verify it's gone
            retrieved = test_cache.get_resource(api_version, kind, test_name, namespace)
            assert retrieved is None, f"Resource {test_name} should not exist after deletion"
        
        # Verify list_resources shows no test resources
        listed_resources = test_cache.list_resources(api_version=api_version, kind=kind, namespace=namespace)
        our_resources = [r for r in listed_resources if r["metadata"]["name"].startswith(test_prefix)]
        assert len(our_resources) == 0, "No test resources should remain in list_resources"
        
    finally:
        # Clean up any remaining test data
        for test_name, _ in test_resources:
            try:
                test_cache.delete_resource(api_version, kind, test_name, namespace)
            except:
                pass


def test_delete_resource_runtime_safety_check():
    """
    Test that delete_resource has runtime safety check to prevent production cache access.
    
    This test verifies that delete_resource prevents tests from accidentally
    accessing the production cache without using the test_cache fixture.
    """
    # Create a standard Cache instance (not marked as test_cache)
    temp_dir = tempfile.mkdtemp(prefix="cache_safety_test_delete_resource_")
    config = Config(config_dir=temp_dir)
    cache = Cache(config)
    
    # We're running in a test, so PYTEST_CURRENT_TEST should be set
    assert "PYTEST_CURRENT_TEST" in os.environ, "This test must be run with pytest"
    
    # Verify that the cache instance doesn't have the _is_test_cache attribute
    assert not hasattr(cache, "_is_test_cache"), "Cache instance should not have _is_test_cache attribute"
    
    try:
        # Attempt to delete a resource - should raise RuntimeError now that runtime check is added
        with pytest.raises(RuntimeError) as excinfo:
            cache.delete_resource("v1", "Pod", "test-pod", "default")
        assert "CRITICAL ERROR: Attempting to delete from production cache in a test" in str(excinfo.value)
        
    finally:
        # Clean up temporary directory
        import shutil
        shutil.rmtree(temp_dir)


# =============================================================================
# TESTS FOR clear_cache METHOD - COMPREHENSIVE COVERAGE
# =============================================================================

@settings(suppress_health_check=[HealthCheck.function_scoped_fixture])
@given(
    resource_names_list=st.lists(resource_names, min_size=2, max_size=3, unique=True),
    namespace=namespaces,
    api_version=api_versions,
    kind=kinds
)
def test_clear_cache_filtered_property(test_cache, resource_names_list, namespace, api_version, kind):
    """
    Property: clear_cache should correctly clear resources based on filters.
    
    This test verifies that:
    1. Filtered cache clearing only removes matching resources
    2. Non-matching resources remain in the cache
    3. The return value indicates the number of cleared items
    """
    test_prefix = "test_clear_filtered"
    test_resources = []
    other_resources = []
    
    try:
        # Store test resources with target filters
        for i, resource_name in enumerate(resource_names_list):
            test_name = f"{test_prefix}_{resource_name}"
            test_resource = generate_k8s_resource(kind, test_name, namespace, api_version)
            test_cache.store_resource(test_resource)
            test_resources.append((test_name, test_resource))
        
        # Store resources with different filters that should NOT be cleared
        different_namespace = "different-ns" if namespace != "different-ns" else "other-ns"
        different_kind = "Secret" if kind != "Secret" else "ConfigMap"
        
        for i, resource_name in enumerate(resource_names_list[:2]):  # Only store 2 to keep test manageable
            other_name = f"{test_prefix}_other_{resource_name}"
            other_resource = generate_k8s_resource(different_kind, other_name, different_namespace, api_version)
            test_cache.store_resource(other_resource)
            other_resources.append((other_name, other_resource, different_kind, different_namespace))
        
        # Get counts before clearing
        target_resources_before = test_cache.list_resources(api_version=api_version, kind=kind, namespace=namespace)
        other_resources_before = test_cache.list_resources(api_version=api_version, kind=different_kind, namespace=different_namespace)
        
        target_count_before = len([r for r in target_resources_before if r["metadata"]["name"].startswith(test_prefix)])
        other_count_before = len([r for r in other_resources_before if r["metadata"]["name"].startswith(test_prefix)])
        
        # Clear cache with specific filters
        cleared_count = test_cache.clear_cache(api_version=api_version, kind=kind, namespace=namespace)
        
        # The cleared count should be at least our target resources
        # (could be more if other tests left data, but should include ours)
        assert cleared_count >= target_count_before, f"Should clear at least {target_count_before} resources, cleared {cleared_count}"
        
        # Verify target resources are gone
        target_resources_after = test_cache.list_resources(api_version=api_version, kind=kind, namespace=namespace)
        target_count_after = len([r for r in target_resources_after if r["metadata"]["name"].startswith(test_prefix)])
        assert target_count_after == 0, "Target resources should be cleared"
        
        # Verify other resources still exist
        other_resources_after = test_cache.list_resources(api_version=api_version, kind=different_kind, namespace=different_namespace)
        other_count_after = len([r for r in other_resources_after if r["metadata"]["name"].startswith(test_prefix)])
        assert other_count_after == other_count_before, "Other resources should not be affected"
        
        # Verify each specific other resource still exists
        for other_name, original_resource, other_kind, other_ns in other_resources:
            retrieved = test_cache.get_resource(api_version, other_kind, other_name, other_ns)
            assert retrieved is not None, f"Other resource {other_name} should still exist"
            assert retrieved == original_resource, f"Other resource {other_name} should be unchanged"
    
    finally:
        # Clean up any remaining test data
        for test_name, _ in test_resources:
            try:
                test_cache.delete_resource(api_version, kind, test_name, namespace)
            except:
                pass
        for other_name, _, other_kind, other_ns in other_resources:
            try:
                test_cache.delete_resource(api_version, other_kind, other_name, other_ns)
            except:
                pass


@settings(suppress_health_check=[HealthCheck.function_scoped_fixture])
@given(
    resource_names_list=st.lists(resource_names, min_size=1, max_size=3, unique=True),
    namespace=namespaces,
    api_version=api_versions,
    kind=kinds
)
def test_clear_cache_partial_filters_property(test_cache, resource_names_list, namespace, api_version, kind):
    """
    Property: clear_cache should handle partial filters correctly.
    
    This test verifies that:
    1. Clearing by API version only affects resources with that API version
    2. Clearing by kind only affects resources with that kind
    3. Clearing by namespace only affects resources in that namespace
    """
    test_prefix = "test_clear_partial"
    test_resources = []
    
    try:
        # Store resources with our target filters
        for i, resource_name in enumerate(resource_names_list):
            test_name = f"{test_prefix}_{resource_name}"
            test_resource = generate_k8s_resource(kind, test_name, namespace, api_version)
            test_cache.store_resource(test_resource)
            test_resources.append((test_name, test_resource))
        
        # Test clearing by API version only
        api_resources_before = test_cache.list_resources(api_version=api_version)
        our_api_resources_before = len([r for r in api_resources_before if r["metadata"]["name"].startswith(test_prefix)])
        
        # Only test if we have resources to clear
        if our_api_resources_before > 0:
            cleared_by_api = test_cache.clear_cache(api_version=api_version)
            assert cleared_by_api >= our_api_resources_before, f"Should clear at least {our_api_resources_before} resources by API version"
            
            # Verify our resources are gone
            api_resources_after = test_cache.list_resources(api_version=api_version)
            our_api_resources_after = len([r for r in api_resources_after if r["metadata"]["name"].startswith(test_prefix)])
            assert our_api_resources_after == 0, "Resources should be cleared by API version filter"
        
        # Re-store for kind test (since they were cleared)
        for test_name, test_resource in test_resources:
            test_cache.store_resource(test_resource)
        
        # Test clearing by kind only
        kind_resources_before = test_cache.list_resources(kind=kind)
        our_kind_resources_before = len([r for r in kind_resources_before if r["metadata"]["name"].startswith(test_prefix)])
        
        if our_kind_resources_before > 0:
            cleared_by_kind = test_cache.clear_cache(kind=kind)
            assert cleared_by_kind >= our_kind_resources_before, f"Should clear at least {our_kind_resources_before} resources by kind"
            
            # Verify our resources are gone
            kind_resources_after = test_cache.list_resources(kind=kind)
            our_kind_resources_after = len([r for r in kind_resources_after if r["metadata"]["name"].startswith(test_prefix)])
            assert our_kind_resources_after == 0, "Resources should be cleared by kind filter"
        
        # Re-store for namespace test (since they were cleared)
        for test_name, test_resource in test_resources:
            test_cache.store_resource(test_resource)
        
        # Test clearing by namespace only  
        ns_resources_before = test_cache.list_resources(namespace=namespace)
        our_ns_resources_before = len([r for r in ns_resources_before if r["metadata"]["name"].startswith(test_prefix)])
        
        if our_ns_resources_before > 0:
            cleared_by_ns = test_cache.clear_cache(namespace=namespace)
            assert cleared_by_ns >= our_ns_resources_before, f"Should clear at least {our_ns_resources_before} resources by namespace"
            
            # Verify our resources are gone
            ns_resources_after = test_cache.list_resources(namespace=namespace)
            our_ns_resources_after = len([r for r in ns_resources_after if r["metadata"]["name"].startswith(test_prefix)])
            assert our_ns_resources_after == 0, "Resources should be cleared by namespace filter"
    
    finally:
        # Clean up any remaining test data
        for test_name, _ in test_resources:
            try:
                test_cache.delete_resource(api_version, kind, test_name, namespace)
            except:
                pass


def test_clear_cache_empty_property(test_cache):
    """
    Property: clear_cache should handle empty cache gracefully.
    
    This test verifies that:
    1. Clearing an empty cache returns 0
    2. No exceptions are raised
    3. Subsequent operations work normally
    """
    # First ensure our test section is empty by clearing any test data
    test_cache.clear_cache(api_version="test-api", kind="TestKind", namespace="test-namespace")
    
    # Try to clear with specific filters that should match nothing
    cleared_count = test_cache.clear_cache(
        api_version="nonexistent-api/v1", 
        kind="NonexistentKind", 
        namespace="nonexistent-namespace"
    )
    
    # Should return 0 for empty result
    assert cleared_count == 0, "Clearing empty cache should return 0"
    
    # Verify cache operations still work after clearing empty cache
    test_resource = generate_k8s_resource("Pod", "test-after-clear", "default", "v1")
    
    try:
        # Store and retrieve should work normally
        test_cache.store_resource(test_resource)
        retrieved = test_cache.get_resource("v1", "Pod", "test-after-clear", "default")
        assert retrieved is not None, "Cache should work normally after clearing empty cache"
        assert retrieved == test_resource, "Retrieved resource should match stored resource"
        
    finally:
        # Clean up
        try:
            test_cache.delete_resource("v1", "Pod", "test-after-clear", "default")
        except:
            pass


def test_clear_cache_runtime_safety_check():
    """
    Test that clear_cache has runtime safety check to prevent production cache access.
    
    This test verifies that clear_cache prevents tests from accidentally
    accessing the production cache without using the test_cache fixture.
    """
    # Create a standard Cache instance (not marked as test_cache)
    temp_dir = tempfile.mkdtemp(prefix="cache_safety_test_clear_cache_")
    config = Config(config_dir=temp_dir)
    cache = Cache(config)
    
    # We're running in a test, so PYTEST_CURRENT_TEST should be set
    assert "PYTEST_CURRENT_TEST" in os.environ, "This test must be run with pytest"
    
    # Verify that the cache instance doesn't have the _is_test_cache attribute
    assert not hasattr(cache, "_is_test_cache"), "Cache instance should not have _is_test_cache attribute"
    
    try:
        # Attempt to clear cache - should raise RuntimeError since clear_cache has this check
        with pytest.raises(RuntimeError) as excinfo:
            cache.clear_cache()
        assert "CRITICAL ERROR: Attempting to clear production cache from a test" in str(excinfo.value)
        
    finally:
        # Clean up temporary directory
        import shutil
        shutil.rmtree(temp_dir)


@settings(suppress_health_check=[HealthCheck.function_scoped_fixture])
@given(
    resource_names_list=st.lists(resource_names, min_size=2, max_size=3, unique=True),
    namespace=namespaces,
    api_version=api_versions,
    kind=kinds
)
def test_clear_cache_return_value_property(test_cache, resource_names_list, namespace, api_version, kind):
    """
    Property: clear_cache should return accurate count of cleared items.
    
    This test verifies that:
    1. The return value matches the number of items actually cleared
    2. Multiple clear operations have consistent return values
    3. Zero is returned when no items match the filter
    """
    test_prefix = "test_clear_count"
    test_resources = []
    
    try:
        # Store known number of resources
        for i, resource_name in enumerate(resource_names_list):
            test_name = f"{test_prefix}_{resource_name}"
            test_resource = generate_k8s_resource(kind, test_name, namespace, api_version)
            test_cache.store_resource(test_resource)
            test_resources.append((test_name, test_resource))
        
        # Count resources before clearing
        resources_before = test_cache.list_resources(api_version=api_version, kind=kind, namespace=namespace)
        our_resources_before = [r for r in resources_before if r["metadata"]["name"].startswith(test_prefix)]
        expected_clear_count = len(our_resources_before)
        
        # Clear and check return value
        actual_clear_count = test_cache.clear_cache(api_version=api_version, kind=kind, namespace=namespace)
        
        # The actual count should be at least our expected count (might include other test data)
        assert actual_clear_count >= expected_clear_count, f"Should clear at least {expected_clear_count} items, actually cleared {actual_clear_count}"
        
        # Verify resources are actually gone
        resources_after = test_cache.list_resources(api_version=api_version, kind=kind, namespace=namespace)
        our_resources_after = [r for r in resources_after if r["metadata"]["name"].startswith(test_prefix)]
        assert len(our_resources_after) == 0, "All target resources should be cleared"
        
        # Clear again - should return 0 since nothing matches anymore
        second_clear_count = test_cache.clear_cache(api_version=api_version, kind=kind, namespace=namespace)
        # Note: This might not be 0 if other tests are running concurrently and adding data
        # But for our specific test prefix, there should be nothing left
        final_resources = test_cache.list_resources(api_version=api_version, kind=kind, namespace=namespace)
        final_our_resources = [r for r in final_resources if r["metadata"]["name"].startswith(test_prefix)]
        assert len(final_our_resources) == 0, "Second clear should find no test resources"
    
    finally:
        # Clean up any remaining test data (in case test failed)
        for test_name, _ in test_resources:
            try:
                test_cache.delete_resource(api_version, kind, test_name, namespace)
            except:
                pass