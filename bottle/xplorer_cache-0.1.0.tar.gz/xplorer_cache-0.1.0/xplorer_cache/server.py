"""
API server implementation for Xplorer-Cache.
"""

import json
import logging
import os
import threading
import time
from typing import Dict, Any, Optional, Callable

import requests
from flask import Flask, request, Response, jsonify
from kubernetes import client, config
from werkzeug.serving import make_server

from xplorer_cache.cache import Cache
from xplorer_cache.config import Config

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class Server:
    """API server for Xplorer-Cache."""

    def __init__(self, config_obj: Config, cache_obj: Cache):
        """Initialize the server.

        Args:
            config_obj: Configuration manager.
            cache_obj: Cache manager.
        """
        self.config = config_obj
        self.cache = cache_obj
        self.app = Flask(__name__)
        self.server = None
        self.server_thread = None
        self.is_running = False
        self.k8s_client = None
        self.stop_event = threading.Event()

        # Set up routes
        self._setup_routes()

    def _setup_routes(self):
        """Set up Flask routes."""
        # Kubernetes API proxy routes
        self.app.route('/<path:path>', methods=['GET', 'POST', 'PUT', 'DELETE', 'PATCH'])(self._proxy_request)

        # Admin API routes
        self.app.route('/admin/api/v1/status', methods=['GET'])(self._get_status)
        self.app.route('/admin/api/v1/config/endpoints', methods=['GET'])(self._get_endpoints)
        self.app.route('/admin/api/v1/config/endpoints', methods=['PUT'])(self._update_endpoints)
        self.app.route('/admin/api/v1/cache/resources', methods=['GET'])(self._get_resources)
        self.app.route('/admin/api/v1/cache/resources', methods=['DELETE'])(self._clear_resources)
        self.app.route('/admin/api/v1/server/stop', methods=['POST'])(self._stop_server)

    def _initialize_k8s_client(self):
        """Initialize Kubernetes client."""
        try:
            k8s_config = self.config.get("kubernetes", {})
            if k8s_config.get("use_kubeconfig", True):
                kubeconfig_path = k8s_config.get("kubeconfig_path", os.path.expanduser("~/.kube/config"))
                context = k8s_config.get("context")

                if context:
                    config.load_kube_config(config_file=kubeconfig_path, context=context)
                else:
                    config.load_kube_config(config_file=kubeconfig_path)
            else:
                # In-cluster configuration
                config.load_incluster_config()

            self.k8s_client = client.ApiClient()
            logger.info("Kubernetes client initialized successfully")
        except Exception as e:
            logger.error(f"Error initializing Kubernetes client: {e}")
            raise

    def start(self, host: str = None, port: int = None):
        """Start the server.

        Args:
            host: Host to bind the server to.
            port: Port to run the server on.
        """
        if self.is_running:
            logger.warning("Server is already running")
            return

        # Get host and port from config if not provided
        host = host or self.config.get("server.host", "127.0.0.1")
        port = port or self.config.get("server.port", 8080)

        # Initialize Kubernetes client
        self._initialize_k8s_client()

        # Create server
        self.server = make_server(host, port, self.app)
        self.server_thread = threading.Thread(target=self.server.serve_forever)
        self.server_thread.daemon = True
        self.server_thread.start()

        self.is_running = True
        logger.info(f"Server started on {host}:{port}")

    def stop(self):
        """Stop the server."""
        if not self.is_running:
            logger.warning("Server is not running")
            return

        if self.server:
            self.server.shutdown()
            self.is_running = False
            # Signal that the server has been stopped
            self.stop_event.set()
            logger.info("Server stopped")

    def _proxy_request(self, path):
        """Proxy request to Kubernetes API or serve from cache.

        Args:
            path: Request path.

        Returns:
            Flask response.
        """
        # Determine endpoint mode
        endpoint = f"/{path}"
        mode = self.config.get_endpoint_mode(endpoint)

        # Get request details
        method = request.method
        headers = {key: value for key, value in request.headers if key != 'Host'}
        data = request.get_data()
        params = request.args

        logger.info(f"Proxying {method} request to {endpoint} in {mode} mode")

        if mode == "cache":
            # Serve from cache
            return self._serve_from_cache(endpoint, method, params)
        elif mode == "live":
            # Proxy to live cluster
            return self._proxy_to_live(endpoint, method, headers, params, data)
        elif mode == "hybrid":
            # Try cache first, then live
            cache_response = self._serve_from_cache(endpoint, method, params)
            if cache_response.status_code == 404:
                return self._proxy_to_live(endpoint, method, headers, params, data)
            return cache_response
        else:
            return jsonify({"error": f"Invalid mode: {mode}"}), 400

    def _serve_from_cache(self, endpoint: str, method: str, params: Dict[str, Any]):
        """Serve request from cache.

        Args:
            endpoint: Request endpoint.
            method: HTTP method.
            params: Request parameters.

        Returns:
            Flask response.
        """
        # Parse endpoint to extract resource details
        # This is a simplified implementation and would need to be expanded
        # to handle all Kubernetes API paths correctly
        parts = endpoint.strip('/').split('/')

        if len(parts) < 2:
            return jsonify({"error": "Invalid endpoint"}), 400

        if parts[0] == "api":
            # Core API
            if parts[1] == "v1":
                if len(parts) >= 3:
                    kind = parts[2].capitalize()
                    api_version = "v1"

                    if len(parts) >= 4:
                        name = parts[3]

                        if len(parts) >= 5 and parts[4] == "namespaces" and len(parts) >= 6:
                            namespace = parts[5]
                            if len(parts) >= 7:
                                kind = parts[6].capitalize()
                                if len(parts) >= 8:
                                    name = parts[7]
                                else:
                                    name = None
                        else:
                            namespace = None
                    else:
                        name = None
                        namespace = None
                else:
                    return jsonify({"error": "Invalid endpoint"}), 400
        elif parts[0] == "apis":
            # Extensions API
            if len(parts) >= 3:
                group = parts[1]
                version = parts[2]
                api_version = f"{group}/{version}"

                if len(parts) >= 4:
                    kind = parts[3].capitalize()

                    if len(parts) >= 5:
                        name = parts[4]

                        if len(parts) >= 6 and parts[5] == "namespaces" and len(parts) >= 7:
                            namespace = parts[6]
                            if len(parts) >= 8:
                                kind = parts[7].capitalize()
                                if len(parts) >= 9:
                                    name = parts[8]
                                else:
                                    name = None
                        else:
                            namespace = None
                    else:
                        name = None
                        namespace = None
                else:
                    return jsonify({"error": "Invalid endpoint"}), 400
            else:
                return jsonify({"error": "Invalid endpoint"}), 400
        else:
            return jsonify({"error": "Invalid endpoint"}), 400

        # Handle different HTTP methods
        if method == "GET":
            if name:
                # Get specific resource
                resource = self.cache.get_resource(api_version, kind, name, namespace)
                if resource:
                    return jsonify(resource)
                else:
                    return jsonify({"error": "Resource not found"}), 404
            else:
                # List resources
                resources = self.cache.list_resources(api_version, kind, namespace)

                # Format response as Kubernetes list
                items = resources
                response = {
                    "apiVersion": api_version,
                    "kind": f"{kind}List",
                    "items": items
                }
                return jsonify(response)
        elif method == "DELETE":
            if name:
                # Delete specific resource
                success = self.cache.delete_resource(api_version, kind, name, namespace)
                if success:
                    return "", 204
                else:
                    return jsonify({"error": "Resource not found"}), 404
            else:
                # Delete all resources of this type
                count = self.cache.clear_cache(api_version, kind, namespace)
                return jsonify({"deleted": count}), 200
        else:
            # Other methods not supported from cache
            return jsonify({"error": f"Method {method} not supported in cache mode"}), 405

    def _proxy_to_live(self, endpoint: str, method: str, headers: Dict[str, str], params: Dict[str, Any], data: bytes):
        """Proxy request to live Kubernetes cluster.

        Args:
            endpoint: Request endpoint.
            method: HTTP method.
            headers: Request headers.
            params: Request parameters.
            data: Request body.

        Returns:
            Flask response.
        """
        if not self.k8s_client:
            return jsonify({"error": "Kubernetes client not initialized"}), 500

        # Build the full URL
        host = self.k8s_client.configuration.host
        url = f"{host}{endpoint}"

        try:
            # Make the request to the Kubernetes API
            response = requests.request(
                method=method,
                url=url,
                headers=headers,
                params=params,
                data=data,
                verify=self.k8s_client.configuration.verify_ssl,
                cert=(
                    self.k8s_client.configuration.cert_file,
                    self.k8s_client.configuration.key_file
                ) if self.k8s_client.configuration.cert_file else None,
                timeout=30
            )

            # Store response in cache if it's a successful GET request
            if method == "GET" and response.status_code == 200:
                try:
                    resource_data = response.json()

                    # Check if it's a single resource or a list
                    if "kind" in resource_data and not resource_data["kind"].endswith("List"):
                        # Single resource
                        self.cache.store_resource(resource_data)
                    elif "items" in resource_data and isinstance(resource_data["items"], list):
                        # Resource list
                        for item in resource_data["items"]:
                            self.cache.store_resource(item)
                except Exception as e:
                    logger.error(f"Error storing response in cache: {e}")

            # Create Flask response
            return Response(
                response=response.content,
                status=response.status_code,
                headers=dict(response.headers)
            )
        except Exception as e:
            logger.error(f"Error proxying request to Kubernetes API: {e}")
            return jsonify({"error": str(e)}), 500

    def _get_status(self):
        """Get server status.

        Returns:
            Flask response with server status.
        """
        status = {
            "server": {
                "running": self.is_running,
                "host": self.config.get("server.host", "127.0.0.1"),
                "port": self.config.get("server.port", 8080),
            },
            "cache": self.cache.get_cache_stats(),
            "kubernetes": {
                "connected": self.k8s_client is not None,
                "context": self.config.get("kubernetes.context"),
            }
        }
        return jsonify(status)

    def _get_endpoints(self):
        """Get endpoint configurations.

        Returns:
            Flask response with endpoint configurations.
        """
        endpoints = {
            "default_mode": self.config.get("endpoints.default_mode", "live"),
            "rules": self.config.get_all_endpoint_rules()
        }
        return jsonify(endpoints)

    def _update_endpoints(self):
        """Update endpoint configurations.

        Returns:
            Flask response with updated endpoint configurations.
        """
        data = request.json

        if not data or not isinstance(data, dict):
            return jsonify({"error": "Invalid request data"}), 400

        if "default_mode" in data:
            self.config.set("endpoints.default_mode", data["default_mode"])

        if "rules" in data and isinstance(data["rules"], list):
            for rule in data["rules"]:
                if "endpoint" in rule and "mode" in rule:
                    self.config.set_endpoint_mode(rule["endpoint"], rule["mode"])

        return self._get_endpoints()

    def _get_resources(self):
        """Get cached resources.

        Returns:
            Flask response with cached resources.
        """
        api_version = request.args.get("apiVersion")
        kind = request.args.get("kind")
        namespace = request.args.get("namespace")

        resources = self.cache.list_resources(api_version, kind, namespace)
        return jsonify({"resources": resources})

    def _clear_resources(self):
        """Clear cached resources.

        Returns:
            Flask response with number of resources cleared.
        """
        api_version = request.args.get("apiVersion")
        kind = request.args.get("kind")
        namespace = request.args.get("namespace")

        count = self.cache.clear_cache(api_version, kind, namespace)
        return jsonify({"cleared": count})

    def _stop_server(self):
        """Stop the server via API.

        Returns:
            Flask response indicating the server is stopping.
        """
        # Schedule server shutdown to happen after response is sent
        def shutdown_server():
            time.sleep(1)  # Small delay to ensure response is sent
            self.stop()

        threading.Thread(target=shutdown_server, daemon=True).start()
        return jsonify({"status": "Server is shutting down"}), 200
