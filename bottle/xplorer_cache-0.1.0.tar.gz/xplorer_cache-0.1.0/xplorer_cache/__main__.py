"""
Main entry point for the xplorer-cache package when run as a module.
"""

import sys
from setproctitle import setproctitle
from xplorer_cache.cli import main as cli_main

def main():
    """Main entry point for running the application."""
    # Set process title
    setproctitle("xplorer-cache-cli")
    
    # Run the CLI
    cli_main()

if __name__ == "__main__":
    main()
