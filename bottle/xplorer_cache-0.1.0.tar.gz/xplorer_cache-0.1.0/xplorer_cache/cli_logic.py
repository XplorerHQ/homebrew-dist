"""
Business logic for CLI commands, separated from the CLI interface for better testability.
"""

import os
import sys
import json
import signal
import time
import psutil
import requests
import subprocess
import tempfile
# import inspect - removed as part of refactoring
from typing import Optional, Dict, Any, Tuple, List, ContextManager
from dataclasses import dataclass

import uvicorn
import setproctitle
from loguru import logger

from xplorer_cache.config import Config
from xplorer_cache.server.commands import build_uvicorn_command
from xplorer_cache.server.resources import capture_output_files, cleanup_temp_files
from xplorer_cache.server.process import (
    handle_failed_process,
    start_daemon_process,
    handle_server_already_running
)
from xplorer_cache.server.shutdown import stop_server
from xplorer_cache.server.server_info import get_pid_file_path, read_server_info, write_server_info





def is_server_running() -> bool:
    """Check if the server is running.
    
    First checks if we can connect to the server via HTTP, even if PID file is missing.
    If HTTP check fails, falls back to checking the process by PID (if available).

    Returns:
        True if the server is running, False otherwise.
    """
    # Try to get server info from PID file
    server_info = read_server_info()
    
    # Try common server locations even if we don't have a PID file
    # Start with default values
    host = "127.0.0.1"
    port = 4433
    
    # Use values from server_info if available
    if server_info:
        host = server_info.get("host", host)
        port = server_info.get("port", port)
    
    # First, try HTTP connection regardless of whether we have server_info
    try:
        # Try to connect to the root endpoint with a short timeout
        response = requests.get(f"http://{host}:{port}", timeout=2)
        if response.status_code == 200 and "running" in response.text.lower():
            return True
    except requests.RequestException:
        # HTTP request failed, fall back to process check if we have PID info
        logger.debug("HTTP check failed, falling back to process check")
        pass
    
    # If HTTP check failed and we have server info, try to check the process
    if server_info:
        try:
            pid = server_info.get("pid")
            if not pid:
                return False

            # Check if process exists
            process = psutil.Process(pid)
            return process.is_running()
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            return False
    
    # Both HTTP check and PID check (if available) failed
    return False


def init_server() -> Tuple[bool, str]:
    """Initialize the server and database.
    
    Returns:
        Tuple of (success, message)
    """
    # TODO: Implement initialization logic
    return True, "Initialization complete!"


def reset_cache_if_requested(reset_cache: bool) -> Tuple[bool, Optional[str]]:
    """Reset the cache if requested.
    
    Args:
        reset_cache: Whether to reset the cache.
        
    Returns:
        Tuple of (success, error_message).
    """
    if not reset_cache:
        return True, None
    
    try:
        # Import here to avoid circular imports
        from xplorer_cache.cache import Cache
        config = Config()
        cache = Cache(config)
        # Clear everything by not providing any filters
        cache.clear_cache()
        logger.info("Cache has been reset")
        return True, None
    except Exception as e:
        logger.error(f"Error resetting cache: {e}")
        return False, f"Error resetting cache: {e}"


def update_cache_mode(cache_mode: str) -> Tuple[bool, Optional[str]]:
    """Update the default cache mode in the configuration.
    
    Args:
        cache_mode: Default caching mode ("live", "cache", or "hybrid").
        
    Returns:
        Tuple of (success, error_message).
    """
    try:
        config = Config()
        config.set("endpoints.default_mode", cache_mode)
        logger.info(f"Default cache mode set to {cache_mode}")
        return True, None
    except Exception as e:
        logger.error(f"Error setting default cache mode: {e}")
        return False, f"Error setting default cache mode: {e}"


# The helper functions have been moved to their respective modules in the server package


def start_server_daemon(host: str, port: int, reload: bool) -> Tuple[bool, str, Optional[int]]:
    """Start the server in daemon mode.
    
    Args:
        host: Host to bind to.
        port: Port to bind to.
        reload: Whether to enable auto-reload.
        
    Returns:
        Tuple of (success, message, pid).
    """
    # Import here to avoid circular imports
    from .server.config import ServerConfig
    from .server.environment import default_env
    
    # Create server configuration and use _start_daemon_mode
    config = ServerConfig(host, port, reload, False)  # daemon=False since that's already handled
    
    return _start_daemon_mode(config, default_env)


def _start_foreground_mode(config, env):
    """Start server in foreground mode.
    
    Args:
        config: ServerConfig object with server parameters
        env: Environment dictionary with server dependencies
        
    Returns:
        Tuple of (success, message, pid)
    """
    try:
        # Write PID file
        env['write_server_info'](os.getpid(), config.host, config.port)
        return True, f"Starting server on {config.host}:{config.port}", os.getpid()
    except Exception as e:
        return False, f"Error running server: {e}", None


def _start_daemon_mode(config, env):
    """Start server in daemon mode.
    
    Args:
        config: ServerConfig object with server parameters
        env: Environment dictionary with server dependencies
        
    Returns:
        Tuple of (success, message, pid)
    """
    # Build the command
    cmd = build_uvicorn_command(config.host, config.port, config.reload)
    
    # Use temporary files to capture output
    with capture_output_files() as (stdout_path, stderr_path):
        # Start the process
        success, message, pid = env['start_daemon_process'](cmd, stdout_path, stderr_path)
        
        if success and pid:
            # Write PID file
            env['write_server_info'](pid, config.host, config.port)
            return True, f"Server started in background on {config.host}:{config.port}!", pid
        else:
            return success, message, pid


def start_server(host: str, port: int, reload: bool, daemon: bool) -> Tuple[bool, str, Optional[int]]:
    """Start the server.
    
    Args:
        host: Host to bind to.
        port: Port to bind to.
        reload: Whether to enable auto-reload.
        daemon: Whether to run as a daemon.
        
    Returns:
        Tuple of (success, message, pid)
    """
    # Import here to avoid circular imports
    from .server.environment import default_env
    from .server.config import ServerConfig
    
    # Create server configuration
    config = ServerConfig(host, port, reload, daemon)
    
    # Check if server is already running
    if default_env['is_server_running']():
        return default_env['handle_server_already_running']()

    # Choose appropriate startup method
    if config.daemon:
        return _start_daemon_mode(config, default_env)
    else:
        return _start_foreground_mode(config, default_env)


def run_uvicorn_server(host: str, port: int, reload: bool):
    """Run the Uvicorn server in the current process.
    
    This function blocks until the server is stopped.
    """
    import signal
    import multiprocessing
    
    def cleanup_resources():
        """Clean up multiprocessing resources to prevent leaks."""
        try:
            # Force cleanup of multiprocessing resources
            multiprocessing.util._exit_function()
        except (AttributeError, RuntimeError):
            pass
    
    def signal_handler(signum, frame):
        """Handle termination signals gracefully."""
        logger.info(f"Received signal {signum}, initiating shutdown...")
        cleanup_resources()
        sys.exit(0)
    
    # Register signal handlers for graceful shutdown
    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGINT, signal_handler)
    
    try:
        uvicorn.run(
            "xplorer_cache.main:app",
            host=host,
            port=port,
            reload=reload,
            reload_includes=["*.py"],
            workers=1,
            log_level="info",
            access_log=False  # Reduce resource usage
        )
    except KeyboardInterrupt:
        logger.info("Received keyboard interrupt")
    except Exception as e:
        logger.error(f"Server error: {e}")
    finally:
        logger.info("Cleaning up server resources...")
        cleanup_resources()
        
        # Remove PID file
        try:
            os.remove(get_pid_file_path())
        except OSError:
            pass




def get_server_status() -> Dict[str, Any]:
    """Get the server status.
    
    Returns:
        Dict with server status information.
    """
    server_running = is_server_running()
    server_info = read_server_info()
    
    status = {
        "running": server_running,
        "server": None,
        "database": None,
        "cache": None,
        "cache_stats": None
    }
    
    if server_running:
        # Set default host and port if PID file is missing
        host = "127.0.0.1"
        port = 4433
        pid = None
        
        # If server_info is available, use those values
        if server_info:
            host = server_info.get("host", host)
            port = server_info.get("port", port)
            pid = server_info.get("pid")
        
        status["server"] = {
            "host": host,
            "port": port,
            "pid": pid,
            "pid_file": "Missing" if not server_info else "Present"
        }
        
        try:
            # Initialize configuration to get database info
            config_obj = Config()
            db_type = config_obj.get("database.type", "sqlite")
            db_path = config_obj.get("database.path", "~/.xplorer-cache/cache.db")
            
            status["database"] = {
                "status": "Connected",
                "type": db_type,
                "path": db_path
            }
            
            status["cache"] = {
                "status": "Active"
            }
            
            # Get cache statistics
            status["cache_stats"] = {
                "total_resources": 0,
                "cache_size": "0 MB",
                "hit_rate": "0%"
            }
        except Exception as e:
            logger.error(f"Error getting configuration: {e}")
            status["database"] = {"status": "Unknown"}
            status["cache"] = {"status": "Unknown"}
    else:
        status["database"] = {"status": "Disconnected"}
        status["cache"] = {"status": "Inactive"}
    
    return status


def list_config() -> List[Dict[str, str]]:
    """List current endpoint configurations.
    
    Returns:
        List of dictionaries with endpoint configurations.
    """
    # TODO: Implement actual config listing
    return [
        {"endpoint": "/api/v1/namespaces", "mode": "Live"},
        {"endpoint": "/api/v1/pods", "mode": "Cache"},
        {"endpoint": "/apis/apps/v1/deployments", "mode": "Hybrid"}
    ]


def set_config(endpoint: str, mode: str) -> Tuple[bool, str]:
    """Configure endpoint routing.
    
    Args:
        endpoint: The endpoint to configure.
        mode: The mode to set (live/cache/hybrid).
        
    Returns:
        Tuple of (success, message)
    """
    # TODO: Implement actual config setting
    return True, f"Endpoint {endpoint} set to {mode} mode!"


def list_cache(resource: Optional[str] = None) -> List[Dict[str, str]]:
    """List cached resources.
    
    Args:
        resource: Optional resource type to filter by.
        
    Returns:
        List of dictionaries with cached resources.
    """
    # TODO: Implement actual cache listing
    resources = [
        {"resource": "namespaces", "count": "5", "last_updated": "2023-01-01 12:00:00"},
        {"resource": "pods", "count": "20", "last_updated": "2023-01-01 12:00:00"},
        {"resource": "deployments", "count": "10", "last_updated": "2023-01-01 12:00:00"}
    ]
    
    if resource:
        return [r for r in resources if r["resource"] == resource]
    return resources


def show_cache(resource: str, name: Optional[str] = None, namespace: Optional[str] = None) -> Dict[str, Any]:
    """Show details of a cached resource.
    
    Args:
        resource: The resource type.
        name: Optional resource name.
        namespace: Optional namespace.
        
    Returns:
        Dictionary with resource details.
    """
    # TODO: Implement actual cache detail showing
    if not name:
        return {"error": "Resource name is required"}
    
    return {
        "resource": resource,
        "name": name,
        "namespace": namespace,
        "status": "Active"
    }


def clear_cache(resource: Optional[str] = None) -> Tuple[bool, str]:
    """Clear specific resources from cache.
    
    Args:
        resource: Optional resource type to clear.
        
    Returns:
        Tuple of (success, message)
    """
    # TODO: Implement actual cache clearing
    if resource:
        return True, f"{resource} cleared from cache!"
    else:
        return True, "All resources cleared from cache!"


def export_cache(file: str) -> Tuple[bool, str]:
    """Export cache to a file.
    
    Args:
        file: The file to export to.
        
    Returns:
        Tuple of (success, message)
    """
    # TODO: Implement actual cache exporting
    return True, f"Cache exported to {file}!"


def import_cache(file: str) -> Tuple[bool, str]:
    """Import cache from a file.
    
    Args:
        file: The file to import from.
        
    Returns:
        Tuple of (success, message)
    """
    # TODO: Implement actual cache importing
    return True, f"Cache imported from {file}!"
