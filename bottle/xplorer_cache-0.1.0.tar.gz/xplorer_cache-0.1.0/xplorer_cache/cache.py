"""
Cache management for Xplorer-Cache.
"""

import orjson
import os
import time
from datetime import datetime
from typing import Dict, List, Any, Optional, Tuple

from kubernetes import client
from sqlalchemy import create_engine, Column, Integer, String, Text, DateTime, Boolean, ForeignKey, func, event
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import sessionmaker, relationship

from xplorer_cache.config import Config
from xplorer_cache.core.system_logger import get_system_logger

Base = declarative_base()


class Resource(Base):
    """SQLAlchemy model for cached Kubernetes resources."""

    __tablename__ = "resources"

    id = Column(Integer, primary_key=True)
    api_version = Column(String(100), nullable=False)
    kind = Column(String(100), nullable=False)
    name = Column(String(255), nullable=False)
    namespace = Column(String(255), nullable=True)
    uid = Column(String(255), nullable=False, unique=True)
    resource_version = Column(String(100), nullable=False)
    data = Column(Text, nullable=False)  # JSON serialized resource data
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def __repr__(self):
        return f"<Resource(kind='{self.kind}', name='{self.name}', namespace='{self.namespace}')>"


class CachedResponse(Base):
    """SQLAlchemy model for cached API responses."""

    __tablename__ = "cached_responses"

    id = Column(Integer, primary_key=True)
    cache_key = Column(String(255), nullable=False, unique=True, index=True)
    data = Column(Text, nullable=False)  # JSON serialized response data
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def __repr__(self):
        return f"<CachedResponse(cache_key='{self.cache_key}')>"


class Cache:
    """Cache manager for Kubernetes resources."""

    def __init__(self, config: Config):
        """Initialize the cache manager.

        Args:
            config: Configuration manager.
        """
        self.config = config
        self.engine = self._create_engine()
        self.Session = sessionmaker(bind=self.engine)
        self._create_tables()
        self._warm_database_cache()

    def _create_engine(self):
        """Create SQLAlchemy engine based on configuration.

        Returns:
            SQLAlchemy engine.
        """
        db_config = self.config.get("database", {})
        db_type = db_config.get("type", "sqlite")

        if db_type == "sqlite":
            db_path = db_config.get("path", os.path.join(self.config.config_dir, "cache.db"))
            
            # SQLite performance optimizations
            engine_options = {
                'echo': False,
                'pool_pre_ping': True,
                'connect_args': {
                    'check_same_thread': False,
                    'isolation_level': None,  # Enable autocommit mode
                }
            }
            
            engine = create_engine(f"sqlite:///{db_path}", **engine_options)
            
            # Apply SQLite PRAGMA settings for performance
            @event.listens_for(engine, "connect")
            def set_sqlite_pragma(dbapi_connection, connection_record):
                cursor = dbapi_connection.cursor()
                # Enable WAL mode for better concurrent reads
                cursor.execute("PRAGMA journal_mode=WAL")
                # Increase cache size (10MB)
                cursor.execute("PRAGMA cache_size=10000")
                # Balance safety vs speed
                cursor.execute("PRAGMA synchronous=NORMAL")
                # Use memory for temporary storage
                cursor.execute("PRAGMA temp_store=MEMORY")
                # Enable memory mapping (256MB)
                cursor.execute("PRAGMA mmap_size=268435456")
                # Optimize query planner
                cursor.execute("PRAGMA optimize")
                cursor.close()
            
            return engine
            
        elif db_type == "postgresql":
            host = db_config.get("host", "localhost")
            port = db_config.get("port", 5432)
            user = db_config.get("user", "postgres")
            password = db_config.get("password", "")
            database = db_config.get("database", "xplorer_cache")
            return create_engine(f"postgresql://{user}:{password}@{host}:{port}/{database}")
        else:
            raise ValueError(f"Unsupported database type: {db_type}")

    def _create_tables(self):
        """Create database tables if they don't exist."""
        Base.metadata.create_all(self.engine)

    def _warm_database_cache(self):
        """Warm up OS file system cache by reading the entire database file.
        
        This forces the OS to load the SQLite database files into memory,
        eliminating cold start performance issues for the first requests.
        """
        try:
            db_config = self.config.get("database", {})
            db_type = db_config.get("type", "sqlite")
            
            if db_type == "sqlite":
                db_path = db_config.get("path", os.path.join(self.config.config_dir, "cache.db"))
                
                # Track files read and bytes for logging
                files_warmed = []
                total_bytes = 0
                
                # Read main database file
                if os.path.exists(db_path):
                    with open(db_path, 'rb') as f:
                        data = f.read()  # Read entire file into OS cache
                        total_bytes += len(data)
                        files_warmed.append(f"cache.db ({len(data)//1024//1024}MB)")
                
                # Also warm WAL and SHM files if they exist
                for suffix in ['-wal', '-shm']:
                    auxiliary_path = db_path + suffix
                    if os.path.exists(auxiliary_path):
                        with open(auxiliary_path, 'rb') as f:
                            data = f.read()
                            total_bytes += len(data)
                            size_mb = len(data) // 1024 // 1024 if len(data) > 1024*1024 else 0
                            size_str = f"{size_mb}MB" if size_mb > 0 else f"{len(data)//1024}KB"
                            files_warmed.append(f"{os.path.basename(auxiliary_path)} ({size_str})")
                
                if files_warmed:
                    self._log_info(f"Cache warmup: Loaded {', '.join(files_warmed)} into OS cache ({total_bytes//1024//1024}MB total)")
                else:
                    self._log_info("Cache warmup: No database files found to warm")
            else:
                # Non-SQLite databases don't need file-based warmup
                self._log_info(f"Cache warmup: Skipped for {db_type} database (not file-based)")
                
        except Exception as e:
            # Log error but don't fail initialization
            self._log_error(f"Cache warmup failed: {e}")

    def _database_session(self):
        """Create a database session context manager.
        
        Returns:
            Database session context manager that handles rollback on exceptions.
        """
        from contextlib import contextmanager
        
        @contextmanager
        def session_context():
            session = self.Session()
            try:
                yield session
                session.commit()
            except Exception:
                session.rollback()
                raise
            finally:
                session.close()
        
        return session_context()

    def _read_only_session(self):
        """Create a read-only database session context manager.
        
        Returns:
            Database session context manager for read operations only.
        """
        from contextlib import contextmanager
        
        @contextmanager
        def session_context():
            session = self.Session()
            try:
                yield session
                # No commit for read-only operations
            except Exception:
                session.rollback()
                raise
            finally:
                session.close()
        
        return session_context()

    def _log_error(self, message: str) -> None:
        """Log an error message with consistent formatting.
        
        Args:
            message: Error message to log.
        """
        logger = get_system_logger()
        logger.error(message)
    
    def _log_info(self, message: str) -> None:
        """Log an info message with consistent formatting.
        
        Args:
            message: Info message to log.
        """
        logger = get_system_logger()
        logger.info(message)

    def _query_single_resource(self, session, api_version: str, kind: str, name: str, namespace: Optional[str]) -> Optional[Dict[str, Any]]:
        """Query a single resource from the database.
        
        Args:
            session: Database session.
            api_version: API version of the resource.
            kind: Kind of the resource.
            name: Name of the resource.
            namespace: Namespace of the resource (if applicable).
            
        Returns:
            Resource dict or None if not found.
        """
        try:
            query = session.query(Resource).filter_by(
                api_version=api_version,
                kind=kind,
                name=name
            )

            if namespace is not None:
                query = query.filter_by(namespace=namespace)

            resource = query.first()

            if resource:
                return orjson.loads(resource.data)
            return None
        except Exception as e:
            self._log_error(f"Error getting resource {kind}/{name}: {e}")
            return None

    def _query_filtered_resources(self, session, api_version: Optional[str], kind: Optional[str], namespace: Optional[str]) -> List[Dict[str, Any]]:
        """Query filtered resources from the database.
        
        Args:
            session: Database session.
            api_version: Filter by API version.
            kind: Filter by kind.
            namespace: Filter by namespace.
            
        Returns:
            List of resource dicts.
        """
        try:
            query = session.query(Resource)

            if api_version:
                query = query.filter_by(api_version=api_version)

            if kind:
                query = query.filter_by(kind=kind)

            if namespace:
                query = query.filter_by(namespace=namespace)

            resources = query.all()

            return [orjson.loads(resource.data) for resource in resources]
        except Exception as e:
            self._log_error(f"Error listing resources (api_version={api_version}, kind={kind}, namespace={namespace}): {e}")
            return []

    def _delete_single_resource(self, session, api_version: str, kind: str, name: str, namespace: Optional[str]) -> bool:
        """Delete a single resource from the database.
        
        Args:
            session: Database session.
            api_version: API version of the resource.
            kind: Kind of the resource.
            name: Name of the resource.
            namespace: Namespace of the resource (if applicable).
            
        Returns:
            True if resource was deleted, False otherwise.
        """
        try:
            query = session.query(Resource).filter_by(
                api_version=api_version,
                kind=kind,
                name=name
            )

            if namespace is not None:
                query = query.filter_by(namespace=namespace)

            resource = query.first()

            if resource:
                session.delete(resource)
                return True
            return False
        except Exception as e:
            self._log_error(f"Error deleting resource {kind}/{name}: {e}")
            return False

    def _clear_filtered_cache(self, session, api_version: Optional[str], kind: Optional[str], namespace: Optional[str]) -> int:
        """Clear filtered resources and responses from the cache.
        
        Args:
            session: Database session.
            api_version: Filter by API version.
            kind: Filter by kind.
            namespace: Filter by namespace.
            
        Returns:
            Number of resources deleted.
        """
        try:
            # Clear resources with filters
            resource_query = session.query(Resource)

            if api_version:
                resource_query = resource_query.filter_by(api_version=api_version)

            if kind:
                resource_query = resource_query.filter_by(kind=kind)

            if namespace:
                resource_query = resource_query.filter_by(namespace=namespace)

            resource_count = resource_query.count()
            resource_query.delete()
            
            # Clear cached responses (no filtering for responses)
            response_query = session.query(CachedResponse)
            response_count = response_query.count()
            response_query.delete()

            return resource_count + response_count
        except Exception as e:
            self._log_error(f"Error clearing cache (api_version={api_version}, kind={kind}, namespace={namespace}): {e}")
            return 0

    def _validate_resource_fields(self, resource: Dict[str, Any]) -> None:
        """Validate that a resource has all required fields.
        
        Args:
            resource: Kubernetes resource dict to validate.
            
        Raises:
            ValueError: If resource is missing required fields.
        """
        api_version = resource.get("apiVersion", "")
        kind = resource.get("kind", "")
        metadata = resource.get("metadata", {})
        name = metadata.get("name", "")
        uid = metadata.get("uid", "")
        resource_version = metadata.get("resourceVersion", "")

        if not all([api_version, kind, name, uid, resource_version]):
            missing_fields = []
            if not api_version:
                missing_fields.append("apiVersion")
            if not kind:
                missing_fields.append("kind")
            if not name:
                missing_fields.append("metadata.name")
            if not uid:
                missing_fields.append("metadata.uid")
            if not resource_version:
                missing_fields.append("metadata.resourceVersion")
            
            raise ValueError(f"Resource is missing required fields: {', '.join(missing_fields)}")

    def _extract_resource_metadata(self, resource: Dict[str, Any]) -> tuple:
        """Extract metadata fields from a Kubernetes resource.
        
        Args:
            resource: Kubernetes resource dict.
            
        Returns:
            Tuple of (api_version, kind, name, namespace, uid, resource_version).
        """
        api_version = resource["apiVersion"]
        kind = resource["kind"]
        metadata = resource["metadata"]
        name = metadata["name"]
        namespace = metadata.get("namespace")
        uid = metadata["uid"]
        resource_version = metadata["resourceVersion"]
        
        return api_version, kind, name, namespace, uid, resource_version

    def _upsert_resource(self, session, resource: Dict[str, Any], 
                        api_version: str, kind: str, name: str, 
                        namespace: Optional[str], uid: str, resource_version: str) -> None:
        """Insert or update a resource in the database.
        
        Args:
            session: Database session.
            resource: Complete resource dict to store.
            api_version: API version of the resource.
            kind: Kind of the resource.
            name: Name of the resource.
            namespace: Namespace of the resource (if applicable).
            uid: UID of the resource.
            resource_version: Resource version.
        """
        # Check if resource already exists
        existing = session.query(Resource).filter_by(uid=uid).first()

        if existing:
            # Update existing resource
            existing.api_version = api_version
            existing.kind = kind
            existing.name = name
            existing.namespace = namespace
            existing.resource_version = resource_version
            existing.data = orjson.dumps(resource).decode('utf-8')
            existing.updated_at = datetime.utcnow()
        else:
            # Create new resource
            new_resource = Resource(
                api_version=api_version,
                kind=kind,
                name=name,
                namespace=namespace,
                uid=uid,
                resource_version=resource_version,
                data=orjson.dumps(resource).decode('utf-8')
            )
            session.add(new_resource)

    def store_resource(self, resource: Dict[str, Any]) -> None:
        """Store a Kubernetes resource in the cache.

        Args:
            resource: Kubernetes resource dict.
            
        Raises:
            ValueError: If resource is missing required fields.
            RuntimeError: If accessed from a test without using the test_cache fixture.
        """
        # Check if running in test environment - if so, this is likely a mistake
        if "PYTEST_CURRENT_TEST" in os.environ and not hasattr(self, "_is_test_cache"):
            # This is the global instance, fail loudly to alert the developer
            raise RuntimeError(
                "CRITICAL ERROR: Attempting to modify production cache from a test!\n"
                "You MUST use the test_cache fixture from conftest.py to isolate test data.\n"
                "Tests should NEVER interact with the global production cache.\n"
                "Fix this by updating your test to use the test_cache fixture."
            )
        
        # Validate resource has all required fields
        self._validate_resource_fields(resource)
        
        # Extract metadata fields
        api_version, kind, name, namespace, uid, resource_version = self._extract_resource_metadata(resource)
        
        # Store or update resource using database session context manager
        with self._database_session() as session:
            self._upsert_resource(session, resource, api_version, kind, name, namespace, uid, resource_version)

    def get_resource(self, api_version: str, kind: str, name: str, namespace: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """Get a resource from the cache.

        Args:
            api_version: API version of the resource.
            kind: Kind of the resource.
            name: Name of the resource.
            namespace: Namespace of the resource (if applicable).

        Returns:
            Resource dict or None if not found.
            
        Raises:
            RuntimeError: If accessed from a test without using the test_cache fixture.
        """
        # Check if running in test environment - even reading can be misleading in tests
        if "PYTEST_CURRENT_TEST" in os.environ and not hasattr(self, "_is_test_cache"):
            # This is the global instance, fail loudly to alert the developer
            raise RuntimeError(
                "CRITICAL ERROR: Attempting to read from production cache in a test!\n"
                "You MUST use the test_cache fixture from conftest.py to isolate test data.\n"
                "Tests should NEVER interact with the global production cache.\n"
                "Fix this by updating your test to use the test_cache fixture."
            )
        with self._read_only_session() as session:
            return self._query_single_resource(session, api_version, kind, name, namespace)

    def list_resources(self, api_version: Optional[str] = None, kind: Optional[str] = None, namespace: Optional[str] = None) -> List[Dict[str, Any]]:
        """List resources from the cache.

        Args:
            api_version: Filter by API version.
            kind: Filter by kind.
            namespace: Filter by namespace.

        Returns:
            List of resource dicts.
            
        Raises:
            RuntimeError: If accessed from a test without using the test_cache fixture.
        """
        # Check if running in test environment - even reading can be misleading in tests
        if "PYTEST_CURRENT_TEST" in os.environ and not hasattr(self, "_is_test_cache"):
            # This is the global instance, fail loudly to alert the developer
            raise RuntimeError(
                "CRITICAL ERROR: Attempting to read from production cache in a test!\n"
                "You MUST use the test_cache fixture from conftest.py to isolate test data.\n"
                "Tests should NEVER interact with the global production cache.\n"
                "Fix this by updating your test to use the test_cache fixture."
            )
        with self._read_only_session() as session:
            return self._query_filtered_resources(session, api_version, kind, namespace)

    def delete_resource(self, api_version: str, kind: str, name: str, namespace: Optional[str] = None) -> bool:
        """Delete a resource from the cache.

        Args:
            api_version: API version of the resource.
            kind: Kind of the resource.
            name: Name of the resource.
            namespace: Namespace of the resource (if applicable).

        Returns:
            True if resource was deleted, False otherwise.
            
        Raises:
            RuntimeError: If accessed from a test without using the test_cache fixture.
        """
        # Check if running in test environment - deleting is also dangerous
        if "PYTEST_CURRENT_TEST" in os.environ and not hasattr(self, "_is_test_cache"):
            # This is the global instance, fail loudly to alert the developer
            raise RuntimeError(
                "CRITICAL ERROR: Attempting to delete from production cache in a test!\n"
                "You MUST use the test_cache fixture from conftest.py to isolate test data.\n"
                "Tests should NEVER interact with the global production cache.\n"
                "Fix this by updating your test to use the test_cache fixture."
            )
        with self._database_session() as session:
            return self._delete_single_resource(session, api_version, kind, name, namespace)

    def clear_cache(self, api_version: Optional[str] = None, kind: Optional[str] = None, namespace: Optional[str] = None) -> int:
        """Clear resources from the cache.

        Args:
            api_version: Filter by API version.
            kind: Filter by kind.
            namespace: Filter by namespace.

        Returns:
            Number of resources deleted.
            
        Raises:
            RuntimeError: If accessed from a test without using the test_cache fixture
        """
        # Check if running in test environment - this is especially dangerous since it clears everything
        if "PYTEST_CURRENT_TEST" in os.environ and not hasattr(self, "_is_test_cache"):
            # This is the global instance, fail loudly to alert the developer
            raise RuntimeError(
                "CRITICAL ERROR: Attempting to clear production cache from a test!\n"
                "You MUST use the test_cache fixture from conftest.py to isolate test data.\n"
                "Tests should NEVER interact with the global production cache.\n"
                "Fix this by updating your test to use the test_cache fixture and only clear specific test keys."
            )
        with self._database_session() as session:
            return self._clear_filtered_cache(session, api_version, kind, namespace)

    def store_response(self, cache_key: str, response_data: Dict[str, Any]) -> None:
        """Store a response in the cache.

        Args:
            cache_key: The cache key for the response (typically the request path)
            response_data: The response data to cache
            
        Raises:
            RuntimeError: If accessed from a test without using the test_cache fixture
        """
        # Check if running in test environment - if so, this is likely a mistake
        if "PYTEST_CURRENT_TEST" in os.environ and not hasattr(self, "_is_test_cache"):
            # This is the global instance, fail loudly to alert the developer
            raise RuntimeError(
                "CRITICAL ERROR: Attempting to modify production cache from a test!\n"
                "You MUST use the test_cache fixture from conftest.py to isolate test data.\n"
                "Tests should NEVER interact with the global production cache.\n"
                "Fix this by updating your test to use the test_cache fixture."
            )
        session = self.Session()
        try:
            # Check if response already exists
            existing = session.query(CachedResponse).filter_by(cache_key=cache_key).first()

            if existing:
                # Update existing response
                existing.data = orjson.dumps(response_data).decode('utf-8')
                existing.updated_at = datetime.utcnow()
            else:
                # Create new response
                new_response = CachedResponse(
                    cache_key=cache_key,
                    data=orjson.dumps(response_data).decode('utf-8')
                )
                session.add(new_response)

            session.commit()
        except Exception as e:
            session.rollback()
            raise e
        finally:
            session.close()

    def get_response(self, cache_key: str) -> Optional[Dict[str, Any]]:
        """Get a response from the cache.

        Args:
            cache_key: The cache key for the response

        Returns:
            Response dict or None if not found.
            
        Raises:
            RuntimeError: If accessed from a test without using the test_cache fixture
        """
        # Check if running in test environment - even reading can be misleading in tests
        if "PYTEST_CURRENT_TEST" in os.environ and not hasattr(self, "_is_test_cache"):
            # This is the global instance, fail loudly to alert the developer
            raise RuntimeError(
                "CRITICAL ERROR: Attempting to read from production cache in a test!\n"
                "You MUST use the test_cache fixture from conftest.py to isolate test data.\n"
                "Tests should NEVER interact with the global production cache.\n"
                "Fix this by updating your test to use the test_cache fixture."
            )
        session = self.Session()
        try:
            cached_response = session.query(CachedResponse).filter_by(cache_key=cache_key).first()

            if cached_response:
                return orjson.loads(cached_response.data)
            return None
        except Exception as e:
            self._log_error(f"Error getting cached response: {e}")
            return None
        finally:
            session.close()
            
    def clear_response(self, cache_key: str) -> bool:
        """Delete a response from the cache.

        Args:
            cache_key: The cache key for the response to delete

        Returns:
            True if the response was deleted, False otherwise
            
        Raises:
            RuntimeError: If accessed from a test without using the test_cache fixture
        """
        # Check if running in test environment - deleting is also dangerous
        if "PYTEST_CURRENT_TEST" in os.environ and not hasattr(self, "_is_test_cache"):
            # This is the global instance, fail loudly to alert the developer
            raise RuntimeError(
                "CRITICAL ERROR: Attempting to clear response from production cache in a test!\n"
                "You MUST use the test_cache fixture from conftest.py to isolate test data.\n"
                "Tests should NEVER interact with the global production cache.\n"
                "Fix this by updating your test to use the test_cache fixture."
            )
        session = self.Session()
        try:
            cached_response = session.query(CachedResponse).filter_by(cache_key=cache_key).first()
            if cached_response:
                session.delete(cached_response)
                session.commit()
                return True
            return False
        except Exception as e:
            session.rollback()
            self._log_error(f"Error clearing cached response: {e}")
            return False
        finally:
            session.close()

    def get_cache_stats(self) -> Dict[str, Any]:
        """Get cache statistics.

        Returns:
            Dict with cache statistics.
        """
        session = self.Session()
        try:
            total_resources = session.query(Resource).count()
            total_responses = session.query(CachedResponse).count()

            # Count resources by kind
            resources_by_kind = {}
            for kind, count in session.query(Resource.kind, func.count(Resource.id)).group_by(Resource.kind).all():
                resources_by_kind[kind] = count

            # Get latest update time
            latest_resource_update = session.query(func.max(Resource.updated_at)).scalar()
            latest_response_update = session.query(func.max(CachedResponse.updated_at)).scalar()
            latest_update = max(latest_resource_update, latest_response_update) if latest_resource_update and latest_response_update else (latest_resource_update or latest_response_update)

            return {
                "total_resources": total_resources,
                "total_responses": total_responses,
                "resources_by_kind": resources_by_kind,
                "latest_update": latest_update.isoformat() if latest_update else None,
            }
        except Exception as e:
            self._log_error(f"Error getting cache stats: {e}")
            return {
                "total_resources": 0,
                "total_responses": 0,
                "resources_by_kind": {},
                "latest_update": None,
            }
        finally:
            session.close()

    def export_cache(self, file_path: str) -> bool:
        """Export cache to a file.

        Args:
            file_path: Path to export file.

        Returns:
            True if export was successful, False otherwise.
        """
        session = self.Session()
        try:
            resources = session.query(Resource).all()

            export_data = {
                "version": "1.0",
                "timestamp": datetime.utcnow().isoformat(),
                "resources": [orjson.loads(resource.data) for resource in resources]
            }

            with open(file_path, "w") as f:
                f.write(orjson.dumps(export_data, option=orjson.OPT_INDENT_2).decode('utf-8'))

            return True
        except Exception as e:
            self._log_error(f"Error exporting cache: {e}")
            return False
        finally:
            session.close()

    def import_cache(self, file_path: str) -> Tuple[int, int]:
        """Import cache from a file.

        Args:
            file_path: Path to import file.

        Returns:
            Tuple of (resources_imported, resources_failed).
        """
        try:
            with open(file_path, "r") as f:
                import_data = orjson.loads(f.read())

            if not isinstance(import_data, dict) or "resources" not in import_data:
                raise ValueError("Invalid import file format")

            resources = import_data.get("resources", [])
            imported = 0
            failed = 0

            for resource in resources:
                try:
                    self.store_resource(resource)
                    imported += 1
                except Exception:
                    failed += 1

            return imported, failed
        except Exception as e:
            self._log_error(f"Error importing cache: {e}")
            return 0, 0
