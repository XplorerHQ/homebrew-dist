"""
Configuration management for Xplorer-Cache.
"""

import os
import yaml
import base64
import tempfile
from pathlib import Path
from kubernetes import client, config as k8s_config
from kubernetes.config import kube_config
from typing import Dict, Any, Optional, List, Tuple


class Config:
    """Configuration manager for Xplorer-Cache."""
    
    DEFAULT_CONFIG_DIR = os.path.expanduser("~/.xplorer-cache")
    DEFAULT_CONFIG_FILE = "config.yaml"
    DEFAULT_DB_FILE = "cache.db"
    
    def __init__(self, config_dir: Optional[str] = None):
        """Initialize the configuration manager.
        
        Args:
            config_dir: Directory to store configuration files. Defaults to ~/.xplorer-cache.
        """
        self.config_dir = config_dir or self.DEFAULT_CONFIG_DIR
        self.config_file = os.path.join(self.config_dir, self.DEFAULT_CONFIG_FILE)
        self.config = self._load_config()
    
    def _load_config(self) -> Dict[str, Any]:
        """Load configuration from file.
        
        Returns:
            Dict containing configuration values.
        """
        if not os.path.exists(self.config_dir):
            os.makedirs(self.config_dir)
        
        if not os.path.exists(self.config_file):
            return self._create_default_config()
        
        try:
            with open(self.config_file, "r") as f:
                return yaml.safe_load(f) or {}
        except Exception as e:
            print(f"Error loading config: {e}")
            return self._create_default_config()
    
    def _create_default_config(self) -> Dict[str, Any]:
        """Create default configuration.
        
        Returns:
            Dict containing default configuration values.
        """
        default_config = {
            "server": {
                "host": "127.0.0.1",
                "port": 8080,
                "debug": False,
            },
            "database": {
                "type": "sqlite",
                "path": os.path.join(self.config_dir, self.DEFAULT_DB_FILE),
            },
            "cache": {
                "expiration": 3600,  # 1 hour in seconds
                "max_size": 1024,    # 1 GB in MB
            },
            "endpoints": {
                # Default is to use hybrid mode for all endpoints
                "default_mode": "hybrid",
                "rules": []
            },
            "kubernetes": {
                "use_kubeconfig": True,
                "kubeconfig_path": os.path.expanduser("~/.kube/config"),
                "context": None,
                "api_server_url": "",
                "contexts": {},
            }
        }
        
        self._save_config(default_config)
        return default_config
    
    def _save_config(self, config: Dict[str, Any]) -> None:
        """Save configuration to file.
        
        Args:
            config: Configuration dict to save.
        """
        try:
            with open(self.config_file, "w") as f:
                yaml.dump(config, f, default_flow_style=False)
        except Exception as e:
            print(f"Error saving config: {e}")
    
    def get(self, key: str, default: Any = None) -> Any:
        """Get a configuration value.
        
        Args:
            key: Configuration key (dot notation supported, e.g., "server.port").
            default: Default value if key not found.
            
        Returns:
            Configuration value or default.
        """
        keys = key.split(".")
        value = self.config
        
        for k in keys:
            if isinstance(value, dict) and k in value:
                value = value[k]
            else:
                return default
        
        return value
    
    def set(self, key: str, value: Any) -> None:
        """Set a configuration value.
        
        Args:
            key: Configuration key (dot notation supported, e.g., "server.port").
            value: Value to set.
        """
        keys = key.split(".")
        config = self.config
        
        # Navigate to the nested dict
        for k in keys[:-1]:
            if k not in config:
                config[k] = {}
            config = config[k]
        
        # Set the value
        config[keys[-1]] = value
        
        # Save the updated config
        self._save_config(self.config)
    
    def get_endpoint_mode(self, endpoint: str) -> str:
        """Get the mode for a specific endpoint.
        
        Args:
            endpoint: The endpoint path.
            
        Returns:
            Mode for the endpoint ("live", "cache", or "hybrid").
        """
        default_mode = self.get("endpoints.default_mode", "live")
        rules = self.get("endpoints.rules", [])
        
        # Check if there's a specific rule for this endpoint
        for rule in rules:
            if rule.get("endpoint") == endpoint:
                return rule.get("mode", default_mode)
        
        # Check for wildcard matches
        for rule in rules:
            rule_endpoint = rule.get("endpoint", "")
            if rule_endpoint.endswith("*") and endpoint.startswith(rule_endpoint[:-1]):
                return rule.get("mode", default_mode)
        
        return default_mode
    
    def set_endpoint_mode(self, endpoint: str, mode: str) -> None:
        """Set the mode for a specific endpoint.
        
        Args:
            endpoint: The endpoint path.
            mode: Mode for the endpoint ("live", "cache", or "hybrid").
        """
        rules = self.get("endpoints.rules", [])
        
        # Check if there's an existing rule for this endpoint
        for rule in rules:
            if rule.get("endpoint") == endpoint:
                rule["mode"] = mode
                self.set("endpoints.rules", rules)
                return
        
        # Add a new rule
        rules.append({"endpoint": endpoint, "mode": mode})
        self.set("endpoints.rules", rules)
    
    def get_all_endpoint_rules(self) -> List[Dict[str, str]]:
        """Get all endpoint rules.
        
        Returns:
            List of endpoint rules.
        """
        return self.get("endpoints.rules", [])
        
    def load_kubernetes_config(self) -> None:
        """
        Load Kubernetes configuration from the default kubeconfig file.
        
        This loads available contexts, clusters, and users from the user's
        kubeconfig file (~/.kube/config by default) into the configuration.
        """
        kubeconfig_path = self.get("kubernetes.kubeconfig_path", os.path.expanduser("~/.kube/config"))
        
        if not os.path.exists(kubeconfig_path):
            print(f"Kubernetes config file not found at {kubeconfig_path}")
            return
        
        try:
            # Load the kubernetes config file
            with open(kubeconfig_path, 'r') as f:
                kube_conf = yaml.safe_load(f)
                
            # Extract all available contexts
            contexts = {}
            
            # Get the current context
            current_context = kube_conf.get('current-context')
            
            # Process all contexts
            for context_entry in kube_conf.get('contexts', []):
                context_name = context_entry.get('name')
                context_data = context_entry.get('context', {})
                
                # Find the cluster for this context
                cluster_name = context_data.get('cluster')
                cluster_data = None
                for cluster_entry in kube_conf.get('clusters', []):
                    if cluster_entry.get('name') == cluster_name:
                        cluster_data = cluster_entry.get('cluster', {})
                        break
                
                # Find the user for this context
                user_name = context_data.get('user')
                user_data = None
                for user_entry in kube_conf.get('users', []):
                    if user_entry.get('name') == user_name:
                        user_data = user_entry.get('user', {})
                        break
                
                # Create a context object with all the necessary info
                if cluster_data:
                    contexts[context_name] = {
                        'api_server_url': cluster_data.get('server', ''),
                        'cluster': cluster_name,
                        'user': user_name,
                        'namespace': context_data.get('namespace', 'default'),
                        'is_current': context_name == current_context,
                        # Store essential auth info for creating API clients
                        'auth': {
                            'certificate_authority_data': cluster_data.get('certificate-authority-data'),
                            'client_certificate_data': user_data.get('client-certificate-data') if user_data else None,
                            'client_key_data': user_data.get('client-key-data') if user_data else None,
                            'token': user_data.get('token') if user_data else None,
                            'username': user_data.get('username') if user_data else None,
                            'password': user_data.get('password') if user_data else None,
                        }
                    }
            
            # Update the configuration
            self.set("kubernetes.contexts", contexts)
            
            # Set the default context
            if current_context:
                self.set("kubernetes.context", current_context)
            
        except Exception as e:
            print(f"Error loading Kubernetes config: {e}")
    
    def get_kubernetes_api_url(self, context_name: Optional[str] = None) -> str:
        """Get the Kubernetes API server URL for a specific context.
        
        Args:
            context_name: The Kubernetes context name. If None, uses the default context.
            
        Returns:
            The Kubernetes API server URL.
        """
        # Load kubernetes config if it hasn't been loaded yet
        if not self.get("kubernetes.contexts"):
            self.load_kubernetes_config()
        
        # If no context specified, use default
        if not context_name:
            context_name = self.get("kubernetes.context")
        
        # Check if we have this context
        contexts = self.get("kubernetes.contexts", {})
        if context_name and context_name in contexts:
            return contexts[context_name]["api_server_url"]
        
        # Fall back to the global API server URL
        return self.get("kubernetes.api_server_url", "")
    
    def get_kubernetes_auth_info(self, context_name: Optional[str] = None) -> Dict[str, Any]:
        """
        Get authentication information for a specific Kubernetes context.
        
        Args:
            context_name: The Kubernetes context name. If None, uses the default context.
            
        Returns:
            Dictionary containing authentication information.
        """
        # Load kubernetes config if it hasn't been loaded yet
        if not self.get("kubernetes.contexts"):
            self.load_kubernetes_config()
        
        # If no context specified, use default
        if not context_name:
            context_name = self.get("kubernetes.context")
        
        # Check if we have this context
        contexts = self.get("kubernetes.contexts", {})
        if context_name and context_name in contexts:
            return contexts[context_name].get("auth", {})
        
        return {}
    
    def get_api_client_for_context(self, context_name: Optional[str] = None) -> Tuple[Optional[client.ApiClient], bool]:
        """
        Create a Kubernetes API client for the specified context.
        
        Args:
            context_name: The Kubernetes context name. If None, uses the default context.
            
        Returns:
            A tuple with (ApiClient instance, success flag).
        """
        # Load kubernetes config if it hasn't been loaded yet
        if not self.get("kubernetes.contexts"):
            self.load_kubernetes_config()
        
        # If no context specified, use default
        if not context_name:
            context_name = self.get("kubernetes.context")
        
        # Get the context
        contexts = self.get("kubernetes.contexts", {})
        if not context_name or context_name not in contexts:
            return None, False
        
        context_info = contexts[context_name]
        auth_info = context_info.get("auth", {})
        
        try:
            # Create a temporary kubeconfig file with just this context
            with tempfile.NamedTemporaryFile(delete=False) as temp_config:
                # Create a minimal kubeconfig
                minimal_config = {
                    "apiVersion": "v1",
                    "kind": "Config",
                    "clusters": [
                        {
                            "name": context_info.get("cluster"),
                            "cluster": {
                                "server": context_info.get("api_server_url")
                            }
                        }
                    ],
                    "users": [
                        {
                            "name": context_info.get("user"),
                            "user": {}
                        }
                    ],
                    "contexts": [
                        {
                            "name": context_name,
                            "context": {
                                "cluster": context_info.get("cluster"),
                                "user": context_info.get("user"),
                                "namespace": context_info.get("namespace", "default")
                            }
                        }
                    ],
                    "current-context": context_name
                }
                
                # Add authentication details
                cluster = minimal_config["clusters"][0]["cluster"]
                user = minimal_config["users"][0]["user"]
                
                # Certificate authority data
                if auth_info.get("certificate_authority_data"):
                    cluster["certificate-authority-data"] = auth_info["certificate_authority_data"]
                
                # Client certificate and key
                if auth_info.get("client_certificate_data"):
                    user["client-certificate-data"] = auth_info["client_certificate_data"]
                if auth_info.get("client_key_data"):
                    user["client-key-data"] = auth_info["client_key_data"]
                
                # Token
                if auth_info.get("token"):
                    user["token"] = auth_info["token"]
                
                # Basic auth
                if auth_info.get("username"):
                    user["username"] = auth_info["username"]
                if auth_info.get("password"):
                    user["password"] = auth_info["password"]
                
                # Write the config to the temp file
                temp_config.write(yaml.dump(minimal_config).encode())
                temp_config.flush()
                
                # Load the config and create an API client
                client_config = kube_config.KubeConfigLoader(
                    config_dict=minimal_config,
                    config_file=temp_config.name
                )
                
                api_client = client.ApiClient(client_config.load_and_set())
                
                # Clean up
                os.unlink(temp_config.name)
                
                return api_client, True
                
        except Exception as e:
            print(f"Error creating API client for context {context_name}: {e}")
            return None, False
    
    def get_kubernetes_contexts(self) -> Dict[str, Dict[str, Any]]:
        """Get all configured Kubernetes contexts.
        
        Returns:
            Dictionary of context names to their configurations.
        """
        # Load kubernetes config if it hasn't been loaded yet
        if not self.get("kubernetes.contexts"):
            self.load_kubernetes_config()
            
        return self.get("kubernetes.contexts", {})
