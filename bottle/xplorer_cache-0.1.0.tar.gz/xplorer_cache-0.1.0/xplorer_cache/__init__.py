"""
Xplorer-Cache: A specialized Python server application for efficiently storing, managing, 
and proxying Kubernetes cluster data.
"""

__version__ = "0.1.0"
