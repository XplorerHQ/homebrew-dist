# Differences between explore-claim.py and Main Program

This document outlines the features present in explore-claim.py that are currently missing in the main program. Note that enhancements in the main program that are not present in the script are intentionally omitted.

## DONE: Resource Pre-fetching
The main program now implements the same pre-fetching optimization as explore-claim.py:
- Collects unique group/versions from claims and XRs (cli.py lines 141-146)
- Pre-fetches resource groups before processing using cache.get_group_instances (cli.py lines 155-160)
- Shows detailed progress during pre-fetching with percentage and group counts (cli.py lines 151-159)
- Uses 0-20% progress range for pre-fetching phase
- Properly utilizes pre-fetched data during claim processing

## DONE: Command Line Interface
The main program now implements all CLI options from explore-claim.py:
- `--all/-A`: List all claims in the cluster (cli.py line 91)
- `--namespace`: Specify namespace to search in (cli.py line 92)
- `--refresh-cache`: Force cache refresh (cli.py line 95)
- `--show-cache`: Display cache information and exit (cli.py line 96)

All options are fully functional with proper help messages and are handled correctly in the code. The implementation matches explore-claim.py's behavior for each option.

## DONE: Resource Processing
The main program now matches explore-claim.py's resource processing capabilities:
- Namespace-based filtering for multiple matches with helpful error messages (cli.py lines 242-250)
- Comprehensive progress updates throughout processing:
  - Group prefetching progress (lines 151-159)
  - Claim processing status (lines 177-178)
  - XR discovery progress (lines 179-180)
  - Child resource discovery (lines 184-233)
  - Event processing status (lines 205-212)
- Detailed error handling and reporting:
  - Multiple matches with namespace suggestion
  - No instances found handling
  - Proper error messages using sys.stderr
- Memory-efficient incremental processing with pre-fetching optimization

## DONE: Error Handling
The main program implements comprehensive error handling matching explore-claim.py:
- Detailed error messages for kube config loading (cli.py lines 106-110)
- Resource discovery errors with helpful suggestions (lines 250-254)
- Event fetching errors with proper reporting
- Cache-related errors with fallback mechanisms
- All errors properly directed to sys.stderr with color-coded messages

## DONE: Cache Management
The main program implements all cache management features from explore-claim.py:
- Cache information display with detailed statistics (--show-cache option)
- Force cache refresh option with proper cleanup (--refresh-cache)
- Comprehensive debug logging throughout cache operations:
  - Cache loading and validation
  - Cache refresh operations
  - Cache size and age tracking
  - Backup and recovery mechanisms

## DONE: Operational Features
The main program implements all operational features from explore-claim.py:
- Signal handling for graceful interruption (SIGINT/Ctrl-C) with proper cleanup (cli.py lines 25-32)
- Transient progress display using rich.progress with automatic cleanup
- Memory-efficient resource processing:
  - Incremental updates with progress tracking
  - Pre-fetching optimization
  - Resource cleanup after processing

## DONE: Feature Parity Achieved
All major features from explore-claim.py have been successfully implemented in the main program:
- Resource pre-fetching and optimization
- Complete CLI functionality
- Comprehensive resource processing
- Enhanced error handling
- Full cache management
- Operational improvements

Note: While feature parity has been achieved, the main program may have its own additional enhancements and improvements that intentionally differ from the script's implementation.
