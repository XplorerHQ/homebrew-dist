# Code Organization and Cohesion Analysis

## Current Module Structure

### cli.py
**Primary Responsibility**: Command-line interface and main program flow
**Current Additional Responsibilities**:
- Progress reporting and display formatting
- Resource processing workflow
- Error handling and reporting
- Signal handling

### display.py
**Primary Responsibility**: Resource tree visualization
**Current Additional Responsibilities**:
- Cache information formatting and display
- Size formatting utilities
- Progress status formatting

### cache.py
**Primary Responsibility**: Kubernetes resource caching
**Current Additional Responsibilities**:
- Debug logging
- File operations and error handling
- Data conversion utilities

### discovery.py
**Primary Responsibility**: Kubernetes resource discovery
**Current Additional Responsibilities**:
- Event handling and attachment
- Resource relationship mapping
- Data transformation

## Future TUI Support Considerations

The planned refactoring should prepare the codebase for adding a Terminal User Interface (TUI) by:

1. **Interface Abstraction**:
   ```python
   class UIInterface(ABC):
       @abstractmethod
       def display_resource_tree(self, resources): ...
       @abstractmethod
       def show_progress(self, current, total, message): ...
       @abstractmethod
       def display_error(self, error, suggestions=None): ...
   ```

2. **Display Strategy**:
   ```python
   class DisplayManager:
       def __init__(self, ui_interface):
           self.ui = ui_interface

       def show_resources(self, resources):
           self.ui.display_resource_tree(resources)
   ```

3. **Event Handling**:
   ```python
   class UIEventHandler:
       def on_resource_selected(self, resource): ...
       def on_refresh_requested(self): ...
       def on_filter_changed(self, filter_text): ...
   ```

This preparation will make it easier to:
- Add interactive resource navigation
- Implement live updates
- Support different display modes (tree/list/detail views)
- Handle user input and events
- Maintain consistent UI behavior

## Identified Issues

1. **Mixed Display Responsibilities**:
   - Size formatting utilities in display.py could be moved to a utilities module
   - Cache information display mixes cache and display responsibilities

2. **Scattered Progress Reporting**:
   - Progress reporting logic spread between cli.py and display.py
   - Status message formatting mixed with progress tracking

3. **Utility Functions Distribution**:
   - Format conversion utilities scattered across modules
   - Common error handling patterns duplicated

4. **Mixed Resource Processing**:
   - Resource processing mixed with CLI handling
   - Event handling mixed with resource discovery

## Code Examples for Refactoring

### From display.py:
1. Move to utils.py:
```python
def format_size_kb(size_bytes: float) -> str:
    """Format size in bytes to KB with comma separator."""
    return f"{size_bytes/1024:,.1f}"
```

2. Move to events.py:
```python
def attach_events(resource: Dict[str, Any], dynamic_client: Any, cache: Any) -> None:
    """Attach events to a resource using namespace-level caching."""
    # Event handling logic
```

3. Move to resource_processor.py:
```python
def get_resource_conditions(resource: Dict[str, Any]) -> tuple[str, str]:
    """Get resource ready and synced condition status."""
    # Resource condition checking logic
```

### From cache.py:
1. Move to utils.py:
```python
def _convert_for_cache(self, obj):
    """Convert dynamic client objects to JSON-serializable format."""
    # Data conversion logic
```

2. Move to events.py:
```python
def get_resource_events(self, resource):
    """Get events for a specific resource."""
    # Event retrieval logic
```

3. Move to resource_processor.py:
```python
def _discover_group_relationships(self, crds, group):
    """Discover relationships between resource groups."""
    # Group relationship logic
```

### From cli.py:
1. Move to progress.py:
```python
# Progress bar configuration
with Progress(
    SpinnerColumn(),
    *Progress.get_default_columns(),
    "Elapsed:",
    TimeElapsedColumn(),
    TextColumn("[bold]{task.fields[status]}"),
    transient=True
) as progress:
    # Progress handling logic

# Progress update utilities
def update_progress(progress, task, step, total_steps, resource_name):
    """Update progress with consistent formatting."""
    progress.update(task, 
        completed=int((step/total_steps) * 100),
        status=f"Processing [blue]{resource_name}[/blue] ({step}/{total_steps})")
```

2. Move to resource_processor.py:
```python
def process_resources(resources, progress_callback=None):
    """Process resources with optional progress reporting."""
    for resource in resources:
        # Resource processing logic
        if progress_callback:
            progress_callback(resource)

def count_resources(tree):
    """Count total resources in a resource tree."""
    count = 1  # Count current resource
    for child in tree.get('children', []):
        count += count_resources(child)
    return count
```

3. Move to utils.py:
```python
def handle_connection_error(e):
    """Handle connection errors with user-friendly messages."""
    console = Console()
    error_str = str(e)

    console.print("\n[red]Error: Unable to connect to the cluster[/red]")
    console.print("\nPossible solutions:")
    console.print(" • Verify your kubeconfig is correct: [bold]kubectl config view[/bold]")
    console.print(" • Confirm cluster accessibility: [bold]kubectl cluster-info[/bold]")
    console.print(" • Check if credentials need to be refreshed")

    console.print("\n[dim]Technical details:[/dim]")
    console.print(f"[dim]{error_str}[/dim]")
    sys.exit(1)
```

## Proposed Refactoring

### New Modules

1. **ui.py**:
   - UI interface abstractions
   - Display strategy implementations
   - Event handling interfaces
   - Common UI utilities
   - Base classes for CLI and TUI implementations

2. **utils.py**:
   - Size formatting (from display.py)
   - Data conversion utilities (from cache.py)
   - Common error handling patterns
   - Shared logging utilities

2. **progress.py**:
   - Progress bar configuration
   - Status message formatting
   - Progress tracking utilities
   - Progress reporting abstractions

3. **events.py**:
   - Event handling and attachment
   - Event data formatting
   - Event-related utilities

4. **resource_processor.py**:
   - Resource processing workflow
   - Resource relationship handling
   - Resource transformation logic

### Module Updates

1. **cli.py** should focus on:
   - Argument parsing
   - Command handling
   - High-level program flow
   - Signal handling

2. **display.py** should focus on:
   - Resource tree visualization
   - Display formatting
   - Output generation

3. **cache.py** should focus on:
   - Cache management
   - Cache data handling
   - Cache validation

4. **discovery.py** should focus on:
   - Resource discovery
   - API interaction
   - Resource metadata handling

## Implementation Strategy

1. **Phase 1: Create Utility Module**
   - Create utils.py with shared functionality:
     ```python
     from rich.console import Console

     def format_size_kb(size_bytes: float) -> str: ...
     def handle_connection_error(e): ...
     def setup_logging(debug: bool): ...
     ```
   - Move formatting and error handling from display.py and cli.py
   - Add unit tests for each utility function
   - Update imports in all affected modules

2. **Phase 2: Progress Handling**
   - Create progress.py with progress abstractions:
     ```python
     class ProgressReporter:
         def __init__(self):
             self.progress = Progress(...)

         def update_status(self, step, total, message): ...
         def start_task(self, description): ...
     ```
   - Extract progress logic from cli.py
   - Create progress reporting interface
   - Add progress-specific tests
   - Update CLI to use new progress module

3. **Phase 3: Resource Processing**
   - Create resource_processor.py with processing logic:
     ```python
     class ResourceProcessor:
         def __init__(self, progress_callback=None):
             self.progress = progress_callback

         def process_resources(self, resources): ...
         def handle_child_resources(self, resource): ...
     ```
   - Move resource handling from cli.py and discovery.py
   - Add resource processing tests
   - Update dependencies to use new module

4. **Phase 4: Event Handling**
   - Create events.py for event management:
     ```python
     class EventManager:
         def __init__(self, cache):
             self.cache = cache

         def attach_events(self, resource): ...
         def get_resource_events(self, resource): ...
     ```
   - Extract event logic from cache.py and discovery.py
   - Add event handling tests
   - Update affected modules

5. **Phase 5: UI Abstractions**
   - Create ui.py with interface definitions:
     ```python
     class BaseUI(ABC):
         @abstractmethod
         def initialize(self): ...

         @abstractmethod
         def cleanup(self): ...

     class CLIInterface(BaseUI):
         def display_resources(self, resources, style="tree"): ...
         def show_progress(self, progress): ...
         def handle_input(self): ...

     class DisplayStrategy:
         def __init__(self, ui: BaseUI):
             self.ui = ui

         def show(self, data, format_opts=None): ...
     ```
   - Move display logic from display.py to CLIInterface
   - Create UI event handling infrastructure
   - Add UI abstraction tests
   - Update display.py to use new abstractions

6. **Testing Strategy**
   - Create unit tests for each new module
   - Add integration tests for module interactions
   - Create mock objects for external dependencies
   - Test error handling paths
   - Verify progress reporting accuracy

## Benefits

1. **Improved Cohesion**:
   - Each module has a single, clear responsibility:
     - cli.py: Only handles command-line interface and program flow
     - display.py: Focuses solely on visualization
     - cache.py: Dedicated to cache management
   - Utility functions are properly grouped by purpose
   - Clear boundaries between different concerns

2. **Better Testability**:
   - Isolated components with clear interfaces:
     ```python
     # Before: Mixed responsibilities
     def process_resources(resources, progress, cache):
         for resource in resources:
             progress.update(...)
             cache.store(...)

     # After: Clean separation
     def process_resources(resources, callbacks):
         for resource in resources:
             callbacks.on_progress(...)
             callbacks.on_cache(...)
     ```
   - Easy to mock dependencies
   - Focused unit tests for each component

3. **Enhanced Maintainability**:
   - Centralized error handling in utils.py
   - Consistent progress reporting through ProgressReporter
   - Resource processing logic in one place:
     ```python
     # Before: Scattered across modules
     if resource.get('status', {}).get('conditions', []):
         # condition handling...

     # After: Centralized in ResourceProcessor
     processor.check_conditions(resource)
     ```

4. **Cleaner Dependencies**:
   - One-way dependency flow:
     - cli.py → resource_processor.py → events.py
     - utils.py ← (used by all modules)
   - No circular imports
   - Clear module hierarchy

5. **UI Flexibility**:
   - Easy to add new UI implementations:
     ```python
     class TUIInterface(BaseUI):
         def display_resources(self, resources):
             # TUI-specific display logic

     # Switch UI implementations easily
     ui = TUIInterface() if use_tui else CLIInterface()
     display_manager = DisplayManager(ui)
     ```
   - Consistent behavior across interfaces
   - Shared UI utilities and helpers
   - Clean separation of UI and business logic

6. **Future-Proof Architecture**:
   - Support for interactive features
   - Easy to add new display modes
   - Pluggable UI components
   - Event-driven architecture ready

## Next Steps

1. **Initial Setup** (Priority: High)
   - Create new module files: utils.py, progress.py, events.py, resource_processor.py
   - Set up test files for each new module
   - Update project structure to include new modules

2. **Phase 1: Utils Module** (Priority: High)
   - Move format_size_kb from display.py
   - Move error handling from cli.py
   - Create shared logging utilities
   - Add unit tests for utils.py
   - Update imports in existing files

3. **Phase 2: Progress Module** (Priority: Medium)
   - Create ProgressReporter class
   - Move progress logic from cli.py
   - Update cli.py to use new abstractions
   - Add progress reporting tests
   - Verify progress display functionality

4. **Phase 3: Resource Processing** (Priority: High)
   - Create ResourceProcessor class
   - Move processing logic from cli.py
   - Update discovery.py to use new processor
   - Add processor unit tests
   - Verify resource handling

5. **Phase 4: Event Handling** (Priority: Medium)
   - Create EventManager class
   - Move event logic from cache.py
   - Update affected modules
   - Add event handling tests
   - Verify event functionality

6. **Phase 6: UI Preparation** (Priority: High)
   - Create UI abstraction interfaces
   - Implement CLI version using new interfaces
   - Set up event handling infrastructure
   - Add UI component tests
   - Create UI utility functions

7. **Validation** (Priority: High)
   - Run full test suite
   - Verify all features still work
   - Check performance impact
   - Review error handling
   - Test UI abstractions
   - Verify interface consistency
   - Update documentation

8. **TUI Preparation** (Priority: Medium)
   - Create TUI prototype using new interfaces
   - Test UI switching mechanism
   - Verify event handling
   - Document TUI implementation guide

This refactoring should be done incrementally, with each phase having its own branch and review process. Regular testing throughout the process will ensure functionality is maintained while improving code organization. The new architecture will make it straightforward to add TUI support while maintaining consistent behavior across different interfaces.
