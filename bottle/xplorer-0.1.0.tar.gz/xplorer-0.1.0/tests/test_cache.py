import unittest
import time
import sys
from unittest.mock import Mock
from xplorer.cache import ResourceCache


class TestResourceCache(unittest.TestCase):
    def setUp(self):
        self.mock_client = Mock()
        self.cache = ResourceCache(self.mock_client)

    def test_cache_initialization(self):
        self.assertIsNotNone(self.cache)
        self.assertEqual(self.cache._cache_ttl, 3600 * 3)

    def test_cache_validation(self):
        # Test valid cache data
        valid_data = {
            'timestamp': 1234567890,
            'crds': {'items': []},
            'resources_meta': {},
            'group_relationships': {}
        }
        self.assertTrue(self.cache._validate_cache_data(valid_data))

        # Test invalid cache data
        invalid_data = {'invalid': 'data'}
        self.assertFalse(self.cache._validate_cache_data(invalid_data))

    def test_cache_loading(self):
        # Mock file operations and time
        current_time = time.time()
        mock_cache_data = {
            'timestamp': current_time,  # Use current time
            'crds': {'items': []},
            'resources_meta': {},
            'group_relationships': {}
        }
        with unittest.mock.patch('os.path.exists', return_value=True), \
             unittest.mock.patch('os.path.getmtime', return_value=current_time), \
             unittest.mock.patch('time.time', return_value=current_time), \
             unittest.mock.patch('builtins.open', unittest.mock.mock_open(read_data='{}')), \
             unittest.mock.patch('json.load', return_value=mock_cache_data):
            self.assertTrue(self.cache._load_cache())

    def test_cache_saving(self):
        # Mock file operations
        with unittest.mock.patch('os.makedirs'), \
             unittest.mock.patch('builtins.open', unittest.mock.mock_open()), \
             unittest.mock.patch('json.dump'), \
             unittest.mock.patch('os.replace'):
            self.cache._save_cache()

    def test_get_crds(self):
        """Test CRD retrieval with caching."""
        # Mock API response
        mock_crds = {
            'items': [{
                'metadata': {'name': 'test-crd'},
                'spec': {
                    'group': 'test.group',
                    'names': {'kind': 'TestCRD'}
                }
            }]
        }
        self.mock_client.resources.get.return_value.get.return_value = mock_crds

        # First call should hit the API
        result = self.cache.get_crds()
        self.assertEqual(result, mock_crds)
        self.mock_client.resources.get.assert_called_once()

        # Second call should use cache
        self.mock_client.resources.get.reset_mock()
        cached_result = self.cache.get_crds()
        self.assertEqual(cached_result, mock_crds)
        self.mock_client.resources.get.assert_not_called()

    def test_get_resource(self):
        """Test resource retrieval with caching."""
        api_version = 'v1'
        kind = 'TestResource'

        # Mock API response
        mock_resource = {
            'kind': kind,
            'apiVersion': api_version,
            'metadata': {'name': 'test-resource'}
        }
        self.mock_client.resources.get.return_value = mock_resource

        # First call should hit the API
        result = self.cache.get_resource(api_version, kind)
        self.assertEqual(result, mock_resource)
        self.mock_client.resources.get.assert_called_once_with(
            api_version=api_version,
            kind=kind
        )

        # Second call should use cache
        self.mock_client.resources.get.reset_mock()
        cached_result = self.cache.get_resource(api_version, kind)
        self.assertEqual(cached_result, mock_resource)
        self.mock_client.resources.get.assert_not_called()

    def test_get_instance(self):
        """Test instance retrieval with caching."""
        group = 'test.group'
        version = 'v1'
        kind = 'TestResource'
        name = 'test-instance'

        # Mock API response
        mock_instance = {
            'kind': kind,
            'apiVersion': f'{group}/{version}',
            'metadata': {'name': name}
        }

        # Mock get_group_instances to return our test data
        def mock_get_instances(g, v):
            if g == group and v == version:
                return {kind: {name: mock_instance}}
            return {}

        self.cache.get_group_instances = Mock(side_effect=mock_get_instances)

        result = self.cache.get_instance(group, version, kind, name)
        self.assertEqual(result, mock_instance)

    def test_get_group_instances(self):
        """Test group instances retrieval with caching."""
        group = 'test.group'
        version = 'v1'
        kind = 'TestResource'

        # Mock CRDs response
        mock_crds = {
            'items': [{
                'spec': {
                    'group': group,
                    'versions': [{'name': version}],
                    'names': {'kind': kind},
                    'scope': 'Namespaced'
                }
            }]
        }

        # Mock resource response
        mock_resource = Mock()
        mock_items = [
            {'kind': kind, 'metadata': {'name': 'instance-1'}},
            {'kind': kind, 'metadata': {'name': 'instance-2'}}
        ]
        mock_result = Mock()
        mock_result.items = mock_items
        mock_resource.get.return_value = mock_result

        # Setup mocks
        self.cache.get_crds = Mock(return_value=mock_crds)
        self.cache.get_resource = Mock(return_value=mock_resource)
        self.cache._group_discovery_in_progress = set()

        # Expected result structure
        expected_instances = {
            kind: {
                'instance-1': {'kind': kind, 'metadata': {'name': 'instance-1'}},
                'instance-2': {'kind': kind, 'metadata': {'name': 'instance-2'}}
            }
        }

        result = self.cache.get_group_instances(group, version)
        self.assertEqual(result, expected_instances)
        self.assertEqual(len(result[kind]), 2)

    def test_get_namespace_events(self):
        """Test namespace events retrieval."""
        namespace = 'test-ns'

        # Create event objects with proper structure
        event1 = Mock()
        event1.involvedObject = Mock()
        event1.involvedObject.uid = 'obj1'
        event1.to_dict.return_value = {
            'type': 'Warning',
            'message': 'Test event 1',
            'metadata': {'namespace': namespace, 'name': 'event-1'},
            'involvedObject': {'uid': 'obj1'},
            'lastTimestamp': '2024-02-26T12:00:00Z'
        }

        event2 = Mock()
        event2.involvedObject = Mock()
        event2.involvedObject.uid = 'obj2'
        event2.to_dict.return_value = {
            'type': 'Normal',
            'message': 'Test event 2',
            'metadata': {'namespace': namespace, 'name': 'event-2'},
            'involvedObject': {'uid': 'obj2'},
            'lastTimestamp': '2024-02-26T12:01:00Z'
        }

        # Mock API response
        mock_response = Mock()
        mock_response.items = [event1, event2]

        events_api = Mock()
        events_api.get.return_value = mock_response
        self.mock_client.resources.get.return_value = events_api

        # Test events retrieval
        result = self.cache.get_namespace_events(namespace)
        self.assertEqual(len(result), 2)  # Two different UIDs
        self.assertEqual(len(result['obj1']), 1)
        self.assertEqual(len(result['obj2']), 1)
        self.assertEqual(result['obj1'][0]['type'], 'Warning')
        self.assertEqual(result['obj2'][0]['type'], 'Normal')

        # Verify API call
        events_api.get.assert_called_once_with(namespace=namespace)

    def test_get_resource_events(self):
        """Test resource events retrieval."""
        resource = {
            'kind': 'TestResource',
            'metadata': {
                'name': 'test-resource',
                'namespace': 'test-ns',
                'uid': 'test-uid'
            }
        }

        mock_events = {
            'test-uid': [{
                'type': 'Warning',
                'message': 'Resource event',
                'metadata': {
                    'namespace': 'test-ns',
                    'name': 'event-1'
                },
                'involvedObject': {
                    'uid': 'test-uid'
                },
                'lastTimestamp': '2024-02-26T12:00:00Z'
            }]
        }

        # Mock namespace events retrieval
        with unittest.mock.patch.object(
            self.cache, 'get_namespace_events', return_value=mock_events
        ) as mock_get_events:
            result = self.cache.get_resource_events(resource)
            self.assertEqual(len(result), 1)
            self.assertEqual(result[0]['type'], 'Warning')
            self.assertEqual(result[0]['involvedObject']['uid'], 'test-uid')

            # Verify namespace events were fetched
            mock_get_events.assert_called_once_with('test-ns')

    def test_get_events_error_handling(self):
        """Test error handling in event retrieval."""
        # Test namespace events error
        self.mock_client.resources.get.side_effect = Exception("API Error")
        result = self.cache.get_namespace_events('test-ns')
        self.assertEqual(result, {})  # Returns empty dict on error

        # Test resource events error with missing metadata
        result = self.cache.get_resource_events({'kind': 'Invalid'})
        self.assertEqual(result, [])  # Returns empty list for resource events

    def test_discover_group_relationships(self):
        """Test discovery of related groups from CRDs."""
        crds = {
            'items': [{
                'spec': {
                    'group': 'test.group',
                    'names': {'kind': 'TestCRD'},
                    'versions': [{
                        'name': 'v1',
                        'schema': {
                            'openAPIV3Schema': {
                                'properties': {
                                    'spec': {
                                        'properties': {
                                            'resourceRef': {
                                                'properties': {
                                                    'apiVersion': {
                                                        'default': 'related.group/v1'
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }]
                }
            }]
        }

        # Initialize cache with empty relationships
        self.cache._group_relationships = {}

        # Test relationship discovery
        self.cache._discover_group_relationships(crds, 'test.group')

        # Verify relationships were added
        self.assertIn('test.group', self.cache._group_relationships)
        self.assertIn('related.group', self.cache._group_relationships['test.group'])

    def test_guess_related_groups(self):
        """Test guessing related groups from a group name."""
        # Test that no groups are guessed (feature disabled)
        groups = self.cache._guess_related_groups('test.group')
        self.assertEqual(groups, set())

    def test_add_group_relationship(self):
        """Test adding group relationships."""
        # Initialize cache with empty relationships
        self.cache._cache = {'group_relationships': {}}

        # Add relationships
        self.cache._add_group_relationship('source.group', 'target.group')

        # Verify relationships
        relationships = self.cache._cache['group_relationships']
        self.assertIn('source.group', relationships)
        self.assertIn('target.group', relationships['source.group'])

        # Test adding duplicate relationship
        self.cache._add_group_relationship('source.group', 'target.group')
        self.assertEqual(len(relationships['source.group']), 1)

    def test_prefetch_related_groups(self):
        """Test prefetching related group resources."""
        # Test that prefetching is disabled
        group = 'test.group'
        version = 'v1'
        self.cache._prefetch_related_groups(group, version)
        # No assertions needed as method is intentionally disabled


if __name__ == '__main__':
    unittest.main()
