import unittest
from unittest.mock import Mock, patch
from rich.console import Console
from xplorer.display import display_resources, display_child_resources, display_resource

import pytest
from rich.console import Console
from rich.tree import Tree

from xplorer.display import display_resource, STATUS_SYMBOLS

class TestDisplay(unittest.TestCase):
    def setUp(self):
        self.console = Console()
        self.mock_args = Mock()
        self.mock_args.verbose = False

    @patch('rich.console.Console.print')
    def test_display_resources(self, mock_print):
        # Test basic resource display
        test_resource = {
            'apiVersion': 'v1',
            'kind': 'Pod',
            'metadata': {'name': 'test-pod'}
        }
        display_resources(test_resource, None, {}, self.mock_args)
        mock_print.assert_called_once()

    def test_verbose_display(self):
        # Test verbose output
        test_resource = {
            'apiVersion': 'apps/v1',
            'kind': 'Deployment',
            'metadata': {'name': 'test-deploy'},
            'spec': {'replicas': 3}
        }
        # Create a tree and add the resource
        tree = Tree("Test")
        node = display_resource(tree, test_resource, True)

        # Check that the node was created and contains spec details
        self.assertIsNotNone(node)
        # Capture tree output and check content
        with self.console.capture() as capture:
            self.console.print(tree)
        output = capture.get()
        self.assertIn('replicas', output)
        self.assertIn('3', output)

    def test_error_handling(self):
        # Test invalid resource format
        with self.assertLogs(level='ERROR') as cm:
            display_resource(Mock(), {'invalid': 'data'}, False)
        self.assertIn('Missing required fields', cm.output[0])

@pytest.fixture
def test_console():
    return Console()

@pytest.fixture
def test_tree():
    return Tree('Test Tree')

def test_status_indicators(test_console, test_tree):
    # Test Ready status
    ready_resource = {
        'kind': 'Pod',
        'metadata': {'name': 'ready-pod'},
        'status': {'phase': 'Ready'}
    }
    node = display_resource(test_tree, ready_resource, False)
    assert node is not None
    # Capture tree output and check content
    with test_console.capture() as capture:
        test_console.print(test_tree)
    output = capture.get()
    assert "✓" in output  # Check for rendered symbol

    # Test Pending status
    pending_resource = {
        'kind': 'Pod',
        'metadata': {'name': 'pending-pod'},
        'status': {'phase': 'Pending'}
    }
    node = display_resource(test_tree, pending_resource, False)
    assert node is not None
    with test_console.capture() as capture:
        test_console.print(test_tree)
    output = capture.get()
    assert "⌛" in output  # Check for rendered symbol

    # Test Failed status
    failed_resource = {
        'kind': 'Pod',
        'metadata': {'name': 'failed-pod'},
        'status': {'phase': 'Failed'}
    }
    node = display_resource(test_tree, failed_resource, False)
    assert node is not None
    with test_console.capture() as capture:
        test_console.print(test_tree)
    output = capture.get()
    assert "✗" in output  # Check for rendered symbol

    # Test Unknown status
    unknown_resource = {
        'kind': 'Pod',
        'metadata': {'name': 'unknown-pod'},
        'status': {'phase': 'Unknown'}
    }
    node = display_resource(test_tree, unknown_resource, False)
    assert node is not None
    with test_console.capture() as capture:
        test_console.print(test_tree)
    output = capture.get()
    assert "?" in output  # Check for rendered symbol

if __name__ == '__main__':
    unittest.main()
