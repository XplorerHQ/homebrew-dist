import unittest
import pytest
from unittest.mock import Mock, patch, MagicMock
from kubernetes.dynamic import DynamicClient
from xplorer.discovery import (
    discover_by_category,
    discover_xr,
    list_crd_instances,
    get_matches,
    attach_events,
    process_child_resources,
    discover_child_resources
)

@pytest.fixture
def mock_dynamic_client():
    client = Mock(spec=DynamicClient)
    # Mock common methods
    client.resources = Mock()
    client.resources.get.return_value = Mock()
    client.resources.search.return_value = []
    return client

@pytest.fixture
def mock_cache():
    cache = Mock()
    # Mock cache methods
    cache.get_cached_data.return_value = None
    cache.store_data.return_value = None
    cache.get_crds.return_value = {'items': []}
    cache.get_instance.return_value = None
    cache.get_instances.return_value = []
    cache.get_resources_by_owner.return_value = []
    cache.is_cache_valid.return_value = True
    cache.debug = Mock()  # Add debug method
    cache.store_instance = Mock()
    cache.store_instances = Mock()
    return cache

@pytest.fixture
def sample_resource():
    return {
        'apiVersion': 'v1',
        'kind': 'TestResource',
        'metadata': {
            'name': 'test-resource',
            'namespace': 'default',
            'uid': '12345'
        },
        'spec': {
            'replicas': 3
        }
    }

class TestDiscovery:
    """Test cases for resource discovery functionality."""

    def test_discover_by_category_empty(self, mock_dynamic_client, mock_cache):
        """Test discovery with no resources."""
        mock_cache.get_crds.return_value = {'items': []}
        result = discover_by_category('claim', mock_dynamic_client, mock_cache)
        assert result == []
        mock_cache.get_crds.assert_called_once()

    def test_discover_by_category_with_resources(self, mock_dynamic_client, mock_cache):
        """Test discovery with some resources."""
        mock_crds = {
            'items': [{
                'spec': {
                    'group': 'azure.intus.io',
                    'versions': [{'name': 'v1alpha1'}],
                    'names': {
                        'kind': 'TestResource',
                        'plural': 'testresources',
                        'singular': 'testresource',
                        'categories': ['claim']
                    },
                    'scope': 'Namespaced'
                }
            }]
        }
        mock_cache.get_crds.return_value = mock_crds

        result = discover_by_category('claim', mock_dynamic_client, mock_cache)
        assert len(result) == 1
        assert result[0]['group'] == 'azure.intus.io'
        assert result[0]['version'] == 'v1alpha1'
        assert result[0]['details']['kind'] == 'TestResource'

    def test_discover_xr_not_found(self, mock_dynamic_client, mock_cache):
        """Test XR discovery when resource not found."""
        manifest = {
            'spec': {
                'resourceRef': {
                    'apiVersion': 'azure.intus.io/v1alpha1',
                    'kind': 'TestXR',
                    'name': 'test-xr'
                }
            }
        }
        mock_cache.get_instance.return_value = None
        result = discover_xr(manifest, mock_dynamic_client, 'default', mock_cache)
        assert result is None
        mock_cache.get_instance.assert_called_once_with(
            'azure.intus.io', 'v1alpha1', 'TestXR', 'test-xr'
        )

    def test_list_crd_instances_empty(self, mock_dynamic_client, mock_cache):
        """Test listing CRD instances with no results."""
        mock_crd = {
            'group': 'azure.intus.io',
            'version': 'v1alpha1',
            'name': 'testcrds',
            'details': {
                'kind': 'TestCRD',
                'namespaced': True
            }
        }
        mock_cache.get_group_instances.return_value = {}
        result = list_crd_instances(mock_crd, mock_dynamic_client, mock_cache)
        assert result == []
        mock_cache.get_group_instances.assert_called_once_with(
            'azure.intus.io', 'v1alpha1'
        )

    def test_attach_events_no_events(self, mock_dynamic_client, mock_cache, sample_resource):
        """Test attaching events when none exist."""
        # Add status conditions to make resource healthy
        sample_resource['status'] = {
            'conditions': [
                {'type': 'Ready', 'status': 'True'},
                {'type': 'Synced', 'status': 'True'}
            ]
        }
        mock_cache.get_resource_events.return_value = []
        attach_events(sample_resource, mock_dynamic_client, mock_cache)
        assert 'events' not in sample_resource  # Healthy resources don't get events

    def test_process_child_resources_empty(self, mock_dynamic_client, mock_cache):
        """Test processing child resources with empty tree."""
        resource_tree = {'children': []}
        process_child_resources(resource_tree, mock_dynamic_client, mock_cache)
        assert resource_tree == {'children': []}

    def test_discover_child_resources_no_children(self, mock_dynamic_client, mock_cache, sample_resource):
        """Test discovering child resources when none exist."""
        result = discover_child_resources(sample_resource, mock_dynamic_client, mock_cache)
        assert result == {'resource': sample_resource, 'children': []}

    def test_discover_by_category_with_cache(self, mock_dynamic_client, mock_cache):
        """Test discovery using cached data."""
        mock_crds = {
            'items': [{
                'spec': {
                    'group': 'azure.intus.io',
                    'versions': [{'name': 'v1alpha1'}],
                    'names': {
                        'kind': 'TestClaim',
                        'plural': 'testclaims',
                        'singular': 'testclaim',
                        'categories': ['claim']
                    },
                    'scope': 'Namespaced'
                }
            }]
        }
        mock_cache.get_crds.return_value = mock_crds
        result = discover_by_category('claim', mock_dynamic_client, mock_cache)
        assert len(result) == 1
        assert result[0]['group'] == 'azure.intus.io'
        assert result[0]['version'] == 'v1alpha1'
        mock_dynamic_client.resources.search.assert_not_called()

    def test_discover_xr_with_children(self, mock_dynamic_client, mock_cache, sample_resource):
        """Test XR discovery with child resources."""
        # Add resourceRef to sample_resource
        sample_resource['spec'] = {
            'resourceRef': {
                'apiVersion': 'azure.intus.io/v1alpha1',
                'kind': 'TestXR',
                'name': 'test-xr'
            }
        }

        # Mock cache to return the XR
        mock_cache.get_instance.return_value = sample_resource

        result = discover_xr(sample_resource, mock_dynamic_client, 'default', mock_cache)
        assert result == sample_resource
        mock_cache.get_instance.assert_called_once_with(
            'azure.intus.io', 'v1alpha1', 'TestXR', 'test-xr'
        )

    def test_list_crd_instances_with_results(self, mock_dynamic_client, mock_cache):
        """Test listing CRD instances with results."""
        mock_crd = {
            'group': 'azure.intus.io',
            'version': 'v1alpha1',
            'name': 'testcrds',
            'details': {
                'kind': 'TestCRD',
                'namespaced': True
            }
        }

        mock_instance = {
            'kind': 'TestCRD',
            'metadata': {'name': 'test-1'}
        }

        mock_cache.get_group_instances.return_value = {
            'TestCRD': {'test-1': mock_instance}
        }

        result = list_crd_instances(mock_crd, mock_dynamic_client, mock_cache)
        assert len(result) == 1
        assert result[0]['kind'] == 'TestCRD'
        assert result[0]['metadata']['name'] == 'test-1'

    def test_attach_events_with_events(self, mock_dynamic_client, mock_cache, sample_resource):
        """Test attaching events when events exist."""
        # Create an unhealthy resource
        unhealthy_resource = {
            **sample_resource,
            'status': {
                'conditions': [
                    {'type': 'Ready', 'status': 'False'},
                    {'type': 'Synced', 'status': 'False'}
                ]
            }
        }

        events = [{
            'type': 'Warning',
            'message': 'Test event',
            'metadata': {'name': 'test-event'},
            'involvedObject': {'uid': '12345'},
            'lastTimestamp': '2024-02-26T12:00:00Z',
            'reason': 'TestReason'
        }]

        # Mock cache events
        mock_cache.get_resource_events.return_value = events

        # Test event attachment
        result = attach_events(unhealthy_resource, mock_dynamic_client, mock_cache)
        assert result is None  # Function modifies resource in place
        assert 'events' in unhealthy_resource
        assert unhealthy_resource['events'] == events

    def test_discover_child_resources_with_children(self, mock_dynamic_client, mock_cache, sample_resource):
        """Test discovering child resources with actual children."""
        # Create parent resource with resourceRefs
        parent_resource = {
            **sample_resource,
            'spec': {
                'resourceRefs': [{
                    'apiVersion': 'v1',
                    'kind': 'ChildResource',
                    'name': 'child-1'
                }]
            }
        }

        child_resource = {
            'apiVersion': 'v1',
            'kind': 'ChildResource',
            'metadata': {
                'name': 'child-1',
                'namespace': 'default'
            },
            'status': {
                'conditions': [
                    {'type': 'Ready', 'status': 'True'},
                    {'type': 'Synced', 'status': 'True'}
                ]
            }
        }

        # Mock cache responses
        mock_cache.get_resource.return_value = child_resource

        result = discover_child_resources(parent_resource, mock_dynamic_client, mock_cache)
        assert len(result['children']) == 1
        assert result['children'][0]['resource']['kind'] == 'ChildResource'
        assert result['children'][0]['resource']['metadata']['name'] == 'child-1'

    def test_error_conditions(self, mock_dynamic_client, mock_cache, sample_resource):
        """Test various error conditions."""
        # Test network error
        mock_dynamic_client.resources.get.side_effect = Exception("Network error")
        result = discover_xr(sample_resource, mock_dynamic_client, 'default', mock_cache)
        assert result is None

        # Test invalid resource format
        invalid_resource = {'invalid': 'format'}
        result = discover_child_resources(invalid_resource, mock_dynamic_client, mock_cache)
        assert result['children'] == []

        # Test permission error
        mock_dynamic_client.resources.get.side_effect = Exception("Forbidden")
        result = discover_by_category('pods', mock_dynamic_client, mock_cache)
        assert result == []

    def test_get_matches_empty(self, mock_dynamic_client, mock_cache):
        """Test get_matches with no matching resources."""
        matches = [{
            'group': 'azure.intus.io',
            'version': 'v1alpha1',
            'name': 'testclaims',
            'details': {'kind': 'TestClaim'}
        }]
        mock_cache.get_instances.return_value = []
        result = get_matches('test-claim', matches, mock_dynamic_client, mock_cache)
        assert result == []

    def test_get_matches_with_results(self, mock_dynamic_client, mock_cache):
        """Test get_matches with matching resources."""
        # Create CRD with proper structure
        crd = {
            'group': 'azure.intus.io',
            'version': 'v1alpha1',
            'name': 'testclaims',
            'details': {
                'kind': 'TestClaim',
                'namespaced': True
            }
        }

        # Create matching instance
        instance = {
            'apiVersion': 'azure.intus.io/v1alpha1',
            'kind': 'TestClaim',
            'metadata': {'name': 'test-claim'}
        }

        # Mock cache to return instances by group/version
        def get_group_instances(group, version):
            if (group == 'azure.intus.io' and 
                version == 'v1alpha1'):
                return {'TestClaim': {'test-claim': instance}}
            return {}

        mock_cache.get_group_instances.side_effect = get_group_instances

        # Test matching
        result = get_matches('test-claim', [crd], mock_dynamic_client, mock_cache)
        assert len(result) == 1
        assert result[0]['metadata']['name'] == 'test-claim'

        # Verify cache was called correctly
        mock_cache.get_group_instances.assert_called_with(
            'azure.intus.io', 'v1alpha1'
        )

    def test_complex_resource_hierarchy(self, mock_dynamic_client, mock_cache):
        """Test discovering complex resource hierarchies."""
        # Create a complex resource tree with resourceRefs
        parent = {
            'kind': 'ParentResource',
            'metadata': {
                'name': 'parent',
                'uid': 'parent-uid'
            },
            'spec': {
                'resourceRefs': [{
                    'apiVersion': 'v1',
                    'kind': 'ChildResource1',
                    'name': 'child1'
                }]
            }
        }

        child1 = {
            'kind': 'ChildResource1',
            'metadata': {
                'name': 'child1',
                'uid': 'child1-uid'
            },
            'spec': {
                'resourceRefs': [{
                    'apiVersion': 'v1',
                    'kind': 'GrandchildResource',
                    'name': 'grandchild'
                }]
            },
            'status': {
                'conditions': [
                    {'type': 'Ready', 'status': 'True'},
                    {'type': 'Synced', 'status': 'True'}
                ]
            }
        }

        grandchild = {
            'kind': 'GrandchildResource',
            'metadata': {
                'name': 'grandchild',
                'uid': 'grandchild-uid'
            },
            'status': {
                'conditions': [
                    {'type': 'Ready', 'status': 'True'},
                    {'type': 'Synced', 'status': 'True'}
                ]
            }
        }

        # Mock cache responses for resource lookups
        def get_resource(api_version, kind, name=None):
            if kind == 'ChildResource1' and name == 'child1':
                return child1
            elif kind == 'GrandchildResource' and name == 'grandchild':
                return grandchild
            return None

        mock_cache.get_resource.side_effect = get_resource

        # Test discovery
        result = discover_child_resources(parent, mock_dynamic_client, mock_cache)

        # Verify the hierarchy
        assert result['resource'] == parent
        assert len(result['children']) == 1
        assert result['children'][0]['resource']['kind'] == 'ChildResource1'
        assert result['children'][0]['resource']['metadata']['name'] == 'child1'

        # Verify grandchild
        child_result = discover_child_resources(child1, mock_dynamic_client, mock_cache)
        assert len(child_result['children']) == 1
        assert child_result['children'][0]['resource']['kind'] == 'GrandchildResource'
        assert child_result['children'][0]['resource']['metadata']['name'] == 'grandchild'

    def test_cache_invalidation(self, mock_dynamic_client, mock_cache):
        """Test behavior with cache invalidation scenarios."""
        # Test expired cache
        mock_cache.get_crds.return_value = {
            'items': [{
                'spec': {
                    'group': 'azure.intus.io',
                    'versions': [{'name': 'v1alpha1'}],
                    'names': {
                        'kind': 'TestResource',
                        'plural': 'testresources',
                        'singular': 'testresource',
                        'categories': ['claim']
                    },
                    'scope': 'Namespaced'
                },
                'metadata': {
                    'resourceVersion': '2'  # Newer version
                }
            }]
        }

        # First call with expired cache
        mock_cache.is_cache_valid.return_value = False
        result = discover_by_category('claim', mock_dynamic_client, mock_cache)
        assert len(result) == 1
        assert result[0]['group'] == 'azure.intus.io'

        # Second call with valid cache
        mock_cache.is_cache_valid.return_value = True
        mock_cache.get_cached_data.return_value = result
        cached_result = discover_by_category('claim', mock_dynamic_client, mock_cache)
        assert cached_result == result  # Should use cached data
