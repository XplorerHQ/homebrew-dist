import unittest
from unittest.mock import Mock, patch
from xplorer.utils import get_api_data
import json
import sys

class TestUtils(unittest.TestCase):
    def setUp(self):
        self.mock_api_client = Mock()
        # Create a mock response object
        self.mock_response = Mock()
        self.mock_response.data = json.dumps({'kind': 'APIResourceList', 'resources': []})
        # Create a valid response tuple (response, status_code, headers)
        self.valid_response = (self.mock_response, 200, {})

    def test_get_api_data_success(self):
        # Test successful API call
        mock_data = {'kind': 'APIResourceList', 'resources': []}
        mock_response = Mock()
        mock_response.data = json.dumps(mock_data).encode('utf-8')  # Return bytes as the real API would
        self.mock_api_client.call_api.return_value = (mock_response, 200, {})

        result = get_api_data(self.mock_api_client, '/api/v1')
        self.assertIsNotNone(result)
        self.assertIn('kind', result)
        self.assertEqual(result, mock_data)

    def test_get_api_data_http_error(self):
        # Test non-200 response
        error_mock = Mock()
        error_mock.data = ''
        self.mock_api_client.call_api.return_value = (error_mock, 404, {})
        result = get_api_data(self.mock_api_client, '/bad/path')
        self.assertIsNone(result)

    def test_get_api_data_invalid_json(self):
        # Test JSON parsing failure
        invalid_mock = Mock()
        invalid_mock.data = 'not json'
        self.mock_api_client.call_api.return_value = (invalid_mock, 200, {})
        result = get_api_data(self.mock_api_client, '/api/v1')
        self.assertIsNone(result)

    def test_get_api_data_missing_kind(self):
        # Test invalid API response structure
        invalid_mock = Mock()
        invalid_mock.data = json.dumps({'invalid': 'data'})
        self.mock_api_client.call_api.return_value = (invalid_mock, 200, {})
        result = get_api_data(self.mock_api_client, '/api/v1')
        self.assertIsNone(result)

    def test_get_api_data_timeout(self):
        # Test API call exception
        self.mock_api_client.call_api.side_effect = Exception('Timeout')
        result = get_api_data(self.mock_api_client, '/api/v1')
        self.assertIsNone(result)

if __name__ == '__main__':
    unittest.main()
