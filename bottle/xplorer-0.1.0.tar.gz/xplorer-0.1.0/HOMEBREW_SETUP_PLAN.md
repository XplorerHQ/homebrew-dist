# Homebrew Setup Plan for Xplorer

## Current Status
- Created initial Homebrew formula (`xplorer.rb`) 
- Created release script (`scripts/create_release.sh`)
- Updated `pyproject.toml` with Alpha status and no license

## Next Session Action Plan

### Prerequisites
1. Run Claude from parent directory that has access to both:
   - `xplorer/` (this project)
   - `homebrew-xplorer/` (the XplorerHQ/homebrew-xplorer tap repo)

### Tasks for New Session
1. **Verify/Clone Tap Repository**
   - Check if `XplorerHQ/homebrew-xplorer` exists
   - If not, create it with proper tap structure

2. **Set Up Tap Repository Structure**
   - Create `Formula/` directory in homebrew-xplorer
   - Set up proper tap metadata

3. **Integrate Release Process**
   - Move/copy `xplorer.rb` to `homebrew-xplorer/Formula/`
   - Update release script to work with both repositories
   - Create workflow for publishing releases

4. **Test Installation Process**
   - Test local tap installation
   - Verify formula works correctly

### Files Already Created
- `xplorer/xplorer.rb` - Homebrew formula (needs to move to tap repo)
- `xplorer/scripts/create_release.sh` - Release automation script
- Updated `xplorer/pyproject.toml` - Package metadata

### Commands to Run New Session
```bash
cd /Users/alexhubitski/PycharmProjects  # Parent directory
# Then start Claude session from here
```

## Goal
Enable users to install xplorer via:
```bash
brew tap XplorerHQ/xplorer
brew install xplorer
```