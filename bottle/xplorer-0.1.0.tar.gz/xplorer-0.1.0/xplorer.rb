class Xplorer < Formula
  desc "Kubernetes resource explorer with claim-based discovery"
  homepage "https://github.com/XplorerHQ/xplorer"
  url "https://github.com/XplorerHQ/xplorer/archive/v0.1.0.tar.gz"
  sha256 "" # Will be calculated when creating release

  depends_on "python@3.11"

  def install
    venv = virtualenv_create(libexec, "python3.11")
    venv.pip_install resources
    venv.pip_install_and_link buildpath
  end

  def caveats
    <<~EOS
      To use xplorer with your Kubernetes cluster, ensure you have kubectl configured
      and your kubeconfig properly set up.
    EOS
  end

  test do
    assert_match "xplorer", shell_output("#{bin}/xplorer --help")
  end
end