"""Module for displaying Kubernetes resources in a tree structure."""

# Status symbols for resource health
STATUS_SYMBOLS = {
    'healthy': "[green]✓[/green]",
    'unhealthy': "[red]✗[/red]",
    'unknown': "[yellow]?[/yellow]",
    'paused': "[dim]⏸[/dim]"
}

# Configure logging
import logging
logger = logging.getLogger(__name__)

import os
import time
import json
from typing import Dict, Any, Optional
from rich.console import Console
from rich.tree import Tree
from rich import print as rprint
from rich.markup import escape
import sys
from datetime import datetime, timezone
from typing import List, Tuple
from xplorer.utils import should_include_child
from rich.panel import Panel

def format_duration(seconds: float) -> str:
    """Format duration in seconds to minutes and seconds.

    Args:
        seconds: Duration in seconds

    Returns:
        Formatted string like "5m32s"
    """
    minutes = int(seconds // 60)
    remaining_seconds = int(seconds % 60)
    if minutes > 0:
        return f"{minutes}m{remaining_seconds}s"
    return f"{remaining_seconds}s"

def aggregate_events(events: List[dict]) -> Tuple[float, int, float]:
    """Aggregate event statistics.

    Args:
        events: List of events

    Returns:
        Tuple of (last_seen_age, count, total_duration)
    """
    if not events:
        return 0, 0, 0

    now = datetime.now(timezone.utc)
    first_time = None
    last_time = None
    count = len(events)

    for event in events:
        try:
            event_time = datetime.fromisoformat(event.get('lastTimestamp', '').replace('Z', '+00:00'))
        except (ValueError, AttributeError):
            continue
        if first_time is None or event_time < first_time:
            first_time = event_time
        if last_time is None or event_time > last_time:
            last_time = event_time

    if last_time is None or first_time is None:
        return 0, count, 0

    last_seen_age = (now - last_time).total_seconds()
    total_duration = (last_time - first_time).total_seconds()

    return last_seen_age, count, total_duration

def format_size_kb(size_bytes: float) -> str:
    """Format size in bytes to KB with comma separator.

    Args:
        size_bytes: Size in bytes

    Returns:
        Formatted string with size in KB
    """
    return f"{size_bytes/1024:,.1f}"

def attach_events(resource: Dict[str, Any], dynamic_client: Any, cache: Any) -> None:
    """Attach events to a resource using namespace-level caching.

    Args:
        resource: The resource to attach events to
        dynamic_client: The kubernetes dynamic client
        cache: The resource cache instance
    """
    if not isinstance(resource, dict):
        resource = resource.to_dict()

    try:
        name = resource.get('metadata', {}).get('name')
        kind = resource.get('kind')
        cache.debug(f"Checking events for {kind}/{name}")

        # Only fetch events if resource is unhealthy
        conditions = resource.get('status', {}).get('conditions', [])
        ready = next((condition['status'] for condition in conditions if condition['type'] == 'Ready'), 'N/A')
        synced = next((condition['status'] for condition in conditions if condition['type'] == 'Synced'), 'N/A')

        if ready != "True" or synced != "True":
            cache.debug(f"Resource {kind}/{name} is unhealthy (Ready={ready}, Synced={synced}), fetching events")
            events = cache.get_resource_events(resource)
            if events:
                cache.debug(f"Found {len(events)} events for {kind}/{name}")
                resource['events'] = events
            else:
                cache.debug(f"No events found for {kind}/{name}")
        else:
            cache.debug(f"Resource {kind}/{name} is healthy, skipping events")

    except Exception as e:
        print(f"Error fetching events for resource {resource.get('metadata', {}).get('name')}: {e}", file=sys.stderr)

def process_child_resources(resource_tree: Dict[str, Any], dynamic_client: Any, cache: Any) -> None:
    """Process child resources recursively with event caching.

    Args:
        resource_tree: The resource tree to process
        dynamic_client: The kubernetes dynamic client
        cache: The resource cache instance
    """
    if resource_tree and 'resource' in resource_tree:
        name = resource_tree['resource'].get('metadata', {}).get('name')
        kind = resource_tree['resource'].get('kind')
        cache.debug(f"Processing child resource tree for {kind}/{name}")
        attach_events(resource_tree['resource'], dynamic_client, cache)
        for child in resource_tree.get('children', []):
            process_child_resources(child, dynamic_client, cache)

def get_resource_conditions(resource: Dict[str, Any]) -> tuple[str, str]:
    """Get resource ready and synced condition status.

    Args:
        resource: The resource manifest

    Returns:
        Tuple of (ready, synced) status strings
    """
    if resource.get('kind') == 'ProviderConfig':
        return 'True', 'True'

    conditions = resource.get('status', {}).get('conditions', [])
    ready = next((condition['status'] for condition in conditions if condition['type'] == 'Ready'), 'N/A')
    synced = next((condition['status'] for condition in conditions if condition['type'] == 'Synced'), 'N/A')
    return ready, synced

def get_resource_status(resource: Dict[str, Any], parent_is_paused: bool = False) -> str:
    """Get resource status symbol based on conditions.

    Args:
        resource: The resource manifest
        parent_is_paused: Whether any parent resource is paused

    Returns:
        Status symbol (✓, ✗, ?, or ⏸)
    """
    # Check if resource is paused directly or via parent
    annotations = resource.get('metadata', {}).get('annotations', {})
    if parent_is_paused or annotations.get('crossplane.io/paused') == 'true':
        return STATUS_SYMBOLS['paused']

    ready, synced = get_resource_conditions(resource)

    if ready == "True" and synced == "True":
        return STATUS_SYMBOLS['healthy']
    elif ready == "N/A" and synced == "N/A":
        return STATUS_SYMBOLS['unknown']
    else:
        return STATUS_SYMBOLS['unhealthy']

def display_resources(claim_manifest: Dict[str, Any], xr_manifest: Optional[Dict[str, Any]], child_resources: Optional[Dict[str, Any]], verbose: int = 0, dynamic_client: Any = None, cache: Any = None, as_renderable: bool = False) -> Optional[object]:
    """Display resources in a hierarchical tree structure or return as renderable."""
    is_claim_paused = claim_manifest.get('metadata', {}).get('annotations', {}).get('crossplane.io/paused') == 'true'
    name = claim_manifest.get('metadata', {}).get('name', 'unknown')
    namespace = claim_manifest.get('metadata', {}).get('namespace', 'default')
    tree = Tree(f"\U0001F4C1 [bold white]Resource Tree for[/bold white] {name} [bold white]in ns:[/bold white] {namespace}")

    if dynamic_client and cache:
        attach_events(claim_manifest, dynamic_client, cache)
    claim_node = tree.add(f"[bold blue]Claim: {claim_manifest['metadata']['name']}[/bold blue]")
    display_resource(claim_node, claim_manifest, parent_is_paused=False)
    style = "[dim]" if is_claim_paused else "[bold blue]"
    style_end = "[/dim]" if is_claim_paused else "[/bold blue]"
    if xr_manifest is not None:
        if dynamic_client and cache:
            attach_events(xr_manifest, dynamic_client, cache)
        xr_node = claim_node.add(f"{style}[bold]XR: {xr_manifest['kind']}[/bold] [cyan]{xr_manifest['metadata']['name']}[/cyan]{style_end}")
        display_resource(xr_node, xr_manifest, parent_is_paused=is_claim_paused)
        if child_resources and child_resources.get('children'):
            is_parent_paused = is_claim_paused or xr_manifest.get('metadata', {}).get('annotations', {}).get('crossplane.io/paused') == 'true'
            refs_node = xr_node.add(f"{style}[bold]Resource Refs[/bold]{style_end}")
            if dynamic_client and cache:
                process_child_resources(child_resources, dynamic_client, cache)
            for child in child_resources['children']:
                if should_include_child(child['resource'], verbose):
                    resource_node = display_resource(refs_node, child['resource'], parent_is_paused=is_parent_paused)
                    if child.get('children'):
                        display_child_resources(resource_node, child['children'], parent_is_paused=is_parent_paused, dynamic_client=dynamic_client, cache=cache, verbose=verbose)
    if as_renderable:
        return tree
    console = Console()
    console.print(tree)

def display_child_resources(parent_node: Tree, children: list, parent_is_paused: bool = False, dynamic_client: Any = None, cache: Any = None, verbose: int = 0) -> None:
    """Recursively display child resources in the tree.

    Args:
        parent_node: The parent node to add children to
        children: List of child resources
        parent_is_paused: Whether the parent resource is paused
        dynamic_client: The kubernetes dynamic client
        cache: The resource cache instance
        verbose: Verbosity level (0: only unhealthy, 1+: all resources)
    """
    for child in children:
        # Process events for the child resource
        if dynamic_client and cache:
            attach_events(child['resource'], dynamic_client, cache)

        # Only display child if it should be included based on verbose level
        if should_include_child(child['resource'], verbose):
            resource_node = display_resource(parent_node, child['resource'], parent_is_paused=parent_is_paused)
            if child.get('children'):
                display_child_resources(resource_node, child['children'], parent_is_paused=parent_is_paused, dynamic_client=dynamic_client, cache=cache, verbose=verbose)

def display_resource(root_node: Tree, resource: Dict[str, Any], parent_is_paused: bool = False) -> Optional[Tree]:
    """Display a resource in the tree.

    Args:
        root_node: The parent node in the tree
        resource: The resource to display
        parent_is_paused: Whether any parent resource is paused

    Returns:
        The created tree node or None if resource should not be displayed
    """
    if not isinstance(resource, dict):
        resource = resource.to_dict()

    # Check if resource is paused directly or via parent
    annotations = resource.get('metadata', {}).get('annotations', {})
    is_directly_paused = annotations.get('crossplane.io/paused') == 'true'
    is_paused = is_directly_paused or parent_is_paused

    # Get resource status
    status_symbol = get_resource_status(resource, parent_is_paused)

    # Create the node 
    resource_name = resource.get('metadata', {}).get('name', 'Unknown')
    resource_kind = resource.get('kind', 'Unknown')
    ready, synced = get_resource_conditions(resource)

    # Determine status color
    status_color = 'green' if ready == 'True' and synced == 'True' else 'red'

    # Get management policies
    management_policies = resource.get('spec', {}).get('managementPolicies', ['*'])

    # Determine if we need to show management policies and if we need blue background
    show_policies = management_policies != ['*']
    use_blue_background = management_policies == ['Observe']

    # Create base style
    base_style = 'dim' if is_paused else status_color
    bg_style = ' on dark_blue' if use_blue_background else ''

    # Create formatted string based on pause status and policies
    resource_text = f"{status_symbol} [bold]{resource_kind}[/bold] {resource_name}"
    if show_policies:
        resource_text += f" (policies: {', '.join(management_policies)})"

    node = root_node.add(f"[{base_style}{bg_style}]{resource_text}[/{base_style}{bg_style}]")

    # If paused, do not show unhealthy details, conditions, or events
    if is_paused:
        return node

    # Display detailed information for unhealthy resources
    if ready != "True" or synced != "True":
        node.add(f"Ready: [{'green' if ready == 'True' else 'red'}]{ready}[/]")
        node.add(f"Synced: [{'green' if synced == 'True' else 'red'}]{synced}[/]")

        # Display conditions
        conditions = resource.get('status', {}).get('conditions', [])
        if conditions:
            conditions_node = node.add("Conditions:")
            for condition in conditions:
                condition_node = conditions_node.add(f"[cyan]type:[/cyan] [green]{condition.get('type', 'N/A')}[/green]")
                condition_node.add(f"[cyan]lastTransitionTime:[/cyan] [green]\"{condition.get('lastTransitionTime', 'N/A')}\"[/green]")
                condition_node.add(f"[cyan]message:[/cyan] [green]{escape(condition.get('message', 'No message available'))}[/green]")
                condition_node.add(f"[cyan]reason:[/cyan] [green]{escape(condition.get('reason', 'N/A'))}[/green]")
                condition_node.add(f"[cyan]status:[/cyan] [green]{escape(condition.get('status', 'N/A'))}[/green]")

        # Display events if they exist
        events = resource.get('events', [])
        if events:
            last_seen_age, count, total_duration = aggregate_events(events)
            events_node = node.add(f"Events ({count} total):")

            # Group events by type and reason
            event_groups = {}
            for event in events:
                key = (event.get('type', 'N/A'), event.get('reason', 'N/A'))
                if key not in event_groups:
                    event_groups[key] = []
                event_groups[key].append(event)

            # Display grouped events
            for (event_type, event_reason), group_events in event_groups.items():
                last_seen_age, count, total_duration = aggregate_events(group_events)
                event_message = group_events[-1].get('message', 'No message available')

                type_color = "green" if event_type == "Normal" else "red"
                time_info = f"{format_duration(last_seen_age)} (x{count} over {format_duration(total_duration)})"

                event_type_node = events_node.add(f"[{type_color}]{escape(event_type)}[/{type_color}] {time_info}")
                event_type_node.add(f"[cyan]reason:[/cyan] [green]{escape(event_reason)}[/green]")
                event_type_node.add(f"[cyan]message:[/cyan] [green]{escape(event_message)}[/green]")

    return node

def show_cache_info(cache) -> None:
    """Display information about the cache.

    Args:
        cache: The resource cache instance
    """
    console = Console()

    try:
        if not os.path.exists(cache._cache_file):
            console.print("[red]No cache file exists.[/red]")
            return

        size = os.path.getsize(cache._cache_file)
        mtime = os.path.getmtime(cache._cache_file)
        age = time.time() - mtime

        with open(cache._cache_file, 'r') as f:
            data = json.load(f)

        tree = Tree(f"[bold]Cache Information[/bold] ({format_size_kb(size)}KB)")

        # Cache status
        status_node = tree.add("Status")
        if age > cache._cache_ttl:
            status_node.add(f"[red]Expired[/red] ({age/60:.1f}min old, TTL is {cache._cache_ttl/60:.1f}min)")
        else:
            status_node.add(f"[green]Valid[/green] ({age/60:.1f}min old, expires in {(cache._cache_ttl - age)/60:.1f}min)")

        # Content summary
        content = tree.add("Content")
        if 'crds' in data and 'items' in data['crds']:
            content.add(f"CRDs: [cyan]{len(data['crds']['items'])}[/cyan] definitions")

        if 'resources_meta' in data:
            content.add(f"Resources: [cyan]{len(data['resources_meta'])}[/cyan] resource types")

        if 'group_relationships' in data:
            rels = data['group_relationships']
            total_rels = sum(len(v) for v in rels.values())
            rel_node = content.add(f"Group relationships: [cyan]{len(rels)}[/cyan] groups with [cyan]{total_rels}[/cyan] total relationships")

            # Show some example relationships
            if rels:
                examples = tree.add("Example relationships")
                for group, related in list(rels.items())[:3]:  # Show first 3
                    examples.add(f"[yellow]{group}[/yellow] → {', '.join(related[:3])}")
                if len(rels) > 3:
                    examples.add(f"...and {len(rels)-3} more groups")

        console.print(tree)

    except Exception as e:
        console.print(f"[red]Error reading cache: {e}[/red]")

def panel_with_timestamp(renderable) -> Panel:
    now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    return Panel(renderable, title="[bold cyan]Current Resource State[/bold cyan]", subtitle=f"Last updated: {now}", padding=(1,2))
