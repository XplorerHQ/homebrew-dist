from typing import List, Dict, Any, Optional, Tuple
from rich.console import Console
from rich.table import Table
from rich.prompt import Prompt
import shutil
import subprocess
import sys

# Sentinel value for unhealthy selection
UNHEALTHY_SENTINEL = "__UNHEALTHY__"

def prompt_select_claim(instances: List[Dict[str, Any]]) -> Tuple[Optional[str], Optional[str]]:
    """
    Prompt the user to select a claim, show all, or show unhealthy.
    Uses fzf if available, otherwise fallback to rich prompt.
    Returns:
        - (name, namespace) for a specific claim.
        - (None, None) for 'Show All Claims'.
        - (None, UNHEALTHY_SENTINEL) for 'Show Unhealthy Claims'.
    """
    console = Console()
    fzf_available = shutil.which("fzf") is not None
    options = []
    label_to_tuple = {}
    # Compute max widths for pretty alignment
    name_w = max((len(inst.get('metadata', {}).get('name', '')) for inst in instances), default=4)
    kind_w = max((len(inst.get('kind', '')) for inst in instances), default=4)
    ns_w = max((len(inst.get('metadata', {}).get('namespace', '')) for inst in instances), default=9)
    fmt = f"{{:<{name_w}}}  {{:<{kind_w}}}  {{:<{ns_w}}}"
    for inst in instances:
        name = inst.get('metadata', {}).get('name', '')
        kind = inst.get('kind', '')
        namespace = inst.get('metadata', {}).get('namespace', '')
        label = fmt.format(name, kind, namespace)
        label = fmt.format(name, kind, namespace)
        options.append(label)
        label_to_tuple[label] = (name, namespace)

    # Add special options at the bottom for fzf, including key binding hints
    all_option_label = ">>> Show All Claims <<< (Ctrl-A)"
    unhealthy_option_label = ">>> Show Unhealthy Claims <<< (Ctrl-U)"
    # Original options list + separator + special options
    fzf_options = options + ["---", all_option_label, unhealthy_option_label]

    if fzf_available:
        try:
            header = fmt.format('NAME', 'KIND', 'NAMESPACE')
            # Adjust prompt and add cycle for easier navigation
            fzf_cmd = [
                'fzf',
                '--with-nth=1,2,3',
                '--prompt=Select claim (or a special option at top): ', # Updated prompt text to match option location
                '--header', header, # Header should display at top by default
                # '--header-first',
                '--cycle', # Allow cycling through options
                # Use 'become' to replace fzf with a command that outputs the desired option, effectively selecting it
                f'--bind=ctrl-a:become(echo "{all_option_label}")+accept',
                f'--bind=ctrl-u:become(echo "{unhealthy_option_label}")+accept'
            ]
            fzf = subprocess.Popen(fzf_cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True)
            # Use fzf_options with special items at the top
            fzf_input = "\n".join(fzf_options)
            selected, _ = fzf.communicate(fzf_input)
            selected = selected.strip()

            # Check for special options first
            if selected == all_option_label:
                return None, None
            if selected == unhealthy_option_label:
                return None, UNHEALTHY_SENTINEL

            # Extract the name and namespace from the selected row by matching the label
            if selected in label_to_tuple:
                return label_to_tuple[selected]

            # Fallback: try to parse columns if label match failed (unlikely with fzf selection)
            parts = selected.split()
            if len(parts) >= 2 and selected not in ["", all_option_label, unhealthy_option_label]:
                 # Ensure it's not accidentally parsing the special options
                return parts[0], parts[-1] # Assuming name is first, namespace is last

            # If nothing valid selected or empty line chosen
            console.print("[red]No valid selection made. Exiting.[/red]")
            sys.exit(0)

        except Exception as e:
            console.print(f"[red]FZF failed: {e}. Falling back to rich prompt.[/red]")
    # Fallback to rich prompt
    table = Table(show_header=True, header_style="bold magenta")
    table.add_column("#", style="dim", width=4)
    table.add_column("Name")
    table.add_column("Kind")
    table.add_column("Namespace")
    num_instances = len(instances)
    for idx, inst in enumerate(instances):
        name = inst.get('metadata', {}).get('name', '')
        kind = inst.get('kind', '')
        namespace = inst.get('metadata', {}).get('namespace', '')
        table.add_row(str(idx + 1), name, kind, namespace)

    # Add special options to the table display
    table.add_row("---", "---", "---", "---")
    table.add_row("[bold]a[/bold]", "Show All Claims", "", "")
    table.add_row("[bold]u[/bold]", "Show Unhealthy Claims", "", "")

    console.print("\n[bold]Select a claim to inspect, or choose an option:[/bold]")
    console.print(table)

    while True:
        choice = Prompt.ask(f"Enter claim number (1-{num_instances}), 'a' (all), or 'u' (unhealthy)", default="1").lower()
        if choice == 'a':
            return None, None
        if choice == 'u':
            return None, UNHEALTHY_SENTINEL
        if choice.isdigit() and 1 <= int(choice) <= num_instances:
            inst = instances[int(choice) - 1]
            return inst.get('metadata', {}).get('name', ''), inst.get('metadata', {}).get('namespace', '')
        console.print(f"[red]Invalid selection. Please enter a number between 1 and {num_instances}, 'a', or 'u'.[/red]")
