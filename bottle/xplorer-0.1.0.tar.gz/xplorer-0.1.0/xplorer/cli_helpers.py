"""CLI helper functions for Kubernetes resource exploration."""

import sys
import signal
from rich.console import Console

def signal_handler(sig, frame):
    """
    Handle SIGINT (Ctrl-C) signal.

    Args:
        sig: Signal number
        frame: Current stack frame

    Returns:
        None (exits the program)
    """
    console = Console()
    console.print("\n[red]Operation was aborted.[/red]")
    sys.exit(0)

def print_repeat_command_suggestion(suggested_command, unhealthy=False):
    """
    Print a suggestion for repeating the current command.

    Args:
        suggested_command: The suggested command string
        unhealthy: Whether to only show unhealthy claims

    Returns:
        None
    """
    if suggested_command and not unhealthy:
        console = Console()
        console.print(f"\n[bold green]To repeat this selection, run:[/bold green]\n$ {suggested_command}\n")

def print_watch_suggestion_for_unhealthy_claim(match, unhealthy=False, verbose=0):
    """
    Print a suggestion for watching an unhealthy claim.

    Args:
        match: The claim manifest
        unhealthy: Whether to only show unhealthy claims
        verbose: Verbosity level

    Returns:
        None
    """
    if unhealthy:
        console = Console()
        claim_name = match.get('metadata', {}).get('name')
        namespace = match.get('metadata', {}).get('namespace', 'default')
        v_arg = f"-{'v'*verbose}" if verbose else ""
        watch_command_parts = ["xplorer", claim_name, "-n", namespace, "--watch"]
        if v_arg:
            watch_command_parts.append(v_arg)
        suggested_command = " ".join(watch_command_parts)
        console.print(f"\n[bold green]To watch this claim, run:[/bold green]\n$ {suggested_command}\n")
