"""Command-line interface for Kubernetes resource exploration."""

import argparse
import sys
import signal
import socket
import urllib3
from rich.progress import Progress, SpinnerColumn, TimeElapsedColumn, TextColumn
from rich.console import Console
from xplorer.client import get_dynamic_client, handle_connection_error
from xplorer.processing import process_all_claims, process_single_claim, claim_matches
from xplorer.watch import watch_claim
from xplorer.interactive import (
    needs_interactive_prompt,
    handle_namespace_without_claim,
    run_interactive_prompt,
    handle_no_specific_claim,
    get_repeat_command_suggestion
)
from xplorer.cli_helpers import signal_handler, print_repeat_command_suggestion, print_watch_suggestion_for_unhealthy_claim
from xplorer.display import display_resources, show_cache_info
from xplorer.discovery import discover_by_category
from xplorer.utils import should_include_child

# Register the signal handler
signal.signal(signal.SIGINT, signal_handler)


def main():
    connection_error = None
    parser = argparse.ArgumentParser(
        description="Discover API resources that are in the 'claim' category from discovery endpoints."
    )
    parser.add_argument("claim_name", nargs='?', help="Name of the claim CRD instance to match")
    parser.add_argument("--all", "-A", help="List all claims in the cluster", action="store_true")
    parser.add_argument("--namespace", "-n", help="Namespace to search in", default="default")
    parser.add_argument("-k", "--kind", help="Show all claims for the specified claim kind (filters by claim kind)", default=None)
    parser.add_argument("-v", "--verbose", help="Show all child resources, including healthy ones (default: only unhealthy/unknown child resources)", action="count", default=0)
    parser.add_argument("--unhealthy", help="Only show claims that are not Ready/Synced (used with --all or interactive selection)", action="store_true")
    parser.add_argument("--debug", help="Enable debug mode", action="store_true")
    parser.add_argument("--refresh-cache", help="Force cache refresh", action="store_true")
    parser.add_argument("--show-cache", help="Show cache information and exit", action="store_true")
    parser.add_argument("--cache-server", help="Address of the xplorer-cache server or proxy (e.g. http://localhost:8443 or https://proxy.example.com/proxy)", default=None)
    parser.add_argument("--context", help="Kubernetes context to use (passes this context to xplorer-cache when used with --cache-server)", default=None)
    parser.add_argument("--watch", help="Watch the specified claim for changes (optionally specify period in seconds and timeout in minutes, e.g. --watch=10,20)", nargs='?', const=True)
    args = parser.parse_args()

    # Determine if interactive prompt is needed and handle namespace without claim
    needs_prompt = needs_interactive_prompt(args.claim_name, args.kind, args.all, args.namespace)
    should_set_all = handle_namespace_without_claim(args.claim_name, args.kind, args.all, args.namespace)
    if should_set_all:
        args.all = True

    # If interactive prompt is needed, prepare and show it
    selected_claim_and_ns = None
    all_claims = None
    if needs_prompt:
        dynamic_client, cache = get_dynamic_client(args.debug, args.cache_server, args.context)
        selected_claim_and_ns, all_claims, updated_args = run_interactive_prompt(args.debug, dynamic_client, cache)
        # Update args with the values from interactive prompt
        if 'all_flag' in updated_args:
            args.all = updated_args['all_flag']
        if 'claim_name' in updated_args:
            args.claim_name = updated_args['claim_name']
        if 'namespace' in updated_args:
            args.namespace = updated_args['namespace']
        if 'unhealthy' in updated_args:
            args.unhealthy = updated_args['unhealthy']
    else:
        # Default to showing all if no specific claim/kind/all is given
        should_set_all = handle_no_specific_claim(args.claim_name, args.all)
        if should_set_all:
            args.all = True

    # Use should_include_child from utils.py directly

    with Progress(
        SpinnerColumn(),
        *Progress.get_default_columns(),
        "Elapsed:",
        TimeElapsedColumn(),
        TextColumn("[bold]{task.fields[status]}"),
        transient=True
    ) as progress:
        # Add two tasks: one for cache info and one for progress
        cache_task = progress.add_task("[dim]Discovery Cache[/dim]", total=1, status="Initializing...")
        main_task = progress.add_task("[cyan]Initializing...[/cyan]", total=100, status="Starting discovery")

        # --- Initial Connection Check ---
        try:
            # Attempt to get the dynamic client first
            dynamic_client, cache = get_dynamic_client(args.debug, args.cache_server, args.context)

            # Perform a lightweight check to verify connectivity
            # Example: Get server version or check a known endpoint
            # Using get_api_versions() as a relatively lightweight check
            cache.debug("Performing initial connection check...")
            dynamic_client.version # Accessing the version property often triggers a connection
            cache.debug("Initial connection check successful.")

        except (urllib3.exceptions.MaxRetryError, socket.gaierror, urllib3.exceptions.NameResolutionError) as e:
            # Handle connection error immediately if the initial check fails
            handle_connection_error(e, args.debug, args.cache_server)
            # handle_connection_error exits, so no need for explicit sys.exit here
        except Exception as e:
            # Catch other potential init errors (like config loading)
            print(f"[red]Error during initialization: {e}[/red]")
            sys.exit(1)
        # --- End Initial Connection Check ---

        # Proceed with the rest of the logic using the obtained client and cache
        try:
            if args.show_cache:
                show_cache_info(cache)
                sys.exit(0)

            if args.refresh_cache:
                cache.clear_cache()
                cache.debug("Cache cleared, forcing refresh")

            # Get and format cache info if available
            cache_info = cache.get_cache_info()
            if cache_info:
                from xplorer.display import format_size_kb
                cache_status = f"[dim]Using cached data ({format_size_kb(cache_info['size'] * 1024)}KB, {cache_info['age']:.1f}min old)[/dim]"
            else:
                cache_status = "[dim]Using fresh data[/dim]"

            # Update cache status task
            progress.update(cache_task, completed=1, status=cache_status)
            progress.update(main_task, status=f"Processing claim{'s' if args.all else ''}")

            matches = discover_by_category("claim", dynamic_client, cache)
            if not matches:
                print("No matching CRDs found.", file=sys.stderr)
                sys.exit(0)

            # Process claims based on args
            all_matches = []
            error_message = None

            if args.all:
                # Process all claims
                all_matches = process_all_claims(matches, args.namespace, args.unhealthy, args.kind, dynamic_client, cache, progress, main_task, args.verbose)
            else:
                # Process a single claim
                all_matches, error_message = process_single_claim(args.claim_name, args.namespace, matches, dynamic_client, cache, progress, main_task, args.verbose)
                if error_message:
                    print(error_message, file=sys.stderr)
                    sys.exit(0 if "No instance named" in error_message else 1)
        except urllib3.exceptions.MaxRetryError as e:
            connection_error = e
        except Exception as e:
            print(f"[red]An unexpected error occurred: {e}[/red]")
            sys.exit(1)

    # Handle connection error outside the progress context manager to ensure it's closed
    if connection_error:
        handle_connection_error(connection_error, args.debug, args.cache_server)

    # Display results
    console = Console()
    if not all_matches:
        if args.all:
            message = "No claims found"
            if args.unhealthy:
                message += " matching unhealthy criteria"
            if args.namespace != 'default':
                message += f" in namespace {args.namespace}"
            if args.kind:
                message += f" of kind {args.kind}"
            console.print(f"[yellow]{message}.[/yellow]")
        # The single claim case already exited if not found
    elif args.all:
        for match in all_matches:
            # Pass dynamic_client and cache to display_resources for event fetching
            display_resources(match, match.get('xr_manifest'), match.get('child_resources'), args.verbose, dynamic_client, cache)

            # If --unhealthy is used, suggest a watch command for this specific claim
            print_watch_suggestion_for_unhealthy_claim(match, args.unhealthy, args.verbose)

            console.print("-" * 80) # Separator between claims
    elif len(all_matches) == 1: # Displaying a single selected claim
        # --- WATCH MODE ---
        if args.watch and args.claim_name:
            watch_claim(args.claim_name, args.namespace, matches, dynamic_client, cache, args.watch, args.verbose)
        else:
            # Display static output for a single claim
            manifest = all_matches[0]
            discovered_manifests = manifest.get('child_resources')
            xr_manifest = discovered_manifests.get('resource')
            display_resources(manifest, xr_manifest, discovered_manifests, args.verbose, dynamic_client, cache)
    # Suggest repeat command if an interactive selection was made
    if selected_claim_and_ns:
        suggested_command = get_repeat_command_suggestion(selected_claim_and_ns, args.verbose)
        print_repeat_command_suggestion(suggested_command, args.unhealthy)


if __name__ == '__main__':
    main()
