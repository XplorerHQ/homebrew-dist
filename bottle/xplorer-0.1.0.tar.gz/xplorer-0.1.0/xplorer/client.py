"""Client module for Kubernetes resource exploration."""

import sys
import urllib3
from kubernetes import config
from kubernetes.client import api_client
from kubernetes.dynamic import DynamicClient
from rich.console import Console
from xplorer.cache import ResourceCache

def get_dynamic_client(debug=False, cache_server=None, context_name=None):
    """Create a dynamic client with built-in caching, with error handling.
    
    Args:
        debug: Whether to show debug output
        cache_server: Address of the xplorer-cache server or proxy (e.g. http://localhost:8443 or https://proxy.example.com/proxy)
        context_name: Kubernetes context name to use (if None, uses current context)
    """
    try:
        # Get the current context name if not explicitly provided
        current_context = context_name
        if not current_context:
            try:
                # Load the kubeconfig file to get access to the current context
                # Use the correct method to get the current context
                _, active_context = config.list_kube_config_contexts()
                current_context = active_context['name'] if active_context else None
                if debug:
                    print(f"[DEBUG] Current Kubernetes context: {current_context}", file=sys.stderr)
            except Exception as e:
                if debug:
                    print(f"[DEBUG] Error getting current context: {e}", file=sys.stderr)
                # Don't fail if we can't get the context, just proceed without it
                current_context = None
                
        if cache_server:
            # Configure the client to use the xplorer-cache server instead of direct cluster connection
            # Create a custom configuration for the API client
            client_config = api_client.Configuration()
            
            # Parse the cache_server URL and enforce proxy prefix
            cache_url = cache_server
            if not (cache_server.startswith("http://") or cache_server.startswith("https://")):
                cache_url = f"https://{cache_server}"
            
            # Always enforce /proxy prefix to prevent wrong endpoint access
            from urllib.parse import urlparse
            parsed_url = urlparse(cache_url)
            
            # Always add /proxy prefix (even if a path already exists)
            if parsed_url.path and not parsed_url.path.startswith('/proxy'):
                # Prepend /proxy to existing path
                cache_url = f"{parsed_url.scheme}://{parsed_url.netloc}/proxy{parsed_url.path}"
            elif not parsed_url.path or parsed_url.path == '/':
                # Add /proxy as the path (without trailing slash)
                cache_url = f"{parsed_url.scheme}://{parsed_url.netloc}/proxy"
            # If already starts with /proxy, keep as is
            
            # Ensure no trailing slash to prevent double slashes in API calls
            if cache_url.endswith('/') and cache_url != f"{parsed_url.scheme}://{parsed_url.netloc}/":
                cache_url = cache_url.rstrip('/')
            
            if debug:
                print(f"[DEBUG] Enforced proxy prefix URL: {cache_url}", file=sys.stderr)
            
            # Set the host to include the proxy path prefix
            client_config.host = cache_url
            
            # Create the API client instance
            api_client_instance = api_client.ApiClient(configuration=client_config)
            
            # Add the current context as a custom header if available
            if current_context:
                api_client_instance.default_headers['X-Kubernetes-Context'] = current_context
                if debug:
                    print(f"[DEBUG] Using context '{current_context}' with xplorer-cache", file=sys.stderr)
                
            # Use the API client to create the dynamic client
            client = DynamicClient(api_client_instance)
            
            if debug:
                print(f"[DEBUG] Using xplorer-cache server at {client_config.host}", file=sys.stderr)
        else:
            # Use standard kubeconfig with the specified context if provided
            if context_name:
                config.load_kube_config(context=context_name)
                if debug:
                    print(f"[DEBUG] Using specified Kubernetes context: {context_name}", file=sys.stderr)
            else:
                # Use the default context from kubeconfig
                config.load_kube_config()
                
            client = DynamicClient(api_client.ApiClient())
            
        return client, ResourceCache(client, debug)
    except (urllib3.exceptions.MaxRetryError, Exception) as e:
        handle_connection_error(e, debug, cache_server)
        # handle_connection_error will exit, but return None for clarity
        return None, None

def handle_connection_error(e, debug=False, cache_server=None):
    """
    Handle connection errors with user-friendly messages and suggestions.
    
    Args:
        e: The exception that occurred
        debug: Whether to show technical details
        cache_server: Whether a cache server was specified
    """
    error_str = str(e)

    # Extract the host information if available
    host = "the Kubernetes API server"
    if "host='" in error_str:
        host_start = error_str.find("host='") + 6
        host_end = error_str.find("'", host_start)
        if host_start > 6 and host_end > host_start:
            host = error_str[host_start:host_end]

    console = Console()
    console.print("[red bold]Connection Error:[/red bold]")
    console.print(f"[red]Unable to connect to [bold]{host}[/bold][/red]")
    console.print("")

    if host.startswith("http://") or host.startswith("https://"):
        # This is likely a connection to the xplorer-cache server
        console.print("[yellow]Possible causes:[/yellow]")
        console.print(" • The xplorer-cache server is not running or not accessible")
        console.print(" • Incorrect xplorer-cache server address specified")
        console.print(" • Network connectivity issues to the xplorer-cache server")
        console.print("")

        console.print("[green]Try the following:[/green]")
        console.print(" • Verify the xplorer-cache server is running")
        console.print(" • Check the address specified with --cache-server parameter")
        console.print(" • Ensure network connectivity to the xplorer-cache server")
        console.print(" • If issues persist, try connecting directly to the cluster without xplorer-cache")
    else:
        # Standard Kubernetes cluster connection
        console.print("[yellow]Possible causes:[/yellow]")
        console.print(" • The Kubernetes cluster is not accessible from your current network")
        console.print(" • DNS resolution failed for the cluster domain")
        console.print(" • Authentication credentials are invalid or expired")
        console.print(" • Cluster endpoint is incorrect in your kubeconfig")
        console.print("")

        console.print("[green]Try the following:[/green]")
        console.print(" • Verify your network connectivity to the cluster")
        console.print(" • Verify your kubeconfig is correct: [bold]kubectl config view[/bold]")
        console.print(" • Confirm cluster accessibility: [bold]kubectl cluster-info[/bold]")
        console.print(" • Check if credentials need to be refreshed")
    
    console.print("")

    # Only show technical details if debug mode is enabled
    if debug:
        console.print("[dim]Technical details:[/dim]")
        console.print(f"[dim]{error_str}[/dim]")
    sys.exit(1)
