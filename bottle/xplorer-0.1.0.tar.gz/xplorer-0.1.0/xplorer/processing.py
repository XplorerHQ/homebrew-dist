"""Processing module for Kubernetes resource exploration."""

from typing import Dict, Any, List, Optional
from rich.progress import Progress
from xplorer.display import get_resource_conditions
from xplorer.discovery import (
    discover_by_category,
    discover_xr,
    discover_child_resources,
    list_crd_instances,
    get_matches
)
from xplorer.utils import check_resource_health

def claim_matches(instance, claim_name=None, all_flag=False, namespace=None, kind=None, unhealthy=False, dynamic_client=None, cache=None):
    """
    Determine if a claim instance matches the filtering criteria.

    Args:
        instance: The claim instance to check
        claim_name: Name of the claim to match
        all_flag: Whether to show all claims
        namespace: Namespace to filter by
        kind: Kind to filter by
        unhealthy: Whether to only show unhealthy claims
        dynamic_client: Kubernetes dynamic client
        cache: Resource cache

    Returns:
        bool: True if the instance matches the criteria, False otherwise
    """
    # Filter by name if provided
    if claim_name and instance.get('metadata', {}).get('name') != claim_name:
        return False
    # Filter by namespace if provided (and not showing all)
    if not all_flag and namespace and instance.get('metadata', {}).get('namespace') != namespace:
         # Note: Namespace filtering is primarily for single claim selection.
         # When --all is used, we typically show claims from all namespaces unless -n is also specified.
         # Let's adjust this logic slightly: if -n is given with --all, filter by namespace.
         pass # Let namespace filtering happen later if needed with --all -n
    # Filter by kind if provided
    if kind and instance.get('kind') != kind:
        return False
    # Filter by health status if --unhealthy is set
    if unhealthy:
        # Check top-level claim conditions
        ready, synced = get_resource_conditions(instance)

        # If the claim itself is unhealthy, include it
        if ready != 'True' or synced != 'True':
            return True

        # If the claim is healthy, check if any referenced resources are unhealthy
        # Discover XR for the claim
        xr_manifest = discover_xr(instance, dynamic_client, namespace, cache)
        if xr_manifest:
            # Check if XR is unhealthy
            xr_ready, xr_synced = get_resource_conditions(xr_manifest)
            if xr_ready != 'True' or xr_synced != 'True':
                return True

            # Check if any referenced resources are unhealthy by walking references directly
            if 'spec' in xr_manifest and 'resourceRefs' in xr_manifest['spec']:
                # Check each top-level reference
                resource_refs = xr_manifest['spec'].get('resourceRefs', [])
                for ref in resource_refs:
                    api_version = ref.get('apiVersion', '')
                    kind = ref.get('kind', '')
                    name = ref.get('name', '')

                    if not api_version or not kind or not name:
                        continue

                    # Split api_version for the group cache
                    group = ''
                    version = api_version
                    if '/' in api_version:
                        group, version = api_version.split('/')

                    # Get the instance using the cache
                    if group and version and kind and name:
                        result = cache.get_instance(group, version, kind, name)
                        if result and check_resource_health(result, cache):
                            return True

        # If we get here, the claim and all its referenced resources are healthy
        return False # Skip healthy claims
    return True

def process_all_claims(matches, namespace, unhealthy, kind, dynamic_client, cache, progress=None, main_task=None, verbose=0):
    """
    Process all claims in the cluster based on filtering criteria.

    Args:
        matches: List of CRD matches from discover_by_category
        namespace: Namespace to filter by
        unhealthy: Whether to only show unhealthy claims
        kind: Kind to filter by
        dynamic_client: Kubernetes dynamic client
        cache: Resource cache
        progress: Rich progress instance for displaying progress
        main_task: Task ID for the progress bar
        verbose: Verbosity level (0: only unhealthy, 1+: all resources)

    Returns:
        list: List of processed claim instances with their XR and child resources
    """
    # Pre-fetch all unique groups before processing claims
    unique_groups = set()
    for crd in matches:
        group = crd['group']
        version = crd['version']
        unique_groups.add((group, version))

    # Show group prefetching progress
    num_groups = len(unique_groups)
    if num_groups > 0 and progress and main_task:
        # Set initial progress for prefetching phase (0-20% range)
        progress.update(main_task, total=100)
        progress.update(main_task, completed=0, status=f"Prefetching [cyan]{num_groups}[/cyan] resource groups...")

        for i, (group, version) in enumerate(unique_groups, 1):
            # Calculate progress within 0-20% range
            step_progress = int((i / num_groups) * 20)
            progress.update(main_task, completed=step_progress, 
                          status=f"Prefetching group [cyan]{i}/{num_groups}[/cyan]: [blue]{group}[/blue]")
            cache.get_group_instances(group, version)

    # Collect all instances first
    all_instances_unfiltered = []
    for crd in matches:
        instances = list_crd_instances(crd, dynamic_client, cache)
        all_instances_unfiltered.extend(instances)

    # Apply filters: namespace (if specified with --all), kind, and health status
    filtered_instances = []
    for inst in all_instances_unfiltered:
        # Apply namespace filter only if -n was explicitly provided with --all
        if namespace != 'default' and inst.get('metadata', {}).get('namespace') != namespace:
            continue
        # Apply kind and health filters using claim_matches
        if claim_matches(inst, all_flag=True, namespace=namespace, kind=kind, unhealthy=unhealthy, dynamic_client=dynamic_client, cache=cache):
            filtered_instances.append(inst)

    total_matches = len(filtered_instances)
    if progress and main_task:
        status_message = f"Processing [cyan]{total_matches}[/cyan] claims"
        if unhealthy:
            status_message += " (unhealthy only)"
        if namespace != 'default':
            status_message += f" in namespace [blue]{namespace}[/blue]"
        if kind:
            status_message += f" of kind [blue]{kind}[/blue]"

        # Start claim processing from 20%
        progress.update(main_task, completed=20, status=status_message)

    # Process filtered instances
    all_matches_processed = []
    processed = 0

    for instance in filtered_instances:
        name = instance.get('metadata', {}).get('name', 'unknown')
        kind = instance.get('kind', 'unknown')

        if progress and main_task:
            # Calculate progress based on filtered count
            progress_percent = 20 + int((processed / total_matches) * 80) if total_matches > 0 else 100
            progress.update(main_task, completed=progress_percent, status=f"Processing [blue]{kind}/{name}[/blue] ({processed + 1}/{total_matches})")
            progress.update(main_task, status=f"Discovering XR for [blue]{kind}/{name}[/blue]...")

        xr_manifest = discover_xr(instance, dynamic_client, namespace, cache)
        if xr_manifest:
            instance['xr_manifest'] = xr_manifest
            # Set only_unhealthy based on verbose flag
            only_unhealthy = not verbose
            discovered_manifests = discover_child_resources(xr_manifest, dynamic_client, cache, only_unhealthy=only_unhealthy)
            instance['child_resources'] = discovered_manifests
        # Add processed instance to the list
        all_matches_processed.append(instance)
        processed += 1

    if progress and main_task:
        progress.update(main_task, completed=100, status=f"Processed [cyan]{processed}[/cyan] claims")

    return all_matches_processed

def process_single_claim(claim_name, namespace, matches, dynamic_client, cache, progress=None, main_task=None, verbose=0):
    """
    Process a single claim specified by name and namespace.

    Args:
        claim_name: Name of the claim to process
        namespace: Namespace of the claim
        matches: List of CRD matches from discover_by_category
        dynamic_client: Kubernetes dynamic client
        cache: Resource cache
        progress: Rich progress instance for displaying progress
        main_task: Task ID for the progress bar
        verbose: Verbosity level (0: only unhealthy, 1+: all resources)

    Returns:
        tuple: (list of processed claims, error message if any)
    """
    import sys

    if progress and main_task:
        progress.update(main_task, completed=20, status=f"Finding claim [blue]{claim_name}[/blue] in namespace [blue]{namespace}[/blue]...")

    # Use get_matches which respects claim_name
    matching_crds = get_matches(claim_name, matches, dynamic_client, cache)

    # Filter the results by namespace *after* getting potential matches by name
    manifest = None
    user_set_namespace = any(arg in ('-n', '--namespace') for arg in sys.argv)
    if user_set_namespace:
        namespace_filtered = [
            m for m in matching_crds
            if m.get('metadata', {}).get('namespace', 'default').lower() == namespace.lower()
        ]
    else:
        namespace_filtered = matching_crds

    if len(namespace_filtered) == 1:
        manifest = namespace_filtered[0]
    elif len(namespace_filtered) > 1:
        # This case should be rare if get_matches worked correctly, but handle defensively
        return [], f"Error: Multiple claims named '{claim_name}' found. Please specify --namespace."
    # If len is 0, manifest remains None

    if not manifest:
        return [], f"No instance named '{claim_name}' found in namespace '{namespace}'."

    # Assign to all_matches for consistency in display logic later
    all_matches = [manifest] # List containing the single matched manifest

    # Discover XR for claim
    if progress and main_task:
        progress.update(main_task, completed=40, status=f"Discover XR for [blue]{claim_name}[/blue] claim...")

    xr_manifest = discover_xr(manifest, dynamic_client, namespace, cache)

    # Always discover children if there is an XR
    discovered_manifests = None
    if xr_manifest:
        # Set only_unhealthy based on verbose flag
        only_unhealthy = not verbose
        discovered_manifests = discover_child_resources(xr_manifest, dynamic_client, cache, only_unhealthy=only_unhealthy)
        manifest['child_resources'] = discovered_manifests

    if progress and main_task:
        progress.update(main_task, completed=100, status=f"Done...")

    return all_matches, None
