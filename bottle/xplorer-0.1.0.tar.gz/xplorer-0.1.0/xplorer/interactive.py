"""Interactive module for Kubernetes resource exploration."""

import sys
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.console import Console
from xplorer.prompt_utils import prompt_select_claim, UNHEALTHY_SENTINEL
from xplorer.discovery import discover_by_category, list_crd_instances

def needs_interactive_prompt(claim_name=None, kind=None, all_flag=False, namespace='default'):
    """
    Determine if interactive prompt is needed based on command line arguments.

    Args:
        claim_name: Name of the claim to match
        kind: Kind to filter by
        all_flag: Whether to show all claims
        namespace: Namespace to filter by

    Returns:
        bool: True if interactive prompt is needed, False otherwise
    """
    # Prompt only if no specific claim/kind/all is given AND the namespace is the default.
    # If a specific namespace is provided, we skip the prompt and assume --all for that namespace.
    return not claim_name and not kind and not all_flag and namespace == 'default'

def handle_namespace_without_claim(claim_name=None, kind=None, all_flag=False, namespace='default'):
    """
    Handle the case where a namespace is specified but no claim name or kind.

    Args:
        claim_name: Name of the claim to match
        kind: Kind to filter by
        all_flag: Whether to show all claims
        namespace: Namespace to filter by

    Returns:
        bool: True if args.all should be set to True, False otherwise
    """
    # If prompt is skipped because a namespace was specified, set all_flag to True
    if not needs_interactive_prompt(claim_name, kind, all_flag, namespace) and namespace != 'default' and not claim_name and not kind:
        return True
    return False

def run_interactive_prompt(debug=False, dynamic_client=None, cache=None):
    """
    Run the interactive prompt to select a claim.

    Args:
        debug: Whether to enable debug mode
        dynamic_client: Kubernetes dynamic client
        cache: Resource cache

    Returns:
        tuple: (selected_claim_and_ns, all_claims, updated_args) where:
               - selected_claim_and_ns is a tuple (name, namespace)
               - all_claims is a list of all claims found
               - updated_args is a dict with updated values for 'all_flag', 'claim_name', 'namespace', 'unhealthy'
    """
    selected_claim_and_ns = None

    with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), transient=True) as progress:
        progress.add_task(description="Building list of claims for selection...", total=None)
        if dynamic_client is None or cache is None:
            from xplorer.client import get_dynamic_client
            dynamic_client, cache = get_dynamic_client(debug)
        matches = discover_by_category("claim", dynamic_client, cache)
        all_claims = []
        for crd in matches:
            instances = list_crd_instances(crd, dynamic_client, cache)
            all_claims.extend(instances)

    if not all_claims:
        console = Console()
        console.print("No claims found in the cluster.", style="red")
        sys.exit(0)

    # Call the prompt function
    selected_name, selected_ns = prompt_select_claim(all_claims)

    # Prepare updated args dict
    updated_args = {}

    # Handle the prompt result
    if selected_name is None and selected_ns is None:
        # User selected "Show All Claims"
        updated_args['all_flag'] = True
        updated_args['claim_name'] = None
        # Keep namespace as default ('default') to signify no specific namespace filter
        updated_args['namespace'] = 'default'
        updated_args['unhealthy'] = False # Explicitly set unhealthy to false if 'all' is chosen
        selected_claim_and_ns = ('all', None) # Indicate 'all' was chosen interactively
    elif selected_name is None and selected_ns == UNHEALTHY_SENTINEL:
        # User selected "Show Unhealthy Claims"
        updated_args['all_flag'] = True
        updated_args['unhealthy'] = True
        updated_args['claim_name'] = None
        # Keep namespace as default ('default') to signify no specific namespace filter
        updated_args['namespace'] = 'default'
        selected_claim_and_ns = ('unhealthy', None) # Indicate 'unhealthy' was chosen interactively
    else:
        # User selected a specific claim
        updated_args['all_flag'] = False # Ensure --all is off if a specific claim is chosen
        updated_args['claim_name'] = selected_name
        updated_args['namespace'] = selected_ns
        selected_claim_and_ns = (selected_name, selected_ns) # Store for repeat message

    return selected_claim_and_ns, all_claims, updated_args

def handle_no_specific_claim(claim_name=None, all_flag=False):
    """
    Handle the case where no specific claim/kind/all is given.

    Args:
        claim_name: Name of the claim to match
        all_flag: Whether to show all claims

    Returns:
        bool: True if args.all should be set to True, False otherwise
    """
    # Default to showing all if no specific claim/kind/all is given
    if not claim_name and not all_flag:
        return True
    return False

def get_repeat_command_suggestion(selected_claim_and_ns, verbose=0):
    """
    Generate a command suggestion for repeating the current selection.

    Args:
        selected_claim_and_ns: Tuple (name, namespace) of the selected claim
        verbose: Verbosity level

    Returns:
        str: Suggested command or None if no suggestion is needed
    """
    if not selected_claim_and_ns:
        return None

    selected_name, selected_ns = selected_claim_and_ns
    v_arg = f"-{'v'*verbose}" if verbose else ""
    command_parts = ["xplorer"]

    if selected_name == 'all':
        command_parts.append("--all")
    elif selected_name == 'unhealthy':
        command_parts.append("--all")
        command_parts.append("--unhealthy")
    elif selected_name: # Specific claim selected
        command_parts.append(selected_name)
        if selected_ns:
            command_parts.extend(["-n", selected_ns])

    if v_arg:
        command_parts.append(v_arg)

    # Only return if we actually constructed a command beyond just 'xplorer'
    if len(command_parts) > 1:
        return " ".join(command_parts)
    return None
