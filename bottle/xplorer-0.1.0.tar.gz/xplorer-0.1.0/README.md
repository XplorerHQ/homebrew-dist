# Xplorer - Crossplane Resource Visualization Tool

Xplorer is a specialized command-line tool designed to visualize and debug Crossplane resources in your Kubernetes cluster. It helps platform engineers and operators understand the relationships between Crossplane claims, their composite resources (XRs), and managed resources, making it easier to troubleshoot and fix issues in your cloud-native infrastructure.

## Overview

When working with Crossplane, understanding the relationship between different resources and identifying issues can be challenging. Xplorer simplifies this by:
- Visualizing the complete hierarchy of resources related to a Crossplane claim
- Highlighting problematic resources and their status
- Providing detailed error information and events for faster debugging
- Showing the relationship between claims, XRs, and their managed resources

## Features

- **Crossplane Resource Visualization**: Automatically discovers and displays the complete hierarchy of Crossplane resources starting from a claim
- **Smart Debugging**: Identifies problematic resources and provides detailed error information and related events
- **Resource Relationship Mapping**: Shows clear relationships between claims, composite resources (XRs), and their managed resources
- **Comprehensive Resource Analysis**: Explores and displays all child resources and their current state
- **Rich CLI Interface**: Features progress indicators and formatted output for better user experience
- **Efficient Caching**: Implements smart caching to improve performance when working with multiple resources
- **Flexible Output Options**: Supports different verbosity levels to show exactly what you need

## Installation

```bash
pip install xplorer
```

## Requirements

- Python 3.x
- Kubernetes cluster with Crossplane installed
- Kubernetes cluster access configured via kubeconfig
- Dependencies:
  - kubernetes >= 28.1.0
  - rich >= 13.7.0
  - urllib3 >= 2.0.0

## Usage

### Basic Commands

1. List all Crossplane claims in the cluster:
```bash
xplorer --all
```

2. Investigate a specific claim:
```bash
xplorer <claim-name>
```

3. Search in a specific namespace:
```bash
xplorer <claim-name> --namespace <namespace>
```

### Verbosity Levels

- Default: Shows only claim and its immediate XR
- `-v`: Shows claim, XR, and managed resources with issues
- `-vv`: Shows complete resource hierarchy including healthy resources

### Additional Options

- `--debug`: Enable debug mode for detailed logging
- `--refresh-cache`: Force cache refresh
- `--show-cache`: Display cache information and exit
- `--cache-server`: Specify the address of an xplorer-cache server (e.g., http://localhost:8443)
- `--context`: Specify a Kubernetes context to use (also passed to xplorer-cache when used with --cache-server)

## Examples

1. List all Crossplane claims across all namespaces:
```bash
xplorer --all
```

2. Debug a problematic PostgreSQL claim:
```bash
xplorer postgresql-claim -v --namespace dev
```

3. Full inspection of a cloud infrastructure claim:
```bash
xplorer vpc-claim -vv --namespace prod
```

4. Using xplorer-cache server for faster access and reduced API calls:
```bash
xplorer --all --cache-server http://localhost:8443
```

5. Using xplorer-cache with a specific Kubernetes context:
```bash
xplorer --all --cache-server http://localhost:8443 --context production-cluster
```

## Troubleshooting

### Common Scenarios

1. **Resource Creation Issues**
When a claim or its resources are stuck in creation:
```bash
xplorer <claim-name> -v
```
This will show:
- Current status of all resources
- Any error messages from the composition
- Related events that might indicate the issue

2. **Resource Dependencies**
To understand why a claim isn't ready:
```bash
xplorer <claim-name> -vv
```
This displays the complete resource hierarchy, helping identify which dependencies might be blocking progress.

3. **Configuration Problems**
For issues related to misconfiguration:
```bash
xplorer <claim-name> -v --debug
```
This provides additional context about resource configurations and any validation errors.

## Configuration

### Kubernetes Configuration
Xplorer uses your current kubeconfig context for cluster access. Ensure your kubeconfig is properly configured and you have access to the cluster where Crossplane is installed.

### Crossplane Compatibility
- Supports Crossplane v1.x and above
- Compatible with both local and remote provider configurations
- Works with all Crossplane composition types

### Performance Considerations
- For large clusters with many claims, use namespace filtering to improve performance
- The caching system helps reduce API server load; use `--refresh-cache` only when needed
- When debugging specific issues, use appropriate verbosity levels instead of always using `-vv`
- Use `--show-cache` to inspect cached resources and their timestamps:
  ```bash
  xplorer --show-cache
  ```
  This helps understand what resources are cached and when they were last updated, which can be useful for debugging cache-related issues or understanding the tool's performance

### Using Xplorer-Cache
Xplorer supports connecting to an xplorer-cache server for improved performance and reduced API calls to your Kubernetes cluster:

- The xplorer-cache server acts as a proxy between xplorer and your Kubernetes cluster
- It caches API responses to reduce load on your cluster and improve response times
- Use the `--cache-server` parameter to specify the xplorer-cache server address:
  ```bash
  xplorer --all --cache-server http://localhost:8443
  ```
- You can specify a Kubernetes context to use with the `--context` parameter:
  ```bash
  xplorer --all --cache-server http://localhost:8443 --context production-cluster
  ```
- When using both `--cache-server` and `--context`, xplorer automatically passes the context to the xplorer-cache server via an HTTP header (`X-Kubernetes-Context`)
- The xplorer-cache server can be configured to selectively cache certain endpoints while proxying others directly
- For development and testing scenarios, you can work offline using a fully-cached environment
- Refer to the xplorer-cache documentation for details on setting up and configuring the cache server

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request. Areas of interest include:
- Additional debugging features
- Support for new Crossplane features
- Performance improvements
- Documentation enhancements

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Author

Alex Hubitski
