#!/bin/bash
python -m pytest tests/ -v --cov=xplorer
