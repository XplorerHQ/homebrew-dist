#!/bin/bash
set -e

# Script to create release artifacts for Homebrew distribution
# Usage: ./scripts/create_release.sh <version>

VERSION=${1:-$(grep version pyproject.toml | cut -d'"' -f2)}
if [ -z "$VERSION" ]; then
    echo "Error: No version specified and couldn't find version in pyproject.toml"
    exit 1
fi

echo "Creating release for version: $VERSION"

# Clean previous builds
rm -rf dist/ build/

# Build the wheel and source distribution
echo "Building wheel and source distribution..."
python -m build

# Create a release tarball
echo "Creating release tarball..."
git archive --format=tar.gz --prefix=xplorer-${VERSION}/ HEAD > dist/xplorer-${VERSION}.tar.gz

# Calculate SHA256 for the tarball
TARBALL_SHA256=$(shasum -a 256 dist/xplorer-${VERSION}.tar.gz | cut -d' ' -f1)

echo "Release artifacts created in dist/"
echo "Tarball SHA256: $TARBALL_SHA256"

# Path to homebrew tap repository
TAP_DIR="../dist"
FORMULA_FILE="$TAP_DIR/Formula/xplorer.rb"

# Update the Homebrew formula with the correct SHA256
if [ -f "$FORMULA_FILE" ]; then
    sed -i.bak "s/sha256 \".*\"/sha256 \"$TARBALL_SHA256\"/" "$FORMULA_FILE"
    sed -i.bak "s/v[0-9]\+\.[0-9]\+\.[0-9]\+/v$VERSION/g" "$FORMULA_FILE"
    rm "$FORMULA_FILE.bak"
    echo "Updated formula at $FORMULA_FILE"
else
    echo "Warning: Formula file not found at $FORMULA_FILE"
fi

echo ""
echo "Instructions for Homebrew tap setup:"
echo "1. Upload dist/xplorer-${VERSION}.tar.gz to GitHub releases"
echo "2. Formula in ../dist/Formula/xplorer.rb has been updated with correct SHA256"
echo "3. Users can then install with: brew install XplorerHQ/xplorer/xplorer"