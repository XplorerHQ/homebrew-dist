"""
Main application module for Xplorer-Cache.
Thin coordination layer that delegates to specialized modules.
"""

import sys
from fastapi import FastAPI
from .server.system_ops import initialize_system, lifespan
from .api.request_handlers import register_routes
from .api.proxy_router import router as proxy_router
from .core.logging_middleware import LoggingContextMiddleware

# Initialize system-level components only if not in test environment
if "pytest" not in sys.modules:
    initialize_system()

# Create FastAPI app with lifespan
app = FastAPI(
    title="Xplorer-Cache",
    description="A specialized Python server application for efficiently storing, managing, "
                "and proxying Kubernetes cluster data.",
    version="0.1.0",
    lifespan=lifespan
)

# Add logging middleware to the application
app.add_middleware(LoggingContextMiddleware)

# Register all HTTP routes
register_routes(app)

# Include proxy router
app.include_router(
    proxy_router,
    prefix="/proxy",
    tags=["kubernetes-proxy"],
)