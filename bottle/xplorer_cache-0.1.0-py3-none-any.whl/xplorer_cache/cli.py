"""
Command-line interface for Xplorer-Cache.
"""

import sys
from typing import Optional, Dict, Any

import click
from rich.console import Console
from rich.table import Table
import setproctitle

from xplorer_cache import __version__
from xplorer_cache.cli_logic import (
    init_server,
    start_server,
    run_uvicorn_server,
    stop_server,
    get_server_status,
    list_config,
    set_config,
    list_cache,
    show_cache,
    clear_cache,
    export_cache,
    import_cache as import_cache_logic,
    is_server_running,
    read_server_info,
    reset_cache_if_requested,
    update_cache_mode
)

console = Console()

# Console object for rich output formatting
console = Console()


@click.group()
@click.version_option(version=__version__)
def cli():
    """Xplorer-Cache: A Kubernetes API proxy and caching tool for Xplorer."""
    pass


@cli.command()
def init():
    """Initialize the server and database."""
    console.print("[bold green]Initializing Xplorer-Cache...[/bold green]")
    success, message = init_server()
    if success:
        console.print(f"[bold green]{message}[/bold green]")
    else:
        console.print(f"[bold red]{message}[/bold red]")


@cli.command()
@click.option("--port", "-p", default=4433, help="Port to run the server on.")
@click.option("--host", "-h", default="127.0.0.1", help="Host to bind the server to.")
@click.option("--reload/--no-reload", default=True, help="Enable/disable auto-reload.")
@click.option("--daemon", is_flag=True, help="Run as a daemon (background process).")
@click.option("--cache-mode", "-m", type=click.Choice(["live", "cache", "hybrid"]), default="hybrid", help="Default caching mode for endpoints.")
@click.option("--reset-cache", is_flag=True, help="Reset the cache before starting the server.")
def start(port: int, host: str, reload: bool, daemon: bool, cache_mode: str, reset_cache: bool):
    """Start the Xplorer-Cache server.
    
    Launches the FastAPI server either in foreground (default) or daemon mode.
    In foreground mode, press Ctrl+C to stop the server.
    """
    if is_server_running():
        server_info = read_server_info()
        if server_info:
            console.print(f"[bold yellow]Server is already running on {server_info.get('host', '127.0.0.1')}:{server_info.get('port', 4433)}[/bold yellow]")
        else:
            console.print(f"[bold yellow]Server is already running (PID file missing) on default address 127.0.0.1:4433[/bold yellow]")
        return

    # Set process title to be visible in Activity Monitor
    setproctitle.setproctitle("xplorer-cache-cli")
    
    console.print(f"[bold green]Starting Xplorer-Cache server on {host}:{port} (mode: {cache_mode})...[/bold green]")
    
    # Handle cache reset if requested
    if reset_cache:
        console.print("[bold yellow]Resetting cache...[/bold yellow]")
        success, error = reset_cache_if_requested(reset_cache)
        if not success:
            console.print(f"[bold red]{error}[/bold red]")
            sys.exit(1)
    
    # Update default cache mode in config
    success, error = update_cache_mode(cache_mode)
    if not success:
        console.print(f"[bold red]{error}[/bold red]")
        sys.exit(1)
    
    # Start the server in the appropriate mode
    if daemon:
        console.print("[bold blue]Running in daemon mode (background)...[/bold blue]")
        success, message, pid = start_server(host, port, reload, daemon)
        
        if success and pid:
            console.print(f"[bold green]{message}[/bold green]")
            console.print(f"[bold blue]Process ID: {pid}[/bold blue]")
        else:
            console.print(f"[bold red]{message}[/bold red]")
            sys.exit(1)
    else:
        console.print("[bold blue]Running in foreground mode...[/bold blue]")
        console.print("[bold blue]Press Ctrl+C to stop[/bold blue]")
        
        success, message, pid = start_server(host, port, reload, False)
        if not success:
            console.print(f"[bold red]{message}[/bold red]")
            sys.exit(1)
        
        try:
            # This will block until the server is stopped
            run_uvicorn_server(host, port, reload)
        except KeyboardInterrupt:
            console.print("\n[bold yellow]Received keyboard interrupt. Stopping server...[/bold yellow]")
        except Exception as e:
            console.print(f"[bold red]Error running server: {e}[/bold red]")
        finally:
            console.print("[bold green]Server stopped![/bold green]")


@cli.command()
def stop():
    """Stop the server."""
    if not is_server_running():
        console.print("[bold yellow]No server is currently running[/bold yellow]")
        return

    # Get server info (might be None if PID file is missing)
    server_info = read_server_info()
    
    if server_info:
        console.print(f"[bold green]Stopping Xplorer-Cache server on {server_info.get('host', '127.0.0.1')}:{server_info.get('port', 4433)}...[/bold green]")
    else:
        console.print("[bold green]Stopping Xplorer-Cache server (PID file missing)...[/bold green]")
    
    success, message = stop_server()
    if success:
        console.print(f"[bold green]{message}[/bold green]")
    else:
        console.print(f"[bold red]{message}[/bold red]")
        sys.exit(1)


@cli.command()
def status():
    """Show server status and statistics."""
    console.print("[bold blue]Xplorer-Cache Status[/bold blue]")

    # Create a table for server status
    table = Table(title="Server Status")
    table.add_column("Component", style="cyan")
    table.add_column("Status", style="green")
    table.add_column("Details", style="yellow")

    # Get server status from logic layer
    status_info = get_server_status()

    if status_info["running"]:
        if status_info["server"]:
            server_info = status_info["server"]
            if "pid_file" in server_info and server_info["pid_file"] == "Missing":
                table.add_row("Server", "Running", f"{server_info['host']}:{server_info['port']} (PID file missing)")
            else:
                table.add_row("Server", "Running", f"{server_info['host']}:{server_info['port']}")

            if status_info["database"] and status_info["database"]["status"] == "Connected":
                db_info = status_info["database"]
                table.add_row("Database", "Connected", f"{db_info['type']} ({db_info['path']})")
                table.add_row("Cache", "Active", "")
            else:
                table.add_row("Database", status_info["database"]["status"], "")
                table.add_row("Cache", status_info["cache"]["status"], "")
        else:
            # This shouldn't happen, but just to be safe
            table.add_row("Server", "Running", "Unknown host:port")
            table.add_row("Database", "Unknown", "")
            table.add_row("Cache", "Unknown", "")
    else:
        table.add_row("Server", "Stopped", "")
        table.add_row("Database", "Disconnected", "")
        table.add_row("Cache", "Inactive", "")

    console.print(table)

    # Only show cache statistics if server is running
    if status_info["running"] and status_info["cache_stats"]:
        try:
            # Create a table for cache statistics
            stats_table = Table(title="Cache Statistics")
            stats_table.add_column("Metric", style="cyan")
            stats_table.add_column("Value", style="green")

            cache_stats = status_info["cache_stats"]
            stats_table.add_row("Total Resources", str(cache_stats["total_resources"]))
            stats_table.add_row("Cache Size", cache_stats["cache_size"])
            stats_table.add_row("Hit Rate", cache_stats["hit_rate"])

            console.print(stats_table)
        except Exception as e:
            console.print(f"[bold red]Error displaying cache statistics: {e}[/bold red]")


@cli.group()
def config():
    """Manage endpoint configurations."""
    pass


@config.command("list")
def config_list():
    """List current endpoint configurations."""
    console.print("[bold blue]Endpoint Configurations[/bold blue]")

    # Create a table for endpoint configurations
    table = Table(title="Endpoint Configurations")
    table.add_column("Endpoint", style="cyan")
    table.add_column("Mode", style="green")

    # Get configurations from logic layer
    configs = list_config()
    for config in configs:
        table.add_row(config["endpoint"], config["mode"])

    console.print(table)


@config.command("set")
@click.argument("endpoint")
@click.argument("mode", type=click.Choice(["live", "cache", "hybrid"]))
def config_set(endpoint: str, mode: str):
    """Configure endpoint routing (live/cache/hybrid)."""
    console.print(f"[bold green]Setting {endpoint} to {mode} mode...[/bold green]")
    success, message = set_config(endpoint, mode)
    if success:
        console.print(f"[bold green]{message}[/bold green]")
    else:
        console.print(f"[bold red]{message}[/bold red]")


@cli.group()
def cache():
    """Manage cached resources."""
    pass


@cache.command("list")
@click.argument("resource", required=False)
def cache_list(resource: Optional[str] = None):
    """List cached resources."""
    if resource:
        console.print(f"[bold blue]Cached Resources for {resource}[/bold blue]")
    else:
        console.print("[bold blue]All Cached Resources[/bold blue]")

    # Create a table for cached resources
    table = Table(title="Cached Resources")
    table.add_column("Resource", style="cyan")
    table.add_column("Count", style="green")
    table.add_column("Last Updated", style="yellow")

    # Get cached resources from logic layer
    resources = list_cache(resource)
    for res in resources:
        table.add_row(res["resource"], res["count"], res["last_updated"])

    console.print(table)


@cache.command("show")
@click.argument("resource")
@click.option("--name", "-n", help="Resource name to show.")
@click.option("--namespace", "-ns", help="Namespace of the resource.")
def cache_show(resource: str, name: Optional[str] = None, namespace: Optional[str] = None):
    """Show details of a cached resource."""
    # Get resource details from logic layer
    details = show_cache(resource, name, namespace)
    
    if "error" in details:
        console.print(f"[bold red]Error: {details['error']}[/bold red]")
        return
    
    console.print(f"[bold blue]Details for {resource}/{details.get('name', 'unknown')}[/bold blue]")
    console.print(f"Resource: {details.get('resource', resource)}")
    console.print(f"Name: {details.get('name', 'unknown')}")
    if "namespace" in details and details["namespace"]:
        console.print(f"Namespace: {details['namespace']}")
    console.print(f"Status: {details.get('status', 'Unknown')}")


@cache.command("clear")
@click.argument("resource", required=False)
def cache_clear(resource: Optional[str] = None):
    """Clear specific resources from cache."""
    if resource:
        console.print(f"[bold yellow]Clearing {resource} from cache...[/bold yellow]")
    else:
        console.print("[bold yellow]Clearing all resources from cache...[/bold yellow]")
    
    success, message = clear_cache(resource)
    if success:
        console.print(f"[bold green]{message}[/bold green]")
    else:
        console.print(f"[bold red]{message}[/bold red]")


@cli.command()
@click.argument("file")
def export(file: str):
    """Export cache to a file."""
    console.print(f"[bold green]Exporting cache to {file}...[/bold green]")
    success, message = export_cache(file)
    if success:
        console.print(f"[bold green]{message}[/bold green]")
    else:
        console.print(f"[bold red]{message}[/bold red]")


@cli.command()
@click.argument("file")
def import_cache(file: str):
    """Import cache from a file."""
    console.print(f"[bold green]Importing cache from {file}...[/bold green]")
    success, message = import_cache_logic(file)
    if success:
        console.print(f"[bold green]{message}[/bold green]")
    else:
        console.print(f"[bold red]{message}[/bold red]")




def main():
    """Main entry point for the CLI."""
    # Set the process title to "xplorer-cache" so it appears with this name in the process list
    # instead of "python3". This makes it easier to identify the process in tools like ps, top, etc.
    setproctitle.setproctitle("xplorer-cache")

    try:
        cli()
    except Exception as e:
        console.print(f"[bold red]Error: {str(e)}[/bold red]")
        sys.exit(1)


if __name__ == "__main__":
    main()
