#!/usr/bin/env python3
"""
Test Crossplane claims by automatically converting them to XR format and running crossplane render.

This script mimics the crossplane render command but automatically handles claim-to-XR conversion
and provides enhanced validation of the render output.
"""

import click
import yaml
import subprocess
import tempfile
import os
import sys
import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple


class Colors:
    RED = '\033[0;31m'
    GREEN = '\033[0;32m'
    YELLOW = '\033[1;33m'
    BLUE = '\033[0;34m'
    BOLD = '\033[1m'
    RED_BOLD = '\033[1;31m'
    DIM = '\033[2m'
    NC = '\033[0m'  # No Color


def log_info(msg: str):
    click.echo(f"{Colors.BLUE}[INFO]{Colors.NC} {msg}")


def log_success(msg: str):
    click.echo(f"{Colors.GREEN}[SUCCESS]{Colors.NC} {msg}")


def log_warning(msg: str):
    click.echo(f"{Colors.YELLOW}[WARNING]{Colors.NC} {msg}")


def log_error(msg: str):
    click.echo(f"{Colors.RED}[ERROR]{Colors.NC} {msg}")


def check_dependencies() -> bool:
    """Check if required dependencies are available."""
    try:
        # Just check if crossplane binary exists, don't require cluster connection
        subprocess.run(['crossplane', 'version'], capture_output=True, check=False)
        return True
    except FileNotFoundError:
        log_error("crossplane CLI is required but not found")
        return False


def fetch_observed_resource(resource_spec: str) -> Optional[str]:
    """
    Fetch an observed resource from the cluster using kubectl.
    
    Args:
        resource_spec: Resource specification in format 'resource_type/resource_name' 
                      e.g., 'virtualnetwork/vnet-eastus2-intus-uat'
    
    Returns:
        YAML string of the resource or None if failed
    """
    try:
        # Parse resource specification
        if '/' not in resource_spec:
            log_error(f"Invalid resource format '{resource_spec}'. Use 'resource_type/resource_name'")
            return None
        
        resource_type, resource_name = resource_spec.split('/', 1)
        
        # Run kubectl get with YAML output
        cmd = ['kubectl', 'get', resource_type, resource_name, '-o', 'yaml']
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        
        # Clean up the YAML (remove managed fields and other cluster-specific metadata)
        resource_yaml = yaml.safe_load(result.stdout)
        
        # Remove fields that aren't useful for observed state
        if 'metadata' in resource_yaml:
            metadata = resource_yaml['metadata']
            # Keep only essential metadata fields
            essential_fields = ['name', 'namespace', 'labels', 'annotations']
            resource_yaml['metadata'] = {k: v for k, v in metadata.items() if k in essential_fields}
        
        # Remove status.conditions if present (not needed for observed state)
        if 'status' in resource_yaml and 'conditions' in resource_yaml['status']:
            del resource_yaml['status']['conditions']
        
        return yaml.dump(resource_yaml, default_flow_style=False)
        
    except subprocess.CalledProcessError as e:
        stderr_msg = e.stderr if e.stderr else ""
        if "no such host" in stderr_msg or "connection refused" in stderr_msg or "unable to connect" in stderr_msg:
            log_error(f"Cannot connect to cluster. Check VPN/connectivity and verify kubectl context:")
            log_error(f"  kubectl config current-context")
            log_error(f"  kubectl cluster-info")
        else:
            log_error(f"Failed to fetch {resource_spec}: {stderr_msg}")
        return None
    except Exception as e:
        log_error(f"Error processing {resource_spec}: {e}")
        return None


def append_observed_resources(fetch_specs: tuple, output_file: str) -> bool:
    """
    Fetch observed resources from cluster and append them to a file.
    
    Args:
        fetch_specs: Tuple of resource specifications to fetch
        output_file: File to append the resources to
        
    Returns:
        True if successful, False otherwise
    """
    if not fetch_specs:
        return True
    
    log_info(f"Fetching {len(fetch_specs)} observed resource(s) from cluster...")
    
    # Check if kubectl is available
    try:
        subprocess.run(['kubectl', 'version', '--client'], capture_output=True, check=True)
    except (subprocess.CalledProcessError, FileNotFoundError):
        log_error("kubectl is required to fetch observed resources but not found")
        return False
    
    fetched_resources = []
    
    for resource_spec in fetch_specs:
        log_info(f"Fetching {resource_spec}...")
        resource_yaml = fetch_observed_resource(resource_spec)
        
        if resource_yaml:
            fetched_resources.append(resource_yaml)
            log_success(f"✅ Fetched {resource_spec}")
        else:
            log_warning(f"⚠️  Failed to fetch {resource_spec}")
    
    if not fetched_resources:
        log_error("No resources were successfully fetched")
        return False
    
    # Append to output file
    try:
        with open(output_file, 'a') as f:
            for resource_yaml in fetched_resources:
                f.write("---\n")
                f.write(resource_yaml)
                if not resource_yaml.endswith('\n'):
                    f.write('\n')
        
        log_success(f"📁 Appended {len(fetched_resources)} resource(s) to {output_file}")
        return True
        
    except Exception as e:
        log_error(f"Failed to write to {output_file}: {e}")
        return False


def load_yaml_file(file_path: str) -> Dict:
    """Load and parse a YAML file."""
    try:
        with open(file_path, 'r') as f:
            return yaml.safe_load(f)
    except Exception as e:
        log_error(f"Failed to load YAML file {file_path}: {e}")
        sys.exit(1)


def convert_claim_to_xr(claim_data: Dict) -> Dict:
    """Convert a claim YAML to XR format."""
    xr_data = claim_data.copy()
    
    # Convert kind from claim to XR (add X prefix if not present)
    kind = xr_data.get('kind', '')
    if not kind.startswith('X'):
        xr_data['kind'] = f"X{kind}"
        log_info(f"Converting claim kind '{kind}' to XR kind 'X{kind}'")
    else:
        log_warning(f"Kind '{kind}' already has X prefix - assuming it's already an XR")
    
    # Remove claim-specific fields that don't belong in XR
    spec = xr_data.get('spec', {})
    fields_to_remove = [
        'compositeDeletePolicy',
        'compositionRef', 
        'compositionRevisionRef',
        'writeConnectionSecretsToNamespace'
    ]
    
    for field in fields_to_remove:
        spec.pop(field, None)
    
    return xr_data


def count_composition_steps(composition_file: str) -> int:
    """Count the number of steps in a composition pipeline."""
    try:
        comp_data = load_yaml_file(composition_file)
        pipeline = comp_data.get('spec', {}).get('pipeline', [])
        
        # Count steps, excluding auto-ready step
        step_count = 0
        for step in pipeline:
            step_name = step.get('step', '')
            if 'auto-ready' not in step_name.lower():
                step_count += 1
        
        return step_count
    except Exception as e:
        log_warning(f"Could not count composition steps: {e}")
        return 0


def find_composition_file(xr_kind: str, search_paths: List[str]) -> Optional[str]:
    """Find the composition file for a given XR kind."""
    for search_path in search_paths:
        if not os.path.exists(search_path):
            continue
            
        for root, dirs, files in os.walk(search_path):
            for file in files:
                if file.endswith('.yaml') or file.endswith('.yml'):
                    file_path = os.path.join(root, file)
                    try:
                        with open(file_path, 'r') as f:
                            content = f.read()
                            if xr_kind in content and 'kind: Composition' in content:
                                return file_path
                    except Exception:
                        continue
    return None


def analyze_render_output(output_file: str, expected_resource_count: int = 0) -> Tuple[int, List[str]]:
    """Analyze crossplane render output for issues."""
    issues = []
    
    try:
        with open(output_file, 'r') as f:
            content = f.read()
            lines = content.splitlines()
    except Exception as e:
        issues.append(f"Could not read render output: {e}")
        return 0, issues
    
    # Count rendered resources (YAML documents)
    documents = content.split('---')
    resource_count = len([doc for doc in documents if doc.strip()])
    
    # Check for <no value> placeholders
    no_value_matches = re.findall(r'<no value>', content)
    if no_value_matches:
        issues.append(f"Found {len(no_value_matches)} '<no value>' placeholder(s)")
        _show_no_value_context(lines)
    
    # Check for missing resource generation
    if expected_resource_count > 0 and resource_count < expected_resource_count:
        issues.append(f"Expected {expected_resource_count} resources but only rendered {resource_count}")
    
    # Check for common template issues
    if '{{' in content or '}}' in content:
        template_matches = re.findall(r'\{\{[^}]*\}\}', content)
        if template_matches:
            issues.append(f"Found {len(template_matches)} unrendered template expression(s)")
            _show_template_context(lines, template_matches)
    
    # Check for empty values in critical fields (excluding known safe ones)
    empty_value_issues = _analyze_empty_values(lines)
    if empty_value_issues:
        issues.extend(empty_value_issues)
    
    return resource_count, issues


def _show_no_value_context(lines: List[str]):
    """Show context around <no value> placeholders."""
    click.echo(f"\n{Colors.YELLOW}{'=' * 60}{Colors.NC}")
    click.echo(f"{Colors.YELLOW}Context for '<no value>' placeholders:{Colors.NC}")
    click.echo(f"{Colors.YELLOW}{'=' * 60}{Colors.NC}")
    
    for i, line in enumerate(lines):
        if '<no value>' in line:
            start = max(0, i - 2)
            end = min(len(lines), i + 3)
            
            click.echo(f"\n{Colors.BLUE}Lines {start + 1}-{end}:{Colors.NC}")
            for j in range(start, end):
                prefix = f"{j + 1:3d}: "
                if j == i:
                    click.echo(f"{Colors.RED_BOLD}>>> {prefix}{Colors.BOLD}{lines[j]}{Colors.NC}")
                else:
                    click.echo(f"    {prefix}{lines[j]}")


def _show_template_context(lines: List[str], template_matches: List[str]):
    """Show context around unrendered template expressions."""
    click.echo(f"\n{Colors.YELLOW}{'=' * 60}{Colors.NC}")
    click.echo(f"{Colors.YELLOW}Context for unrendered templates:{Colors.NC}")
    click.echo(f"{Colors.YELLOW}{'=' * 60}{Colors.NC}")
    
    for template in template_matches:
        for i, line in enumerate(lines):
            if template in line:
                start = max(0, i - 2)
                end = min(len(lines), i + 3)
                
                click.echo(f"\n{Colors.BLUE}Template '{template}' at lines {start + 1}-{end}:{Colors.NC}")
                for j in range(start, end):
                    prefix = f"{j + 1:3d}: "
                    if j == i:
                        click.echo(f"{Colors.RED_BOLD}>>> {prefix}{Colors.BOLD}{lines[j]}{Colors.NC}")
                    else:
                        click.echo(f"    {prefix}{lines[j]}")
                break  # Only show first occurrence of each template


def _analyze_empty_values(lines: List[str]) -> List[str]:
    """Analyze empty values and show context for problematic ones."""
    issues = []
    
    # Known safe empty values to ignore
    safe_empty_patterns = [
        r'uid:\s*""',  # UIDs are expected to be empty in render output
        r'storageAccountAccessKey:\s*""',  # These are often references
        r'value:\s*""',  # App settings values might be references
    ]
    
    problematic_empty_lines = []
    
    for i, line in enumerate(lines):
        # Check for empty values
        if re.search(r':\s*""?\s*$', line) or re.search(r':\s*\[\s*\]', line) or re.search(r':\s*\{\s*\}', line):
            # Skip if it's a known safe pattern
            is_safe = any(re.search(pattern, line) for pattern in safe_empty_patterns)
            if not is_safe:
                problematic_empty_lines.append(i)
    
    if problematic_empty_lines:
        issues.append(f"Found {len(problematic_empty_lines)} potentially problematic empty value(s)")
        _show_empty_value_context(lines, problematic_empty_lines)
    
    return issues


def _show_empty_value_context(lines: List[str], empty_line_indices: List[int]):
    """Show context around potentially problematic empty values."""
    click.echo(f"\n{Colors.YELLOW}{'=' * 60}{Colors.NC}")
    click.echo(f"{Colors.YELLOW}Context for potentially problematic empty values:{Colors.NC}")
    click.echo(f"{Colors.YELLOW}{'=' * 60}{Colors.NC}")
    
    for i in empty_line_indices:
        start = max(0, i - 2)
        end = min(len(lines), i + 3)
        
        click.echo(f"\n{Colors.BLUE}Empty value at lines {start + 1}-{end}:{Colors.NC}")
        for j in range(start, end):
            prefix = f"{j + 1:3d}: "
            if j == i:
                click.echo(f"{Colors.RED_BOLD}>>> {prefix}{Colors.BOLD}{lines[j]}{Colors.NC}")
            else:
                click.echo(f"    {prefix}{lines[j]}")
        
        click.echo(f"{Colors.YELLOW}{'-' * 40}{Colors.NC}")


@click.group()
def cli():
    """🌟 Heavenly Crossplane Testing Tools
    
    Beautiful claim testing and analysis with auto-conversion and divine debugging feedback!
    """
    pass


@cli.command()
@click.argument('composite_resource', type=click.Path(exists=True))
@click.option('-c', '--composition', type=click.Path(exists=True),
              help='A YAML file specifying the Composition to use')
@click.option('-f', '--functions', type=click.Path(exists=True),
              help='A YAML file specifying the Composition Functions to use')
@click.option('-o', '--observed', type=click.Path(exists=True), 
              help='A YAML file specifying observed state to overlay on each composed resource')
@click.option('-r', '--include-function-results', is_flag=True,
              help='Include intermediate function results in the output')
@click.option('-s', '--sort-by-name', is_flag=True,
              help='Sort resources by name before printing')
@click.option('--output', type=click.Path(),
              help='Write render output to file instead of stdout')
@click.option('--composition-dir', type=click.Path(exists=True),
              default='base/compositions',
              help='Directory to search for composition files (default: base/compositions)')
@click.option('--functions-dir', type=click.Path(exists=True),
              default='base/functions',
              help='Directory to search for functions files (default: base/functions)')
@click.option('--quiet', '-q', is_flag=True,
              help='Suppress analysis output, only show render results')
@click.option('--do-not-open', is_flag=True,
              help='Do not automatically open the output file after rendering')
def render(composite_resource: str, composition: Optional[str], functions: Optional[str], 
           observed: Optional[str], include_function_results: bool, sort_by_name: bool, 
           output: Optional[str], composition_dir: str, functions_dir: str, quiet: bool,
           do_not_open: bool):
    """
    Render a Crossplane claim by converting it to XR format and running crossplane render.
    
    This command automatically handles the conversion from claim format to XR format,
    making it easier to test claims without manual kind renaming.
    
    COMPOSITE_RESOURCE: A YAML file specifying the claim or composite resource to render.
    """
    
    if not check_dependencies():
        sys.exit(1)
    
    
    # Load the input file
    input_data = load_yaml_file(composite_resource)
    
    # Convert claim to XR if needed
    xr_data = convert_claim_to_xr(input_data)
    
    # Create temporary XR file
    with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as temp_xr:
        yaml.dump(xr_data, temp_xr, default_flow_style=False)
        temp_xr_path = temp_xr.name
    
    try:
        # Auto-discover composition file if not provided
        composition_file = composition
        if not composition_file:
            xr_kind = xr_data.get('kind', '')
            composition_file = find_composition_file(xr_kind, [composition_dir])
            if not composition_file:
                log_error(f"Could not find composition file for XR kind '{xr_kind}' in {composition_dir}")
                sys.exit(1)
            if not quiet:
                log_info(f"Auto-discovered composition: {composition_file}")
        
        # Auto-discover functions file if not provided
        functions_file = functions
        if not functions_file:
            # Look for functions.yaml in the functions directory
            potential_functions = [
                os.path.join(functions_dir, 'functions.yaml'),
                os.path.join(functions_dir, 'function.yaml'),
            ]
            for func_file in potential_functions:
                if os.path.exists(func_file):
                    functions_file = func_file
                    break
            
            if not functions_file:
                log_error(f"Could not find functions file in {functions_dir}")
                sys.exit(1)
            if not quiet:
                log_info(f"Auto-discovered functions: {functions_file}")

        # Build crossplane render command
        cmd = ['crossplane', 'render', temp_xr_path, composition_file, functions_file]
        
        if observed:
            cmd.extend(['-o', observed])
            if not quiet:
                log_info(f"Using observed resource data from: {observed}")
        
        if include_function_results:
            cmd.append('-r')
        
        if sort_by_name:
            cmd.append('-s')
        
        # Run crossplane render
        if not quiet:
            log_info("Running crossplane render...")
        
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, check=True)
            render_output = result.stdout
            
            if not quiet:
                log_success("Crossplane render completed successfully")
            
        except subprocess.CalledProcessError as e:
            log_error("Crossplane render failed:")
            if e.stdout:
                click.echo(e.stdout)
            if e.stderr:
                click.echo(e.stderr, err=True)
            sys.exit(1)
        
        # Write output to file or stdout
        if output:
            with open(output, 'w') as f:
                f.write(render_output)
            if not quiet:
                log_info(f"Output saved to: {output}")
            output_file = output
        else:
            click.echo(render_output)
            # Create temp file for analysis
            with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as temp_out:
                temp_out.write(render_output)
                output_file = temp_out.name
        
        # Analyze output if not quiet
        if not quiet:
            # Get expected resource count from the composition we used
            expected_count = count_composition_steps(composition_file)
            if expected_count > 0:
                log_info(f"Found composition with {expected_count} resource-generating steps")
            
            # Analyze render output
            resource_count, issues = analyze_render_output(output_file, expected_count)
            
            log_info(f"Generated {resource_count} total resources")
            
            if issues:
                log_warning(f"Found {len(issues)} potential issue(s):")
                for issue in issues:
                    click.echo(f"  - {issue}")
            else:
                log_success("✅ No issues found in render output!")
        
        # Auto-open the output file unless disabled
        if output and not do_not_open:
            try:
                if sys.platform == "darwin":  # macOS
                    subprocess.run(['open', output], check=False)
                elif sys.platform == "linux":  # Linux
                    subprocess.run(['xdg-open', output], check=False)
                elif sys.platform == "win32":  # Windows
                    subprocess.run(['start', output], shell=True, check=False)
                
                if not quiet:
                    log_info(f"Opened {output} in default application")
            except Exception as e:
                if not quiet:
                    log_warning(f"Could not auto-open file: {e}")
        
        # Clean up temp output file if we created one
        if not output and not quiet:
            os.unlink(output_file)
            
    finally:
        # Clean up temporary XR file
        os.unlink(temp_xr_path)


@cli.command('apply')
@click.argument('composite_resource', type=click.Path(exists=True))
@click.option('--composition-dir', type=click.Path(exists=True),
              default='base/compositions',
              help='Directory to search for composition files (default: base/compositions)')
@click.option('--functions-dir', type=click.Path(exists=True),
              default='base/functions',
              help='Directory to search for functions files (default: base/functions)')
@click.option('--xrd-dir', type=click.Path(exists=True),
              default='base/xrd',
              help='Directory to search for XRD files (default: base/xrd)')
@click.option('--dry-run', is_flag=True,
              help='Show what would be applied without actually applying')
@click.option('--yes', '-y', is_flag=True,
              help='Skip confirmation prompt')
@click.option('--quiet', '-q', is_flag=True,
              help='Suppress informational output')
def apply_cmd(composite_resource: str, composition_dir: str, functions_dir: str, 
              xrd_dir: str, dry_run: bool, yes: bool, quiet: bool):
    """
    Apply all necessary manifests for a claim to the cluster.
    
    This command discovers and applies the XRD, Composition, Functions, and Claim
    manifests needed to deploy a Crossplane claim. It shows what will be applied
    and asks for confirmation before proceeding.
    
    COMPOSITE_RESOURCE: A YAML file specifying the claim to deploy
    
    Examples:
    
        # Apply a claim with confirmation
        test-claim apply overlays/uat/carehub-elation-uat.yaml
        
        # Apply without confirmation
        test-claim apply overlays/uat/carehub-elation-uat.yaml --yes
        
        # Dry run to see what would be applied
        test-claim apply overlays/uat/carehub-elation-uat.yaml --dry-run
    """
    
    if not quiet:
        click.echo(f"{Colors.DIM}Discovering manifests...{Colors.NC}")
    
    # Load the claim file
    claim_data = load_yaml_file(composite_resource)
    
    # Extract XR kind for discovery (convert claim kind to XR kind)
    claim_kind = claim_data.get('kind', '')
    xr_kind = f"X{claim_kind}" if not claim_kind.startswith('X') else claim_kind
    
    # Discover required manifests
    discovered_files = []
    
    # 1. Find XRD
    xrd_file = find_xrd_file(xr_kind, [xrd_dir])
    if xrd_file:
        discovered_files.append(('XRD', xrd_file))
        if not quiet:
            click.echo(f"Found XRD: {xrd_file}")
    else:
        log_error(f"❌ Could not find XRD for kind '{xr_kind}' in {xrd_dir}")
        return
    
    # 2. Find Composition
    composition_file = find_composition_file(xr_kind, [composition_dir])
    if composition_file:
        discovered_files.append(('Composition', composition_file))
        if not quiet:
            click.echo(f"Found Composition: {composition_file}")
    else:
        log_error(f"❌ Could not find Composition for kind '{xr_kind}' in {composition_dir}")
        return
    
    # 3. Find Functions
    functions_file = None
    potential_functions = [
        os.path.join(functions_dir, 'functions.yaml'),
        os.path.join(functions_dir, 'function.yaml'),
    ]
    for func_file in potential_functions:
        if os.path.exists(func_file):
            functions_file = func_file
            break
    
    if functions_file:
        discovered_files.append(('Functions', functions_file))
        if not quiet:
            click.echo(f"Found Functions: {functions_file}")
    else:
        log_error(f"❌ Could not find Functions file in {functions_dir}")
        return
    
    # 4. Add the claim itself
    discovered_files.append(('Claim', composite_resource))
    if not quiet:
        click.echo(f"Using Claim: {composite_resource}")
    
    # Show what will be applied
    if not quiet:
        click.echo(f"\n{Colors.BLUE}📋 Manifests to apply:{Colors.NC}")
        for manifest_type, file_path in discovered_files:
            click.echo(f"  {Colors.GREEN}•{Colors.NC} {manifest_type:12} {file_path}")
    
    if dry_run:
        if not quiet:
            log_info("🔍 Dry run mode - showing kubectl commands that would be executed:")
        for manifest_type, file_path in discovered_files:
            click.echo(f"kubectl apply -f {file_path}")
        return
    
    # Ask for confirmation unless --yes flag is used
    if not yes and not quiet:
        click.echo(f"\n{Colors.YELLOW}⚠️  This will apply the above manifests to your current kubectl context:{Colors.NC}")
        try:
            result = subprocess.run(['kubectl', 'config', 'current-context'], 
                                   capture_output=True, text=True, check=True)
            context = result.stdout.strip()
            click.echo(f"   Context: {Colors.BOLD}{context}{Colors.NC}")
        except:
            click.echo(f"   Context: {Colors.RED}Unable to determine current context{Colors.NC}")
        
        if not click.confirm('\nProceed with apply?'):
            log_info("Operation cancelled by user")
            return
    
    # Apply the manifests
    if not quiet:
        click.echo(f"{Colors.DIM}Applying manifests...{Colors.NC}")
    
    applied_successfully = 0
    for manifest_type, file_path in discovered_files:
        if not quiet:
            click.echo(f"{Colors.DIM}Applying {manifest_type}: {file_path}{Colors.NC}")
        
        try:
            result = subprocess.run(['kubectl', 'apply', '-f', file_path], 
                                   capture_output=True, text=True, check=True)
            
            # Parse and show the result
            output_lines = result.stdout.strip().split('\n')
            for line in output_lines:
                if line.strip():
                    if 'created' in line:
                        log_success(f"  ✨ {line}")
                    elif 'configured' in line or 'unchanged' in line:
                        log_info(f"  📝 {line}")
                    else:
                        log_info(f"  ℹ️  {line}")
            
            applied_successfully += 1
            
        except subprocess.CalledProcessError as e:
            log_error(f"❌ Failed to apply {manifest_type}: {file_path}")
            if e.stderr:
                log_error(f"   Error: {e.stderr.strip()}")
            continue
    
    # Summary
    if applied_successfully == len(discovered_files):
        if not quiet:
            log_success(f"🎉 Successfully applied all {applied_successfully} manifests!")
    else:
        if not quiet:
            log_warning(f"⚠️  Applied {applied_successfully}/{len(discovered_files)} manifests")


def find_xrd_file(xr_kind: str, search_paths: List[str]) -> Optional[str]:
    """Find the XRD file for a given XR kind."""
    # Convert XR kind to expected XRD pattern
    # XIntCarehubElation -> xintcarehubelation or similar
    expected_patterns = [
        xr_kind.lower(),
        xr_kind.lower().replace('x', '', 1),  # Remove first X
    ]
    
    for search_path in search_paths:
        if not os.path.exists(search_path):
            continue
            
        for root, dirs, files in os.walk(search_path):
            for file in files:
                if file.endswith('.yaml') or file.endswith('.yml'):
                    file_path = os.path.join(root, file)
                    try:
                        with open(file_path, 'r') as f:
                            content = f.read()
                            # Check if this file contains our XR kind
                            if f'kind: {xr_kind}' in content and 'CompositeResourceDefinition' in content:
                                return file_path
                            # Also check for patterns in filename
                            for pattern in expected_patterns:
                                if pattern in file.lower():
                                    return file_path
                    except Exception:
                        continue
    return None


@cli.command('fetch-observed')
@click.argument('resource_specs', nargs=-1, required=True)
@click.option('-o', '--output', type=click.Path(), required=True,
              help='File to append fetched observed resources to (creates if not exists)')
@click.option('--quiet', '-q', is_flag=True,
              help='Suppress informational output')
def fetch_observed_cmd(resource_specs: tuple, output: str, quiet: bool):
    """
    Fetch observed resources from the cluster and append them to a file.
    
    This command fetches managed resources from your current kubectl context
    and saves them in a format suitable for use with the render command's
    --observed option.
    
    RESOURCE_SPECS: One or more resource specifications in format 'resource_type/resource_name'
    
    Examples:
    
        # Fetch a single VNet
        test-claim fetch-observed virtualnetwork/vnet-eastus2-intus-uat -o observed.yaml
        
        # Fetch multiple resources
        test-claim fetch-observed virtualnetwork/vnet-eastus2-intus-uat subnet/snet-aks-uat -o observed.yaml
    """
    
    if not quiet:
        log_info(f"Fetching {len(resource_specs)} observed resource(s) from cluster...")
    
    # Check if kubectl is available
    try:
        subprocess.run(['kubectl', 'version', '--client'], capture_output=True, check=True)
    except (subprocess.CalledProcessError, FileNotFoundError):
        log_error("kubectl is required to fetch observed resources but not found")
        sys.exit(1)
    
    if not append_observed_resources(resource_specs, output):
        sys.exit(1)
    
    if not quiet:
        log_success("✅ Observed resources fetched successfully!")


# For backward compatibility, make render the default command when no subcommand is specified
@click.command(context_settings={"ignore_unknown_options": True})
@click.argument('composite_resource', type=click.Path(exists=True))
@click.pass_context
def default_render(ctx, composite_resource):
    """Default render command for backward compatibility."""
    # Forward to the render subcommand
    ctx.invoke(render, composite_resource=composite_resource)


if __name__ == '__main__':
    cli()