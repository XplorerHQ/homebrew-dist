#!/usr/bin/env python3
"""
Standalone analysis tool for Crossplane render output files.

This script analyzes existing crossplane render output for common issues and provides
detailed context with beautiful visual feedback.
"""

import click
import sys
import os
import importlib.util
from pathlib import Path


def load_test_claim_module():
    """Load the test-claim module to access analysis functions."""
    try:
        # Try importing as installed module first
        import test_claim
        return test_claim
    except ImportError:
        # Fall back to local import for development
        script_dir = Path(__file__).parent
        test_claim_path = script_dir / "test-claim.py"
        
        spec = importlib.util.spec_from_file_location("test_claim", test_claim_path)
        test_claim = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(test_claim)
        return test_claim


@click.command()
@click.argument('render_output_file', type=click.Path(exists=True))
@click.option('--expected-count', type=int, default=0,
              help='Expected number of resources (for resource count validation)')
@click.option('--composition', type=click.Path(exists=True),
              help='Composition file to auto-detect expected resource count')
def analyze(render_output_file: str, expected_count: int, composition: str):
    """
    Analyze a crossplane render output file for common issues.
    
    This tool provides detailed analysis of render output with beautiful visual feedback,
    including BOLD RED highlighting of problem lines and contextual information.
    
    RENDER_OUTPUT_FILE: Path to the crossplane render output YAML file to analyze
    """
    
    # Load the analysis functions
    try:
        test_claim = load_test_claim_module()
    except Exception as e:
        click.echo(f"Error loading analysis module: {e}", err=True)
        sys.exit(1)
    
    # Auto-detect expected count from composition if provided
    if composition and not expected_count:
        try:
            expected_count = test_claim.count_composition_steps(composition)
            if expected_count > 0:
                test_claim.log_info(f"Auto-detected {expected_count} expected resources from composition")
        except Exception as e:
            test_claim.log_warning(f"Could not count composition steps: {e}")
    
    # Analyze the render output
    test_claim.log_info(f"Analyzing render output: {render_output_file}")
    
    try:
        resource_count, issues = test_claim.analyze_render_output(render_output_file, expected_count)
    except Exception as e:
        test_claim.log_error(f"Analysis failed: {e}")
        sys.exit(1)
    
    # Summary
    click.echo()
    test_claim.log_info(f"Generated {resource_count} total resources")
    if expected_count > 0:
        test_claim.log_info(f"Expected {expected_count} resources")
    
    if issues:
        test_claim.log_warning(f"Found {len(issues)} potential issue(s):")
        for issue in issues:
            click.echo(f"  - {issue}")
    else:
        test_claim.log_success("✅ No issues found in render output!")


if __name__ == '__main__':
    analyze()